package com.brainybeam.roadsideassistance.Admin.CustomArrayList;

public class ActiveUsersList {

    String UserID, UserType, FirstName, LastName, ProfileImage, MobileNumber, Email;
    String Account_Status, Created_time;

    public String getUserID() {
        return UserID;
    }

    public void setUserID(String userID) {
        UserID = userID;
    }

    public String getUserType() {
        return UserType;
    }

    public void setUserType(String userType) {
        UserType = userType;
    }

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String firstName) {
        FirstName = firstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String lastName) {
        LastName = lastName;
    }

    public String getProfileImage() {
        return ProfileImage;
    }

    public void setProfileImage(String profileImage) {
        ProfileImage = profileImage;
    }

    public String getMobileNumber() {
        return MobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        MobileNumber = mobileNumber;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getAccount_Status() {
        return Account_Status;
    }

    public void setAccount_Status(String account_Status) {
        Account_Status = account_Status;
    }

    public String getCreated_time() {
        return Created_time;
    }

    public void setCreated_time(String created_time) {
        Created_time = created_time;
    }

}
