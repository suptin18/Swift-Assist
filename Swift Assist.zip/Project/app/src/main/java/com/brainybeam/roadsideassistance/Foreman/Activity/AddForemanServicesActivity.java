package com.brainybeam.roadsideassistance.Foreman.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

import com.brainybeam.roadsideassistance.Foreman.DashBoard.ForemanDashboardActivity;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.AddForemanServicesData;
import com.brainybeam.roadsideassistance.User.DashBoard.UserDashboardActivity;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConstantData;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import retrofit2.Call;

public class AddForemanServicesActivity extends AppCompatActivity {

    Spinner TypeOfProblem, ProblemSubType;
    EditText FixedCharge;
    LinearLayout layout;
    Button AddButton, BackButton;

    ArrayList<String> arrayList_TypeOfProblem, arrayList_ProblemSubType1, arrayList_ProblemSubType2, arrayList_ProblemSubType;
    String sTypeOfProblem, sProblemSubType, sFixedCharge;

    FirebaseAuth mAuth;
    FirebaseApp firebaseApp;
    FirebaseFirestore fStore;

    SharedPreferences sp;


    int count1, count2, count3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_foreman_services);

        sp = getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);
        firebaseApp = FirebaseApp.initializeApp(getApplicationContext());
        mAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();

        TypeOfProblem = findViewById(R.id.add_foreman_services_Spinner_TypeOfProblem);
        ProblemSubType = findViewById(R.id.add_foreman_services_Spinner_ProblemSubType);
        FixedCharge = findViewById(R.id.add_foreman_services_FixedServiceChage);
        layout = findViewById(R.id.add_foreman_services_ProblemSubType_Layout);
        AddButton = findViewById(R.id.add_foreman_services_AddButton);
        BackButton = findViewById(R.id.add_foreman_services_backButton);

        // layout.setVisibility(View.GONE);

        arrayList_TypeOfProblem = new ArrayList<>();
        arrayList_TypeOfProblem.add("Select TypeOfProblem");
        String typeOfSituationalServices[] = ConstantData.TypeOfProblem;
        List<String> list;
        list = Arrays.asList(typeOfSituationalServices);
        arrayList_TypeOfProblem.addAll(list);

        ArrayAdapter arrayAdapter = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_list_item_1, arrayList_TypeOfProblem);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_list_item_activated_1);
        TypeOfProblem.setAdapter(arrayAdapter);


        sTypeOfProblem = "";
        TypeOfProblem.setSelection(arrayList_TypeOfProblem.indexOf("Select TypeOfProblem"));
        TypeOfProblem.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                TypeOfProblem.setSelection(i);
                sTypeOfProblem = arrayList_TypeOfProblem.get(i);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        arrayList_ProblemSubType1 = new ArrayList<>();
        arrayList_ProblemSubType1.add("Select ProblemSubType");
        String temp1[] = ConstantData.ProblemSubTypeFuel;
        List<String> list1;
        list1 = Arrays.asList(temp1);
        arrayList_ProblemSubType1.addAll(list1);

        ArrayAdapter arrayAdapter1 = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_list_item_1, arrayList_ProblemSubType1);
        arrayAdapter1.setDropDownViewResource(android.R.layout.simple_list_item_activated_1);

        arrayList_ProblemSubType2 = new ArrayList<>();
        arrayList_ProblemSubType2.add("Select ProblemSubType");
        String temp2[] = ConstantData.ProblemSubTypeFuel;
        List<String> list2;
        list2 = Arrays.asList(temp2);
        arrayList_ProblemSubType2.addAll(list2);

        arrayList_ProblemSubType = new ArrayList<>();
        arrayList_ProblemSubType.add("Select ProblemSubType");
        String temp4[] = ConstantData.ProblemSubType;
        List<String> list4;
        list4 = Arrays.asList(temp4);
        arrayList_ProblemSubType.addAll(list4);


        ArrayAdapter arrayAdapter2 = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_list_item_1, arrayList_ProblemSubType2);
        arrayAdapter2.setDropDownViewResource(android.R.layout.simple_list_item_activated_1);
        count1 = 0;
        count2 = 0;
        count3 = 0;

        // Temp
        ArrayList<String> list3 = new ArrayList<>();
        list3.add("-");
        ArrayAdapter arrayAdapter3 = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_list_item_1, list3);
        arrayAdapter3.setDropDownViewResource(android.R.layout.simple_list_item_activated_1);


        ArrayAdapter arrayAdapter4 = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_list_item_1, list4);
        arrayAdapter3.setDropDownViewResource(android.R.layout.simple_list_item_activated_1);


        ProblemSubType.setAdapter(arrayAdapter4);
        ProblemSubType.setSelection(arrayList_ProblemSubType.indexOf("Select ProblemSubType"));

        if (sTypeOfProblem.equals("Fuel Problem")) {
            layout.setVisibility(View.VISIBLE);
            ProblemSubType.setAdapter(arrayAdapter1);
            ProblemSubType.setSelection(arrayList_ProblemSubType1.indexOf("Select ProblemSubType"));
            count1 = count1 + 1;

        }
        if (sTypeOfProblem.equals("Tyre Problem")) {
            layout.setVisibility(View.VISIBLE);
            ProblemSubType.setAdapter(arrayAdapter2);
            ProblemSubType.setSelection(arrayList_ProblemSubType2.indexOf("Select ProblemSubType"));
            count2 = count2 + 1;

        }


        sProblemSubType = "";

        ProblemSubType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                ProblemSubType.setSelection(i);
                if (count1 != 0) {
                    sProblemSubType = arrayList_ProblemSubType.get(i);
                } else if (count2 != 0) {
                    sProblemSubType = arrayList_ProblemSubType.get(i);
                } else {
                    sProblemSubType = "";
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        AddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                sFixedCharge = FixedCharge.getText().toString();

                if (sTypeOfProblem.equalsIgnoreCase("Select TypeOfProblem") ||
                        sTypeOfProblem.equalsIgnoreCase("") || sTypeOfProblem.isEmpty()) {
                    new CommonMethod(getApplicationContext(), "Please Select Type Of Problem");
                } else if (sFixedCharge.isEmpty()) {
                    FixedCharge.setError("FixedCharge is Required");
                } else {

                    AddServicesData();

                }


            }
        });

        BackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
                // new CommonMethod(AddForemanServicesActivity.this, ForemanServicesFragment.class);
            }
        });


    }

    private void AddServicesData() {
        String userID = Objects.requireNonNull(mAuth.getCurrentUser()).getUid();

        String serviceID = userID + sTypeOfProblem + sProblemSubType;
        String profileImage = "images/userprofile/"+userID+".jpg";
        String typeOfProblem = sTypeOfProblem;
        String problemSubType = sProblemSubType;
        String serviceFixedCharge = sFixedCharge;

        String FirstName = sp.getString(SharedPreferencesData.FirstName, "");
        String LastName = sp.getString(SharedPreferencesData.LastName, "");
        String MobileNumber = sp.getString(SharedPreferencesData.MobileNumber, "");
        String FullAddress =   sp.getString(SharedPreferencesData.ForemanAddress, "") + "," + sp.getString(SharedPreferencesData.ForemanArea, "") + "," + sp.getString(SharedPreferencesData.ForemanCity, "") + "," + sp.getString(SharedPreferencesData.ForemanState, "");

        String sForemanLatitude = sp.getString(SharedPreferencesData.Foreman_ForemanLatitude,"");

        String sForemanLongitude = sp.getString(SharedPreferencesData.Foreman_ForemanLongitude,"");



        DocumentReference documentReference = fStore.collection("Services").document(serviceID);
        Map<String, Object> service = new HashMap<>();
        service.put("serviceID", serviceID);
        service.put("foremanID", userID);
        service.put("profileImage", profileImage);
        service.put("typeOfProblem", typeOfProblem);
        service.put("problemSubType", problemSubType);
        service.put("serviceFixedCharge", serviceFixedCharge);
        service.put("FirstName",FirstName);
        service.put("LastName", LastName);
        service.put("MobileNumber", MobileNumber);
        service.put("FullAddress", FullAddress);
        service.put("sForemanLatitude", sForemanLatitude);
        service.put("sForemanLongitude", sForemanLongitude);
        documentReference.set(service).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                Toast.makeText(AddForemanServicesActivity.this, "Service Add Successfully", Toast.LENGTH_SHORT).show();
                Log.d("TAG", "Service Add Successfully for " + userID);
            }

        });
        //onBackPressed();
        new CommonMethod(AddForemanServicesActivity.this, ForemanDashboardActivity.class);


    }

}