package com.brainybeam.roadsideassistance.User.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.MenuItem;

import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.GetUserVehicleData;
import com.brainybeam.roadsideassistance.User.CustomArrayList.UserVehicleList;
import com.brainybeam.roadsideassistance.User.DashBoard.UserVehicleDetailAdapter;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConnectionDetector;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UserVehicleSelectionActivity extends AppCompatActivity {

    RecyclerView recyclerView;

    ArrayList<UserVehicleList> arrayList;


    SharedPreferences sp;
    FirebaseAuth mAuth;
    FirebaseFirestore fStore;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_vehicle_selection);
        getSupportActionBar().setTitle("Select Vehicle");
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#2196F3"));
        getSupportActionBar().setBackgroundDrawable(colorDrawable);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        sp = getSharedPreferences(SharedPreferencesData.PREF, Context.MODE_PRIVATE);
        mAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();

        recyclerView = findViewById(R.id.user_vehicle_selection_recyclerview);

        recyclerView.setLayoutManager(new LinearLayoutManager(UserVehicleSelectionActivity.this));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        if (new ConnectionDetector(UserVehicleSelectionActivity.this).isConnectingToInternet()) {

            recyclerViewDataSetMethod();

        } else {
            new ConnectionDetector(UserVehicleSelectionActivity.this).connectiondetect();
        }

    }

    private void recyclerViewDataSetMethod() {

        arrayList = new ArrayList<>();
        String userID = Objects.requireNonNull(mAuth.getCurrentUser()).getUid();
        Task<QuerySnapshot> documentReference = fStore.collection("Vehicles").whereEqualTo("userID", userID).get();
        documentReference.addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful() && task.getResult() != null) {
                    for (DocumentSnapshot document : task.getResult()) {
                        UserVehicleList list = new UserVehicleList();
                        list.setVehicleID(document.getString("vehicleID"));
                        list.setUserID(document.getString("userID"));
                        list.setNumberPlate_number(document.getString("numberPlateNumber"));
                        list.setTypeOfVehicle(document.getString("typeOfVehicle"));
                        list.setVehicleModelName(document.getString("vehicleModelName"));
                        list.setVehicle_Colour(document.getString("vehicleColour"));
                        arrayList.add(list);
                    }
                    UserVehicleSelectionAdapter adapter = new UserVehicleSelectionAdapter(UserVehicleSelectionActivity.this, arrayList, sp,fStore);
                    recyclerView.setAdapter(adapter);
                }
            }
        });


    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

}