package com.brainybeam.roadsideassistance.Foreman.DashBoard;

import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.brainybeam.roadsideassistance.Foreman.Activity.AddForemanServicesActivity;
import com.brainybeam.roadsideassistance.Foreman.CustomArrayList.ServiceListData;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConnectionDetector;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Objects;


public class ForemanServicesFragment extends Fragment {


    RecyclerView recyclerView;
    FloatingActionButton floatingAddButton;

    ArrayList<ServiceListData> arrayList_ForRecyclerView;


    SharedPreferences sp;
    FirebaseAuth mAuth;
    FirebaseFirestore fStore;


    public ForemanServicesFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_foreman_services, container, false);

        sp = requireActivity().getSharedPreferences(SharedPreferencesData.PREF, getActivity().MODE_PRIVATE);
        mAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();

        floatingAddButton = view.findViewById(R.id.frag_foreman_services_floatingAddButton);

        recyclerView = view.findViewById(R.id.frag_foreman_services_recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        floatingAddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CommonMethod(getActivity(), AddForemanServicesActivity.class);
            }
        });


        if (new ConnectionDetector(getActivity()).isConnectingToInternet()) {

            recyclerViewDataSetMethod();

        } else {
            new ConnectionDetector(getActivity()).connectiondetect();
        }

        return view;
    }


    private void recyclerViewDataSetMethod() {

        arrayList_ForRecyclerView = new ArrayList<>();
        ServiceListData list = new ServiceListData();

        String userID = Objects.requireNonNull(mAuth.getCurrentUser()).getUid();
        Task<QuerySnapshot> documentReference = fStore.collection("Services").whereEqualTo("foremanID", userID).get();
        documentReference.addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {

                if (task.isSuccessful() && task.getResult() != null) {
                    for (DocumentSnapshot document : task.getResult()) {
                        ServiceListData list = new ServiceListData();
                        list.setServiceID(document.getString("serviceID"));
                        list.setForemanID(document.getString("foremanID"));
                        list.setFirstName(document.getString("FirstName"));
                        list.setLastName(document.getString("LastName"));
                        list.setProfileImage(document.getString("profileImage"));
                        list.setMobileNumber(document.getString("MobileNumber"));
                        list.setTypeOfService(document.getString("typeOfProblem"));
                        list.setProblemSubType(document.getString("problemSubType"));
                        list.setServiceFixedCharge(document.getString("serviceFixedCharge"));

                        arrayList_ForRecyclerView.add(list);
                    }
                    ForemanServicesAdapter adapter = new ForemanServicesAdapter(getActivity(), arrayList_ForRecyclerView);
                    recyclerView.setAdapter(adapter);
                    adapter.notifyDataSetChanged();
                }
            }
        });


    }
}