package com.brainybeam.roadsideassistance.Admin.DashBoard;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.brainybeam.roadsideassistance.Admin.CustomArrayList.ActiveSPList;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.AdminActiveSPData;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConnectionDetector;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class AdminActiveServiceProviderFragment extends Fragment {

    RecyclerView recyclerView;

    ArrayList<ActiveSPList> arrayList;


    SharedPreferences sp;


    public AdminActiveServiceProviderFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_admin_active_service_provider, container, false);


        sp = getActivity().getSharedPreferences(SharedPreferencesData.PREF, Context.MODE_PRIVATE);

        recyclerView = view.findViewById(R.id.frag_admin_activeSP_recyclerView);

        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        if (new ConnectionDetector(getActivity()).isConnectingToInternet()) {


            recyclerViewDataSetMethod();

        } else {
            new ConnectionDetector(getActivity()).connectiondetect();
        }


        return view;
    }

    private void recyclerViewDataSetMethod() {


//        sp.edit().putString(SharedPreferencesData.Admin_NumberOfForeman, String.valueOf(response.body().numberOfRow)).commit();
//
//        arrayList = new ArrayList<>();
//
//
//        for (int i = 0; i < data.response.size(); i++) {
//
//            ActiveSPList list = new ActiveSPList();
//
//            list.setForemanID(data.response.get(i).foremanID);
//            list.setUserType(data.response.get(i).userType);
//            list.setFirstName(data.response.get(i).firstName);
//            list.setLastName(data.response.get(i).lastName);
//            list.setProfileImage(data.response.get(i).profileImage);
//            list.setMobileNumber(data.response.get(i).mobileNumber);
//            list.setEmail(data.response.get(i).email);
//            list.setAddress(data.response.get(i).address);
//            list.setArea(data.response.get(i).area);
//            list.setCity(data.response.get(i).city);
//            list.setState(data.response.get(i).state);
//            list.setAccount_Status(data.response.get(i).accountStatus);
//            list.setCreated_time(data.response.get(i).createdTime);
//
//            arrayList.add(list);
//        }

        AdminActiveSPAdapter adapter = new AdminActiveSPAdapter(getActivity(), arrayList);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();


    }

}