package com.brainybeam.roadsideassistance.Foreman.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import com.brainybeam.roadsideassistance.Foreman.CustomArrayList.ServiceListData;
import com.brainybeam.roadsideassistance.Foreman.DashBoard.ForemanServicesAdapter;
import com.brainybeam.roadsideassistance.Notification.UserNotificationActivity;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.GetForemanServicesData;
import com.brainybeam.roadsideassistance.User.DashBoard.UserDashboardActivity;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConnectionDetector;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ForemanHomeAddServicesActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    FloatingActionButton floatingAddButton;

    ArrayList<ServiceListData> arrayList_ForRecyclerView;


    SharedPreferences sp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_foreman_home_add_services);
        getSupportActionBar().setTitle("Add Services");
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#2196F3"));
        getSupportActionBar().setBackgroundDrawable(colorDrawable);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        sp = getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);

        floatingAddButton = findViewById(R.id.foreman_services_floatingAddButton);

        recyclerView = findViewById(R.id.foreman_services_recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(ForemanHomeAddServicesActivity.this));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        floatingAddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CommonMethod(ForemanHomeAddServicesActivity.this, AddForemanServicesActivity.class);
            }
        });


        if (new ConnectionDetector(ForemanHomeAddServicesActivity.this).isConnectingToInternet()) {
            recyclerViewDataSetMethod();
        } else {
            new ConnectionDetector(ForemanHomeAddServicesActivity.this).connectiondetect();
        }

    }

    private void recyclerViewDataSetMethod() {

        sp.getString(SharedPreferencesData.UserID, "");


//        arrayList_ForRecyclerView = new ArrayList<>();
//
//        for (int i = 0; i < data.response.size(); i++) {
//            ServiceListData list = new ServiceListData();
//
//            list.setServiceID(data.response.get(i).serviceID);
//            list.setForemanID(data.response.get(i).foremanID);
//            list.setFirstName(data.response.get(i).firstName);
//            list.setLastName(data.response.get(i).lastName);
//            list.setProfileImage(data.response.get(i).profileImage);
//            list.setMobileNumber(data.response.get(i).mobileNumber);
//            list.setTypeOfService(data.response.get(i).typeOfProblem);
//            list.setProblemSubType(data.response.get(i).problemSubType);
//            list.setServiceFixedCharge(data.response.get(i).serviceFixedCharge);
//
//            arrayList_ForRecyclerView.add(list);
//        }

        ForemanServicesAdapter adapter = new ForemanServicesAdapter(ForemanHomeAddServicesActivity.this, arrayList_ForRecyclerView);
        recyclerView.setAdapter(adapter);


    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

}