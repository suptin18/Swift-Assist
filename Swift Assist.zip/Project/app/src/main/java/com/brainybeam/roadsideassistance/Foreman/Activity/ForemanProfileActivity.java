package com.brainybeam.roadsideassistance.Foreman.Activity;

import static com.google.android.material.internal.ContextUtils.getActivity;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.brainybeam.roadsideassistance.GPS.GPSTracker;
import com.brainybeam.roadsideassistance.Login.LoginActivity;
import com.brainybeam.roadsideassistance.OTPVerification.OTPVerificationActivity;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.DeleteUserORForemanData;
import com.brainybeam.roadsideassistance.RetrofitData.GetProfileImageData;
import com.brainybeam.roadsideassistance.RetrofitData.LocationData;
import com.brainybeam.roadsideassistance.RetrofitData.UpdateForemanData;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConstantData;
import com.brainybeam.roadsideassistance.Utils.FilePath;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;
//import com.zhihu.matisse.Matisse;
//import com.zhihu.matisse.MimeType;
//import com.zhihu.matisse.engine.impl.GlideEngine;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

import de.hdodenhof.circleimageview.CircleImageView;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ForemanProfileActivity extends AppCompatActivity {

    LinearLayout layout1, layout2;
    CircleImageView ProfileImage1, ProfileImage2;
    TextView FirstName, LastName, Contact, Email, Address, Area, City, State, AccountStatus;
    EditText FirstName_EditText, LastName_EditText, Contact_EditText, Email_EditText, Password_EditText, Address_EditText, Area_EditText, City_EditText;
    Spinner Spinner_State;
    Button EditTextButton, UpdateButton, DeactivateButton1, DeactivateButton2;

    ArrayList<String> arrayList;
    String sFirstName, sLastName, sContact, sEmail, sPassword, sAddress, sArea, sCity, sState;

    Uri imageUri;
    StorageReference storageReference;
    SharedPreferences sp;
    FirebaseFirestore fStore;

    Bundle bundle;

    FirebaseApp firebaseApp;
    private FirebaseAuth mAuth;
    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks;
    private String sPhone;

    private String EmailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";


    String[] appPermission = {Manifest.permission.READ_EXTERNAL_STORAGE};
    private static final int PERMISSION_REQUEST_CODE = 1240;
    private static final int PICK_IMAGE_REQUEST = 12;
    String sImagePath1 = "";
    String sImagePath2 = "";

    String getImageURL = "";
    double DriverLatitude, DriverLongitude;
    String sFullAddress, sForemanLatitude, sForemanLongitude;

    private static final int REQUEST_LOCATION = 1;
    LocationManager locationManager;

    GPSTracker gpsTracker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_foreman_profile);
        getSupportActionBar().setTitle("Profile");
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#2196F3"));
        getSupportActionBar().setBackgroundDrawable(colorDrawable);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        firebaseApp = FirebaseApp.initializeApp(ForemanProfileActivity.this);
        mAuth = FirebaseAuth.getInstance();

        sp = getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);

        layout1 = findViewById(R.id.foreman_profile_layout1);
        layout2 = findViewById(R.id.foreman_profile_layout2);
        ProfileImage1 = findViewById(R.id.foreman_profile_foremanProfileImage);
        ProfileImage2 = findViewById(R.id.foreman_profile_userProfileImage2);
        FirstName = findViewById(R.id.foreman_profile_FirstName);
        LastName = findViewById(R.id.foreman_profile_LastName);
        Contact = findViewById(R.id.foreman_profile_MobileNumber);
        Email = findViewById(R.id.foreman_profile_Email);
        Address = findViewById(R.id.foreman_profile_Address);
        Area = findViewById(R.id.foreman_profile_Area);
        City = findViewById(R.id.foreman_profile_City);
        State = findViewById(R.id.foreman_profile_State);
        AccountStatus = findViewById(R.id.foreman_profile_AccountStatus);
        FirstName_EditText = findViewById(R.id.foreman_profile_FirstNameEditText);
        LastName_EditText = findViewById(R.id.foreman_profile_LastNameEditText);
        Contact_EditText = findViewById(R.id.foreman_profile_MobileNumberEditText);
        Email_EditText = findViewById(R.id.foreman_profile_EmailEditText);
        Password_EditText = findViewById(R.id.foreman_profile_PasswordEditText);
        Address_EditText = findViewById(R.id.foreman_profile_AddressEditText);
        Area_EditText = findViewById(R.id.foreman_profile_AreaEditText);
        City_EditText = findViewById(R.id.foreman_profile_CityEditText);
        Spinner_State = findViewById(R.id.foreman_profile_SpinnerState);
        EditTextButton = findViewById(R.id.foreman_profile_EditProfileButton);
        UpdateButton = findViewById(R.id.foreman_profile_UpdateButton);
        DeactivateButton1 = findViewById(R.id.foreman_profile_deactivateButton);
        DeactivateButton2 = findViewById(R.id.foreman_profile_deactivateButton2);

        layout2.setVisibility(View.GONE);

        gpsTracker = new GPSTracker(ForemanProfileActivity.this);

        // Check if GPS enabled
        if (gpsTracker.canGetLocation()) {

//            CurrentLatitude = gpsTracker.getLatitude();
//            CurrentLongitude = gpsTracker.getLongitude();

            //  getLocation();

        } else {
            // Can't get location.
            // GPS or network is not enabled.
            // Ask user to enable GPS/network in settings.
            gpsTracker.showSettingsAlert();
        }


        // TODO Get Profile Image
        GetImageSp();
        if (sp.getString(SharedPreferencesData.ProfileImage, "").isEmpty() ||
                sp.getString(SharedPreferencesData.ProfileImage, "").equalsIgnoreCase("") ||
                sp.getString(SharedPreferencesData.ProfileImage, "").equalsIgnoreCase("ProfileImage")) {

        } else {
            Picasso.with(ForemanProfileActivity.this).load(sp.getString(SharedPreferencesData.ProfileImage, "")).placeholder(R.drawable.ic_profile).into(ProfileImage1);
        }
        FirstName.setText(sp.getString(SharedPreferencesData.FirstName, ""));
        LastName.setText(sp.getString(SharedPreferencesData.LastName, ""));
        Contact.setText(sp.getString(SharedPreferencesData.MobileNumber, ""));
        Email.setText(sp.getString(SharedPreferencesData.Email, ""));
        Address.setText(sp.getString(SharedPreferencesData.ForemanAddress, ""));
        Area.setText(sp.getString(SharedPreferencesData.ForemanArea, ""));
        City.setText(sp.getString(SharedPreferencesData.ForemanCity, ""));
        State.setText(sp.getString(SharedPreferencesData.ForemanState, ""));
        AccountStatus.setText(sp.getString(SharedPreferencesData.Account_Status, ""));

        EditTextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                layout2.setVisibility(View.VISIBLE);
                layout1.setVisibility(View.GONE);
            }
        });

        sState = "";
        arrayList = new ArrayList<>();
        arrayList.add("Select State");
        String S_array[] = ConstantData.State;
        List<String> list;
        list = Arrays.asList(S_array);
        arrayList.addAll(list);

        Spinner_State.setSelection(arrayList.indexOf("Select State"));
        ArrayAdapter adapter = new ArrayAdapter(ForemanProfileActivity.this, android.R.layout.simple_list_item_1, arrayList);
        adapter.setDropDownViewResource(android.R.layout.simple_list_item_activated_1);
        Spinner_State.setAdapter(adapter);

        Spinner_State.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                sState = arrayList.get(i);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        UpdateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sFirstName = FirstName_EditText.getText().toString();
                sLastName = LastName_EditText.getText().toString();
                sContact = Contact_EditText.getText().toString();
                sEmail = Email_EditText.getText().toString();
                sPassword = Password_EditText.getText().toString();
                sAddress = Address_EditText.getText().toString();
                sArea = Area_EditText.getText().toString();
                sCity = City_EditText.getText().toString();

                if (sFirstName.isEmpty() || sFirstName.equalsIgnoreCase("")) {
                    FirstName_EditText.setError("FirstName is Required");
                } else if (sLastName.isEmpty() || sLastName.equalsIgnoreCase("")) {
                    LastName_EditText.setError("LastName is Required");
                } else if (sContact.isEmpty() || sContact.equalsIgnoreCase("")) {
                    Contact_EditText.setError("Mobile number is Required");
                } else if (sContact.length() > 10 || sContact.length() < 10) {
                    Contact_EditText.setError("Mobile number is Not valid");
                } else if (sEmail.isEmpty() || sEmail.equalsIgnoreCase("")) {
                    Email_EditText.setError("Email is Required");
                } else if (!sEmail.matches(EmailPattern)) {
                    Email_EditText.setError("Valid Email is Required");
                } else if (sPassword.isEmpty() || sPassword.equalsIgnoreCase("")) {
                    Password_EditText.setError("Password is Required");
                } else if (sPassword.length() < 8) {
                    Password_EditText.setError("Password must be 8 char long");
                } else if (sAddress.isEmpty() || sAddress.equalsIgnoreCase("")) {
                    Address_EditText.setError("Address is Required");
                } else if (sArea.isEmpty() || sArea.equalsIgnoreCase("")) {
                    Area_EditText.setError("Area is Required");
                } else if (sCity.isEmpty() || sCity.equalsIgnoreCase("")) {
                    City_EditText.setError("City is Required");
                } else if (sState.isEmpty() || sState.equalsIgnoreCase("")) {
                    new CommonMethod(ForemanProfileActivity.this, "State is Required");
                } else if (sState.equalsIgnoreCase("Select State")) {
                    new CommonMethod(ForemanProfileActivity.this, "Not Valid State");
                } else {

                    UpdateSPProfileLocationData();
                    UpdateUserProfileImageData();
                    sp.edit().putString(SharedPreferencesData.ProfileImage, sImagePath2).commit();
                    UpdateUserProfileData();
                    UpdateUserPassword();

                }

            }
        });



        ProfileImage2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (checkAndRequestPermission()) {
                    selectImageMethod(view);
                }
            }
        });

        DeactivateButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                DeactivateUserAccount();
            }
        });

        DeactivateButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                DeactivateUserAccount();
            }
        });

    }

    private void UpdateSPProfileLocationData() {

        String FullAddress = sp.getString(SharedPreferencesData.ForemanAddress, "") + "," + sp.getString(SharedPreferencesData.ForemanArea, "") + "," + sp.getString(SharedPreferencesData.ForemanCity, "") + "," + sp.getString(SharedPreferencesData.ForemanState, "");
        Geocoder coder = new Geocoder(ForemanProfileActivity.this);
        List<android.location.Address> address;
        try {
            // May throw an IOException
            address = coder.getFromLocationName(FullAddress, 5);
            if (address == null) {
                DriverLatitude = 0.00;
                DriverLongitude = 0.00;
            }
            Address location = address.get(0);

            DriverLatitude = location.getLatitude();
            DriverLongitude = location.getLongitude();
            //p1 = new LatLng(location.getLatitude(), location.getLongitude() );

        } catch (IOException ex) {

            ex.printStackTrace();
        }


        sForemanLatitude = String.valueOf(DriverLatitude);
        sForemanLongitude = String.valueOf(DriverLongitude);


    }


    // Todo Get Profile Image From Shared Preference
    private void GetImageSp() {
        String encodedSaveImage = sp.getString(SharedPreferencesData.ProfileImage, "");
        byte[] decodedString = Base64.decode(encodedSaveImage, Base64.DEFAULT);
        Bitmap decodeBitmap = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        if (decodeBitmap != null) {
            ProfileImage1.setImageBitmap(decodeBitmap);
            //new CommonMethod(getActivity(), "Image Got from Sp");
        } else {
            getUserImage();
        }
    }

    // Todo Get Profile Image from Firebase
    private void getUserImage() {
        storageReference = FirebaseStorage.getInstance().getReference("images/userprofile/" + sp.getString(SharedPreferencesData.UserID, "") + ".jpg");
        try {
            File localfile = File.createTempFile("tempfile", ".jpg");
            storageReference.getFile(localfile).addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                    //new CommonMethod(getActivity(), "Image Downloaded");
                    Bitmap bitmap1 = BitmapFactory.decodeFile(localfile.getAbsolutePath());
                    ProfileImage1.setImageBitmap(bitmap1);

                    SaveImageSp();// Save Image to Sp
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    //new CommonMethod(getActivity(), "Image Not Downloaded");
                    ProfileImage1.setImageResource(R.drawable.ic_profile);//default image
                }

            });
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    // Todo Save Image to Shared Preference
    private void SaveImageSp() {
        BitmapDrawable bitmapDrawable = (BitmapDrawable) ProfileImage1.getDrawable();
        Bitmap bitmap = bitmapDrawable.getBitmap();

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream);
        byte[] byteArray = outputStream.toByteArray();
        String encodedImage = Base64.encodeToString(byteArray, Base64.DEFAULT);

        sp.edit().putString(SharedPreferencesData.ProfileImage, encodedImage).apply();

        //new CommonMethod(getActivity(), "Image saved to shared preference");
    }

    // Todo Update Profile Image
    private void UpdateUserProfileImageData() {
        // Todo Delete Old Image
        storageReference = FirebaseStorage.getInstance().getReference("images/userprofile/" + sp.getString(SharedPreferencesData.UserID, "") + ".jpg");
        storageReference.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                //new CommonMethod(getActivity(), "Image Deleted");
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                //new CommonMethod(getActivity(), "Image Not Deleted");
            }
        });
        // Todo Upload New Image
        storageReference = FirebaseStorage.getInstance().getReference("images/userprofile/" + sp.getString(SharedPreferencesData.UserID, "") + ".jpg");
        storageReference.putFile(imageUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                //new CommonMethod(getActivity(), "Image Uploaded");
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                //new CommonMethod(getActivity(), "Image Not Uploaded");
            }
        });
    }

    private void DeactivateUserAccount() {


    }


    private void UpdateUserProfileData() {
        sp.edit().putString(SharedPreferencesData.FirstName, sFirstName).commit();
        sp.edit().putString(SharedPreferencesData.LastName, sLastName).commit();
        sp.edit().putString(SharedPreferencesData.MobileNumber, sContact).commit();
        sp.edit().putString(SharedPreferencesData.Email, sEmail).commit();
        sp.edit().putString(SharedPreferencesData.Password, sPassword).commit();
        sp.edit().putString(SharedPreferencesData.ForemanAddress, sAddress).commit();
        sp.edit().putString(SharedPreferencesData.ForemanArea, sArea).commit();
        sp.edit().putString(SharedPreferencesData.ForemanCity, sCity).commit();
        sp.edit().putString(SharedPreferencesData.ForemanState, sState).commit();

        FirstName.setText(sp.getString(SharedPreferencesData.FirstName, ""));
        LastName.setText(sp.getString(SharedPreferencesData.LastName, ""));
        Contact.setText(sp.getString(SharedPreferencesData.MobileNumber, ""));
        Email.setText(sp.getString(SharedPreferencesData.Email, ""));
        Address.setText(sp.getString(SharedPreferencesData.ForemanAddress, ""));
        Area.setText(sp.getString(SharedPreferencesData.ForemanArea, ""));
        City.setText(sp.getString(SharedPreferencesData.ForemanCity, ""));
        State.setText(sp.getString(SharedPreferencesData.ForemanState, ""));
        AccountStatus.setText(sp.getString(SharedPreferencesData.Account_Status, ""));

        String userID = Objects.requireNonNull(mAuth.getCurrentUser()).getUid();
        DocumentReference documentReference = fStore.collection("Users").document(userID);
        Map<String, Object> user = new HashMap<>();
        user.put("FirstName", sp.getString(SharedPreferencesData.FirstName, ""));
        user.put("LastName", sp.getString(SharedPreferencesData.LastName, ""));
        user.put("MobileNumber", sp.getString(SharedPreferencesData.MobileNumber, ""));
        user.put("Email", sp.getString(SharedPreferencesData.Email, ""));
        user.put("ForemanAddress", sp.getString(SharedPreferencesData.ForemanAddress, ""));
        user.put("ForemanArea", sp.getString(SharedPreferencesData.ForemanArea, ""));
        user.put("ForemanCity", sp.getString(SharedPreferencesData.ForemanCity, ""));
        user.put("ForemanState", sp.getString(SharedPreferencesData.ForemanState, ""));
        user.put("sForemanLatitude", sForemanLatitude);
        user.put("sForemanLongitude", sForemanLongitude);
        user.put("Account_Status", "Verified");
        documentReference.update(user).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                Log.d("Information Updated","Information Updated");


            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.d("Information Not Updated","Information Not Updated");
            }
        });


    }


    private void otpSendToMobile(String sPhone) {

        mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

            @Override
            public void onVerificationCompleted(PhoneAuthCredential credential) {

            }

            @Override
            public void onVerificationFailed(FirebaseException e) {

                new CommonMethod(ForemanProfileActivity.this, e.getLocalizedMessage());
            }

            @Override
            public void onCodeSent(@NonNull String VerificationId,
                                   @NonNull PhoneAuthProvider.ForceResendingToken token) {


                new CommonMethod(ForemanProfileActivity.this, "OTP is successFully Send");


                bundle.putString("PhoneNumber", sPhone.trim());
                bundle.putString("Mobile_VerificationID", VerificationId);
                Intent intent = new Intent(ForemanProfileActivity.this, OTPVerificationActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        };

        PhoneAuthOptions options =
                PhoneAuthOptions.newBuilder(mAuth)
                        .setPhoneNumber("+880" + sPhone.trim())
                        .setTimeout(60L, TimeUnit.SECONDS)
                        .setActivity(ForemanProfileActivity.this)
                        .setCallbacks(mCallbacks)
                        .build();
        PhoneAuthProvider.verifyPhoneNumber(options);

    }
    // Todo Update Password
    private void UpdateUserPassword() {
        Objects.requireNonNull(mAuth.getCurrentUser()).updatePassword(sPassword);
    }

    private void selectImageMethod(View view) {
        Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
        photoPickerIntent.setType("image/*");
        someActivityResultLauncher.launch(photoPickerIntent);
    }
    ActivityResultLauncher<Intent> someActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    // There are no request codes
                    // doSomeOperations();
                    Intent data = result.getData();
                    imageUri = Objects.requireNonNull(data).getData();
                    Log.d("RESPONSE_URI", String.valueOf(imageUri));
                    ProfileImage2.setImageURI(imageUri);
                }
            });

    public boolean checkAndRequestPermission() {
        List<String> listPermission = new ArrayList<>();
        for (String perm : appPermission) {
            if (ContextCompat.checkSelfPermission(ForemanProfileActivity.this, perm) != PackageManager.PERMISSION_GRANTED) {
                listPermission.add(perm);
            }
        }
        if (!listPermission.isEmpty()) {
            ActivityCompat.requestPermissions(ForemanProfileActivity.this, listPermission.toArray(new String[listPermission.size()]), PERMISSION_REQUEST_CODE);
            return false;
        }
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

}