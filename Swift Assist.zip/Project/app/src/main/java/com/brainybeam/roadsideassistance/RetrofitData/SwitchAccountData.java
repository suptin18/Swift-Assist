package com.brainybeam.roadsideassistance.RetrofitData;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SwitchAccountData {

    @SerializedName("Message")
    @Expose
    public String message;

}
