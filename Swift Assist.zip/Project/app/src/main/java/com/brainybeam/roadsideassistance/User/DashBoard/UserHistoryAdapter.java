package com.brainybeam.roadsideassistance.User.DashBoard;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.brainybeam.roadsideassistance.Foreman.DashBoard.ForemanHistoryAdapter;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.User.CustomArrayList.UserHistoryList;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class UserHistoryAdapter extends RecyclerView.Adapter<UserHistoryAdapter.MyHolder> {

    Context context;
    ArrayList<UserHistoryList> arrayList;

    SharedPreferences sp;
    ProgressDialog pd;

    String shistoryID;
    int iPosition;

    public UserHistoryAdapter(Context context, ArrayList<UserHistoryList> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_user_history, parent, false);

        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, @SuppressLint("RecyclerView") int position) {

        holder.ForemanID.setText(arrayList.get(position).getUserID());

//        if (arrayList.get(position).getForemanProfileImage().isEmpty() || arrayList.get(position).getForemanProfileImage().equalsIgnoreCase("")){
//            holder.ForemanProfileImageView.setVisibility(View.GONE);
//        } else {
//            Picasso.with(context).load(arrayList.get(position).getForemanProfileImage()).placeholder(R.drawable.ic_foreman).into(holder.ForemanProfileImageView);
//        }

        if(sp.getString(SharedPreferencesData.ProfileImage, "").equalsIgnoreCase("https://project.000webhostapp.com/RoadSideAssistance/ForemanImages/")){

        } else {
            Picasso.with(context).load(sp.getString(SharedPreferencesData.ProfileImage, "")).placeholder(R.drawable.ic_foreman).into(holder.ForemanProfileImageView);
        }



        holder.Calling_imageLogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("Call to Foreman "+arrayList.get(position).getForemanFirstName()+"?");
                builder.setPositiveButton("CALL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent = new Intent(Intent.ACTION_CALL);
                        intent.setData(Uri.parse("tel:"+"+880"+arrayList.get(position).getForemanMobileNumber()));
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            if (context.checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                                // TODO: Consider calling
                                //    Activity#requestPermissions
                                // here to request the missing permissions, and then overriding
                                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                //                                          int[] grantResults)
                                // to handle the case where the user grants the permission. See the documentation
                                // for Activity#requestPermissions for more details.
                                return;
                            }
                        }
                        context.startActivity(intent);
                    }
                });

                builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                });
                builder.show();

            }
        });

        holder.Name.setText(arrayList.get(position).getForemanFirstName()+" "+arrayList.get(position).getForemanLastName());
        holder.MobileNumber.setText("+880 "+arrayList.get(position).getForemanMobileNumber());
        holder.TypeOfProblem.setText(arrayList.get(position).getTypeOfProblem());
        holder.ProblemSubType.setText(arrayList.get(position).getProblemSubType());
        holder.Payment.setText("৳ "+arrayList.get(position).getPayment());
        holder.PaymentMode.setText(arrayList.get(position).getPaymentMode());
        holder.UserLocation.setText(arrayList.get(position).getUserLocation());
        holder.PaymentDate.setText(arrayList.get(position).getPaymentDate());

        holder.VehicleNumber.setText(arrayList.get(position).getVehicleNumber());
        holder.TypeOfVehicle.setText(arrayList.get(position).getTypeOfVehicle());
        holder.ModelName.setText(arrayList.get(position).getVehicleModelName());


        holder.DeleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                shistoryID = arrayList.get(position).getHistoryID();
                iPosition = position;
                arrayList.remove(iPosition);
                notifyDataSetChanged();
            }
        });

    }


    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder {

        CircleImageView ForemanProfileImageView;
        ImageView Calling_imageLogo;
        TextView ForemanID;
        TextView Name, MobileNumber, TypeOfProblem, ProblemSubType, Payment, PaymentMode, UserLocation, PaymentDate;

        TextView VehicleNumber, TypeOfVehicle, ModelName;

        Button DeleteButton;
        
        public MyHolder(@NonNull View itemView) {
            super(itemView);

            sp = context.getSharedPreferences(SharedPreferencesData.PREF, Context.MODE_PRIVATE);

            ForemanID = itemView.findViewById(R.id.custom_user_history_ForemanID);
            ForemanProfileImageView = itemView.findViewById(R.id.custom_user_history_ForemanProfileImage);
            Calling_imageLogo = itemView.findViewById(R.id.custom_user_history_calling_Image_logo);

            Name = itemView.findViewById(R.id.custom_user_history_FirstANDLastName);
            MobileNumber = itemView.findViewById(R.id.custom_user_history_MobileNumber);
            TypeOfProblem = itemView.findViewById(R.id.custom_user_history_TypeOfProblem);
            ProblemSubType = itemView.findViewById(R.id.custom_user_history_problemSubType);
            Payment = itemView.findViewById(R.id.custom_user_history_Payment);
            PaymentMode = itemView.findViewById(R.id.custom_user_history_PaymentMode);
            UserLocation = itemView.findViewById(R.id.custom_user_history_UserLocation);
            PaymentDate = itemView.findViewById(R.id.custom_user_history_PaymentDate);

            VehicleNumber = itemView.findViewById(R.id.custom_user_history_VehicleNumber);
            TypeOfVehicle = itemView.findViewById(R.id.custom_user_history_TypeOfVehicle);
            ModelName = itemView.findViewById(R.id.custom_user_history_ModelName);

            DeleteButton = itemView.findViewById(R.id.custom_user_history_DeleteButton);
            
        }
    }

}
