package com.brainybeam.roadsideassistance.Foreman.DashBoard;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.brainybeam.roadsideassistance.Foreman.Activity.ForemanHomeAddServicesActivity;
import com.brainybeam.roadsideassistance.Foreman.Activity.ForemanHomeHistoryActivity;
import com.brainybeam.roadsideassistance.Foreman.Activity.ForemanHomeNewRequestActivity;
import com.brainybeam.roadsideassistance.Foreman.Activity.ForemanHomePendingPaymentActivity;
import com.brainybeam.roadsideassistance.Foreman.Activity.ForemanProfileActivity;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;


public class ForemanHomeFragment extends Fragment {

    RelativeLayout relativeLayout;
    CardView cardView;

    LinearLayout frag_foreman_home_Profile_layout, frag_foreman_home_AddServices_layout, frag_foreman_home_NewRequest_layout, frag_foreman_home_History_layout, frag_foreman_home_PendingPayment_layout;

    ImageView frag_foreman_home_Profile_image_logo, frag_foreman_home_AddServices_image_logo, frag_foreman_home_NewRequest_image_logo, frag_foreman_home_History_image_logo, frag_foreman_home_PendingPayment_image_logo;

    TextView frag_foreman_home_Profile_TextButton, frag_foreman_home_AddServices_TextButton, frag_foreman_home_NewRequest_TextButton, frag_foreman_home_History_TextButton, frag_foreman_home_PendingPayment_TextButton;


    SharedPreferences sp;

    public ForemanHomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_foreman_home, container, false);

        sp = requireActivity().getSharedPreferences(SharedPreferencesData.PREF, Context.MODE_PRIVATE);

        relativeLayout = view.findViewById(R.id.frag_foreman_home_RelativeLayout);
        cardView = view.findViewById(R.id.frag_foreman_home_CardViewNotAcceptedForeman);

        frag_foreman_home_Profile_layout = view.findViewById(R.id.frag_foreman_home_profile_layout);
        frag_foreman_home_AddServices_layout = view.findViewById(R.id.frag_foreman_home_AddServices_layout);
        frag_foreman_home_NewRequest_layout = view.findViewById(R.id.frag_foreman_home_NewRequests_layout);
        frag_foreman_home_History_layout = view.findViewById(R.id.frag_foreman_home_history_layout);
        frag_foreman_home_PendingPayment_layout = view.findViewById(R.id.frag_foreman_home_pendingPayment_layout);

        frag_foreman_home_Profile_image_logo = view.findViewById(R.id.frag_foreman_home_profile_image_logo);
        frag_foreman_home_AddServices_image_logo = view.findViewById(R.id.frag_foreman_home_AddServices_image_logo);
        frag_foreman_home_NewRequest_image_logo = view.findViewById(R.id.frag_foreman_home_NewRequests_image_logo);
        frag_foreman_home_History_image_logo = view.findViewById(R.id.frag_foreman_home_history_image_logo);
        frag_foreman_home_PendingPayment_image_logo = view.findViewById(R.id.frag_foreman_home_pendingPayment_image_logo);

        frag_foreman_home_Profile_TextButton = view.findViewById(R.id.frag_foreman_home_profile_text);
        frag_foreman_home_AddServices_TextButton = view.findViewById(R.id.frag_foreman_home_AddServices_text);
        frag_foreman_home_NewRequest_TextButton = view.findViewById(R.id.frag_foreman_home_NewRequests_text);
        frag_foreman_home_History_TextButton = view.findViewById(R.id.frag_foreman_home_history_Text);
        frag_foreman_home_PendingPayment_TextButton = view.findViewById(R.id.frag_foreman_home_pendingPayment_text);


        relativeLayout.setVisibility(View.VISIBLE);
        cardView.setVisibility(View.GONE);

        ValidForemanCheck();

        // TODO home Foreman Profile
        frag_foreman_home_Profile_TextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CommonMethod(getActivity(), ForemanProfileActivity.class);
            }
        });

        frag_foreman_home_Profile_image_logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CommonMethod(getActivity(), ForemanProfileActivity.class);
            }
        });

        frag_foreman_home_Profile_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CommonMethod(getActivity(), ForemanProfileActivity.class);
            }
        });


        // TODO Add Services
        frag_foreman_home_AddServices_TextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CommonMethod(getActivity(), ForemanHomeAddServicesActivity.class);
            }
        });

        frag_foreman_home_AddServices_image_logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CommonMethod(getActivity(), ForemanHomeAddServicesActivity.class);
            }
        });

        frag_foreman_home_AddServices_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CommonMethod(getActivity(), ForemanHomeAddServicesActivity.class);
            }
        });

        // TODO New Services
        frag_foreman_home_NewRequest_TextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CommonMethod(getActivity(), ForemanHomeNewRequestActivity.class);
            }
        });

        frag_foreman_home_NewRequest_image_logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CommonMethod(getActivity(), ForemanHomeNewRequestActivity.class);
            }
        });

        frag_foreman_home_NewRequest_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CommonMethod(getActivity(), ForemanHomeNewRequestActivity.class);
            }
        });

        // TODO Foreman History
        frag_foreman_home_History_TextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CommonMethod(getActivity(), ForemanHomeHistoryActivity.class);
            }
        });

        frag_foreman_home_History_image_logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CommonMethod(getActivity(), ForemanHomeHistoryActivity.class);
            }
        });

        frag_foreman_home_History_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CommonMethod(getActivity(), ForemanHomeHistoryActivity.class);
            }
        });

        // TODO Payment Pending
        frag_foreman_home_PendingPayment_TextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CommonMethod(getActivity(), ForemanHomePendingPaymentActivity.class);
            }
        });

        frag_foreman_home_PendingPayment_image_logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CommonMethod(getActivity(), ForemanHomePendingPaymentActivity.class);
            }
        });

        frag_foreman_home_PendingPayment_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CommonMethod(getActivity(), ForemanHomePendingPaymentActivity.class);
            }
        });

        return view;
    }

    private void ValidForemanCheck() {

        if (sp.getBoolean(SharedPreferencesData.ForemanAccount_Status, false)) {
            relativeLayout.setVisibility(View.VISIBLE);
            cardView.setVisibility(View.GONE);
        } else {
            new CommonMethod(getActivity(), "Your Account Not Accepted");
            new CommonMethod(getActivity(), "Please Wait...");
            relativeLayout.setVisibility(View.GONE);
            cardView.setVisibility(View.VISIBLE);
        }
    }

}