package com.brainybeam.roadsideassistance;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import com.brainybeam.roadsideassistance.Admin.DashBoard.AdminDashboardActivity;
import com.brainybeam.roadsideassistance.Foreman.Activity.ForemanEnableActivity;
import com.brainybeam.roadsideassistance.Foreman.DashBoard.ForemanDashboardActivity;
import com.brainybeam.roadsideassistance.Login.LoginActivity;
import com.brainybeam.roadsideassistance.User.DashBoard.UserDashboardActivity;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;

import java.util.Objects;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainActivity extends AppCompatActivity {

    private CircleImageView mainImage;
    private ImageView startImage, bikeImage;
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Objects.requireNonNull(getSupportActionBar()).hide();

        sp = getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);

        mainImage = findViewById(R.id.main_mainIcan);
        startImage = findViewById(R.id.main_starting_ican);
        bikeImage = findViewById(R.id.main_starting_ican2);

        AlphaAnimation alphaAnimation1 = new AlphaAnimation(10, 90);
        alphaAnimation1.setDuration(200);
        mainImage.setAnimation(alphaAnimation1);

        AlphaAnimation alphaAnimation = new AlphaAnimation(0, 50);
        startImage.setAnimation(alphaAnimation);

        Animation animation = AnimationUtils.loadAnimation(MainActivity.this, R.anim.translate);
        bikeImage.setAnimation(animation);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                if(sp.getString(SharedPreferencesData.UserID, "").isEmpty() || sp.getString(SharedPreferencesData.UserID, "").equalsIgnoreCase("")){
                    new CommonMethod(MainActivity.this, LoginActivity.class);
                    finish();
                } else {
                    if(sp.getString(SharedPreferencesData.UserType, "").equalsIgnoreCase("User")){
                        new CommonMethod(MainActivity.this, UserDashboardActivity.class);
                    } else if (sp.getString(SharedPreferencesData.UserType, "").equalsIgnoreCase("Foreman")){
                        new CommonMethod(MainActivity.this, ForemanDashboardActivity.class);
                    } else if(sp.getString(SharedPreferencesData.ForemanEnable, "").equalsIgnoreCase("ForemanEnable")){
                        new CommonMethod(MainActivity.this, ForemanEnableActivity.class);
                    } else if(sp.getString(SharedPreferencesData.AdminLoginState, "").equalsIgnoreCase("AdminLogin")){
                        new CommonMethod(MainActivity.this, AdminDashboardActivity.class);
                    } else{
                        new CommonMethod(MainActivity.this, LoginActivity.class);
                    }

                    finish();
                }
            }
        }, 500);


    }
}