package com.brainybeam.roadsideassistance.OTPVerification;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.brainybeam.roadsideassistance.Login.LoginActivity;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConnectionDetector;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;


public class OTPVerificationActivity extends AppCompatActivity {

    //Mobile
    LinearLayout Mobile_linearlayout;
    TextView MobileNumberView;
    EditText Mobile_OTP1, Mobile_OTP2, Mobile_OTP3, Mobile_OTP4, Mobile_OTP5, Mobile_OTP6;
    TextView Mobile_OTP_ResendButton;
    Button Mobile_OTP_Verify;

    //Email
    LinearLayout Email_linearlayout;
    TextView EmailView;
    TextView Email_OTP_ResendButton;
    Button Email_OTP_Verify;


    FirebaseAuth mAuth;
    FirebaseApp firebaseApp;
    FirebaseFirestore fStore;
    private String Mobile_VerificationID;
    private SharedPreferences sp;

    String sMail, sPassword;
    int count = 0;

    double DriverLatitude, DriverLongitude;
    String sForemanLatitude;
    String sForemanLongitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otpverification);

        firebaseApp = FirebaseApp.initializeApp(getApplicationContext());
        mAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        sp = getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);


        Bundle bundle = getIntent().getExtras();

        // TODO Mobile Number
        Mobile_linearlayout = findViewById(R.id.MobileOTP_linearlayout);
        MobileNumberView = findViewById(R.id.MobileNumberView);
        Mobile_OTP1 = findViewById(R.id.Mobile_otp1);
        Mobile_OTP2 = findViewById(R.id.Mobile_otp2);
        Mobile_OTP3 = findViewById(R.id.Mobile_otp3);
        Mobile_OTP4 = findViewById(R.id.Mobile_otp4);
        Mobile_OTP5 = findViewById(R.id.Mobile_otp5);
        Mobile_OTP6 = findViewById(R.id.Mobile_otp6);
        Mobile_OTP_ResendButton = findViewById(R.id.Mobile_Resend_OTP_TextButton);
        Mobile_OTP_Verify = findViewById(R.id.Mobile_OTP_Verify_VerifyButton);

        assert bundle != null;
        String sMobileNumber = "+880" + bundle.getString("PhoneNumber");
        MobileNumberView.setText(sMobileNumber);
        Mobile_VerificationID = bundle.getString("Mobile_VerificationID");

        // TODO Email
        Email_linearlayout = findViewById(R.id.EmailOTP_linearlayout);
        EmailView = findViewById(R.id.EmailView);
        Email_linearlayout.setVisibility(View.GONE);

        Email_OTP_ResendButton = findViewById(R.id.Email_Resend_OTP_TextButton);
        Email_OTP_Verify = findViewById(R.id.Email_OTP_Verify_VerifyButton);

        // TODO To Sending OTP in Mobile Number
        Mobile_InputOTPInEditTextField();

        Mobile_OTP_ResendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CommonMethod(OTPVerificationActivity.this, "OTP Send SuccessFully");
                otpSendToMobile(Objects.requireNonNull(bundle.getString("PhoneNumber")));
            }
        });

        Mobile_OTP_Verify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (new ConnectionDetector(OTPVerificationActivity.this).isConnectingToInternet()) {
                    // TODO Mobile OTP Verify
                    MobileOTP_Validity_Check();
                    if (count == 2) {
                        FullyVerify();
                    }
                } else {
                    new ConnectionDetector(OTPVerificationActivity.this).connectiondetect();
                }

            }
        });


        // TODO To Sending OTP in Email
        sMail = sp.getString(SharedPreferencesData.Email, "");
        EmailView.setText(sMail);
        sPassword = sp.getString(SharedPreferencesData.Password, "");

        // TODO Email OTP Send
        //otpSendToEmail(sMail);


        Email_OTP_Verify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (new ConnectionDetector(OTPVerificationActivity.this).isConnectingToInternet()) {

                    EmailVerify();

                    if (count == 2) {
                        FullyVerify();
                    }

                } else {
                    new ConnectionDetector(OTPVerificationActivity.this).connectiondetect();
                }
            }
        });


    }

    private void FullyVerify() {
        if (sp.getString(SharedPreferencesData.UserType, "").equalsIgnoreCase("User")) {
            String userID = Objects.requireNonNull(mAuth.getCurrentUser()).getUid();
            DocumentReference documentReference = fStore.collection("Users").document(userID);
            Map<String, Object> user = new HashMap<>();
            user.put("UserType", sp.getString(SharedPreferencesData.UserType, ""));
            user.put("FirstName", sp.getString(SharedPreferencesData.FirstName, ""));
            user.put("LastName", sp.getString(SharedPreferencesData.LastName, ""));
            user.put("MobileNumber", sp.getString(SharedPreferencesData.MobileNumber, ""));
            user.put("Email", sp.getString(SharedPreferencesData.Email, ""));
            user.put("Password", sp.getString(SharedPreferencesData.Password, ""));
            user.put("Active_Status", sp.getBoolean(SharedPreferencesData.Active_Status, true));
            user.put("Account_Status", "Verified");
            documentReference.set(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void aVoid) {
                    Toast.makeText(OTPVerificationActivity.this, "Sign Up Successful", Toast.LENGTH_SHORT).show();
                    Log.d("TAG", "onSuccess: User Profile is Created for " + userID);
                }

            });
            new CommonMethod(OTPVerificationActivity.this, LoginActivity.class);
            finish();
        } else if (sp.getString(SharedPreferencesData.UserType, "").equalsIgnoreCase("Foreman")) {
            AddSPProfileLocationData();
            String userID = Objects.requireNonNull(mAuth.getCurrentUser()).getUid();
            DocumentReference documentReference = fStore.collection("Users").document(userID);
            Map<String, Object> user = new HashMap<>();
            user.put("UserType", sp.getString(SharedPreferencesData.UserType, ""));
            user.put("FirstName", sp.getString(SharedPreferencesData.FirstName, ""));
            user.put("LastName", sp.getString(SharedPreferencesData.LastName, ""));
            user.put("MobileNumber", sp.getString(SharedPreferencesData.MobileNumber, ""));
            user.put("Email", sp.getString(SharedPreferencesData.Email, ""));
            user.put("Password", sp.getString(SharedPreferencesData.Password, ""));
            user.put("ForemanAddress", sp.getString(SharedPreferencesData.ForemanAddress, ""));
            user.put("ForemanArea", sp.getString(SharedPreferencesData.ForemanArea, ""));
            user.put("ForemanCity", sp.getString(SharedPreferencesData.ForemanCity, ""));
            user.put("ForemanState", sp.getString(SharedPreferencesData.ForemanState, ""));
            user.put("ForemanAccount_Status", sp.getBoolean(SharedPreferencesData.ForemanAccount_Status, false));
            user.put("sForemanLatitude", sForemanLatitude);
            user.put("sForemanLongitude", sForemanLongitude);
            user.put("Account_Status", "Verified");


            documentReference.set(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void aVoid) {
                    Toast.makeText(OTPVerificationActivity.this, "Sign Up Successful", Toast.LENGTH_SHORT).show();
                    Log.d("TAG", "onSuccess: User Profile is Created for " + userID);
                }

            });
            new CommonMethod(OTPVerificationActivity.this, LoginActivity.class);
            finish();

        } else {
            new CommonMethod(OTPVerificationActivity.this, "Not Valid Try Again");
        }

    }

    private void AddSPProfileLocationData() {

        String FullAddress = sp.getString(SharedPreferencesData.ForemanAddress, "") + "," + sp.getString(SharedPreferencesData.ForemanArea, "") + "," + sp.getString(SharedPreferencesData.ForemanCity, "") + "," + sp.getString(SharedPreferencesData.ForemanState, "");
        Geocoder coder = new Geocoder(OTPVerificationActivity.this);
        List<Address> address;
        try {
            // May throw an IOException
            address = coder.getFromLocationName(FullAddress, 5);
            if (address == null) {
                DriverLatitude = 0.00;
                DriverLongitude = 0.00;
            }
            assert address != null;
            Address location = address.get(0);

            DriverLatitude = location.getLatitude();
            DriverLongitude = location.getLongitude();
            //p1 = new LatLng(location.getLatitude(), location.getLongitude() );

        } catch (IOException ex) {

            ex.printStackTrace();
        }
        sForemanLatitude = String.valueOf(DriverLatitude);
        sForemanLongitude = String.valueOf(DriverLongitude);
    }


    private void Mobile_InputOTPInEditTextField() {
        Mobile_OTP1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                Mobile_OTP2.requestFocus();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        Mobile_OTP2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                Mobile_OTP3.requestFocus();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        Mobile_OTP3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                Mobile_OTP4.requestFocus();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        Mobile_OTP4.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                Mobile_OTP5.requestFocus();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        Mobile_OTP5.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                Mobile_OTP6.requestFocus();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private void MobileOTP_Validity_Check() {

        if (Mobile_OTP1.getText().toString().trim().isEmpty() ||
                Mobile_OTP2.getText().toString().trim().isEmpty() ||
                Mobile_OTP3.getText().toString().trim().isEmpty() ||
                Mobile_OTP4.getText().toString().trim().isEmpty() ||
                Mobile_OTP5.getText().toString().trim().isEmpty() ||
                Mobile_OTP6.getText().toString().trim().isEmpty()) {


            new CommonMethod(OTPVerificationActivity.this, "Mobile_OTP is not Valid!");

        } else {

            if (Mobile_VerificationID != null) {
                String code = Mobile_OTP1.getText().toString().trim() +
                        Mobile_OTP2.getText().toString().trim() +
                        Mobile_OTP3.getText().toString().trim() +
                        Mobile_OTP4.getText().toString().trim() +
                        Mobile_OTP5.getText().toString().trim() +
                        Mobile_OTP6.getText().toString().trim();

                PhoneAuthCredential credential = PhoneAuthProvider.getCredential(Mobile_VerificationID, code);

                FirebaseAuth
                        .getInstance()
                        .signInWithCredential(credential)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull @NotNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    new CommonMethod(OTPVerificationActivity.this, "Mobile Number Verified");
                                    count = count + 1;

                                    AuthCredential credential = EmailAuthProvider.getCredential(sMail, sPassword);
                                    link_email(credential);
                                    Mobile_linearlayout.setVisibility(View.GONE);
                                    Email_linearlayout.setVisibility(View.VISIBLE);
                                    if (count == 2) {
                                        FullyVerify();
                                    }
                                } else {
                                    new CommonMethod(OTPVerificationActivity.this, "OTP is not Valid!");
                                }
                            }
                        });
            }
        }

    }

    private void link_email(AuthCredential credential) {
        mAuth.getCurrentUser().linkWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            new CommonMethod(OTPVerificationActivity.this, "linkWithCredential:success");
                            FirebaseUser user = task.getResult().getUser();
                            otpSendToEmail(sMail);
                        } else {
                            new CommonMethod(OTPVerificationActivity.this, "Authentication failed.");
                        }
                    }
                });
    }


    private void otpSendToEmail(String sMail) {
        // TODO Sign in success, update UI with the signed-in user's information
        FirebaseUser user = mAuth.getCurrentUser();
        if (user != null) {
            user.sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful()) {
                        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(OTPVerificationActivity.this);
                        // set title
                        alertDialogBuilder.setTitle("Please Verify Your EmailID");

                        // set dialog message
                        alertDialogBuilder.setMessage("A verification Email Is Sent To Your Registered EmailID, please click on the link and Sign in again!")
                                .setCancelable(false)
                                .setPositiveButton("Sign In", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {

                                    }
                                });
                        // create alert dialog
                        AlertDialog alertDialog = alertDialogBuilder.create();
                        // show it
                        alertDialog.show();

                    }
                }
            });
        }

    }

    public void EmailVerify() {

        mAuth.signInWithEmailAndPassword(sp.getString(SharedPreferencesData.Email, ""), sp.getString(SharedPreferencesData.Password, "")).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    if (Objects.requireNonNull(mAuth.getCurrentUser()).isEmailVerified()) {
                        new CommonMethod(OTPVerificationActivity.this, "Email is Verified");
                        count = count + 1;
                        Email_linearlayout.setVisibility(View.GONE);
                        if (count == 2) {
                            FullyVerify();
                        }
                    } else {
                        new CommonMethod(OTPVerificationActivity.this, "Email is Not Verified");
                    }
                }
            }
        });

    }


    private void otpSendToMobile(String sPhone) {

        PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

            @Override
            public void onVerificationCompleted(@NonNull PhoneAuthCredential credential) {

            }

            @Override
            public void onVerificationFailed(FirebaseException e) {

                new CommonMethod(OTPVerificationActivity.this, e.getLocalizedMessage());
            }

            @Override
            public void onCodeSent(@NonNull String VerificationId,
                                   @NonNull PhoneAuthProvider.ForceResendingToken token) {


                new CommonMethod(OTPVerificationActivity.this, "OTP is successFully Send");

            }
        };

        PhoneAuthOptions options =
                PhoneAuthOptions.newBuilder(mAuth)
                        .setPhoneNumber("+880" + sPhone.trim())
                        .setTimeout(60L, TimeUnit.SECONDS)
                        .setActivity(this)
                        .setCallbacks(mCallbacks)
                        .build();
        PhoneAuthProvider.verifyPhoneNumber(options);

    }


}