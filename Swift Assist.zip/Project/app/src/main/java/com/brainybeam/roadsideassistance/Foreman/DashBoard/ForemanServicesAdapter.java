package com.brainybeam.roadsideassistance.Foreman.DashBoard;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.RecyclerView;

import com.brainybeam.roadsideassistance.Foreman.CustomArrayList.ServiceListData;
import com.brainybeam.roadsideassistance.GPS.GPSTracker;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.AddForemanServicesData;
import com.brainybeam.roadsideassistance.User.Activity.UserForemanServicesActivity;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConstantData;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;
import com.squareup.picasso.Picasso;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ForemanServicesAdapter extends RecyclerView.Adapter<ForemanServicesAdapter.MyHolder> {

    Context context;
    ArrayList<ServiceListData> arrayList_forRecyclerView;
    //ApiInterface apiInterface;
    SharedPreferences sp;

    int sPosition;

    double DriverLatitude, DriverLongitude;

    public ForemanServicesAdapter(Context context, ArrayList<ServiceListData> arrayList_forRecyclerView) {
        this.context = context;
        this.arrayList_forRecyclerView = arrayList_forRecyclerView;
    }

    @NonNull
    @Override
    public ForemanServicesAdapter.MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_foreman_services, parent, false);

        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ForemanServicesAdapter.MyHolder holder, @SuppressLint("RecyclerView") int position) {

        holder.sServiceID = arrayList_forRecyclerView.get(position).getServiceID();


        holder.Name.setText(arrayList_forRecyclerView.get(position).getFirstName() + " " + arrayList_forRecyclerView.get(position).getLastName());
        holder.MobileNumber.setText("+880 " + arrayList_forRecyclerView.get(position).getMobileNumber());

        holder.sProblemType = arrayList_forRecyclerView.get(position).getTypeOfService();
        holder.sProblemSubType = arrayList_forRecyclerView.get(position).getProblemSubType();
        holder.sFixCharge = arrayList_forRecyclerView.get(position).getServiceFixedCharge();
        holder.ProblemType.setText(holder.sProblemType);
        holder.ProblemSubType.setText(holder.sProblemSubType);
        holder.FixCharge.setText("৳ " + holder.sFixCharge);


        holder.arrayList_TypeOfProblem = new ArrayList<>();
        holder.arrayList_TypeOfProblem.add("Select TypeOfProblem");
        String typeOfSituationalServices[] = ConstantData.TypeOfProblem;
        List<String> list;
        list = Arrays.asList(typeOfSituationalServices);
        holder.arrayList_TypeOfProblem.addAll(list);

        ArrayAdapter arrayAdapter = new ArrayAdapter(context, android.R.layout.simple_list_item_1, holder.arrayList_TypeOfProblem);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_list_item_activated_1);
        holder.TypeOFProblemSpinner.setAdapter(arrayAdapter);

        holder.TypeOFProblemSpinner.setSelection(holder.arrayList_TypeOfProblem.indexOf("Select TypeOfProblem"));
        holder.TypeOFProblemSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                holder.TypeOFProblemSpinner.setSelection(i);
                holder.sSTypeOfProblem = holder.arrayList_TypeOfProblem.get(i);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        holder.arrayList_ProblemSubType1 = new ArrayList<>();
        holder.arrayList_ProblemSubType1.add("Select ProblemSubType");
        String temp1[] = ConstantData.ProblemSubTypeFuel;
        List<String> list1;
        list1 = Arrays.asList(temp1);
        holder.arrayList_ProblemSubType1.addAll(list1);

        ArrayAdapter arrayAdapter1 = new ArrayAdapter(context, android.R.layout.simple_list_item_1, holder.arrayList_ProblemSubType1);
        arrayAdapter1.setDropDownViewResource(android.R.layout.simple_list_item_activated_1);

        holder.arrayList_ProblemSubType2 = new ArrayList<>();
        holder.arrayList_ProblemSubType2.add("Select ProblemSubType");
        String temp2[] = ConstantData.ProblemSubTypeTyre;
        List<String> list2;
        list2 = Arrays.asList(temp2);
        holder.arrayList_ProblemSubType2.addAll(list2);

        ArrayAdapter arrayAdapter2 = new ArrayAdapter(context, android.R.layout.simple_list_item_1, holder.arrayList_ProblemSubType2);
        arrayAdapter2.setDropDownViewResource(android.R.layout.simple_list_item_activated_1);
        holder.count1 = 0;
        holder.count2 = 0;
        holder.count3 = 0;

        // Temp
        ArrayList<String> list3 = new ArrayList<>();
        list3.add("-");
        ArrayAdapter arrayAdapter3 = new ArrayAdapter(context, android.R.layout.simple_list_item_1, list3);
        arrayAdapter3.setDropDownViewResource(android.R.layout.simple_list_item_activated_1);


        holder.EditButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                holder.layoutEdit.setVisibility(View.VISIBLE);
                holder.layoutText.setVisibility(View.GONE);
                holder.FixCharge_EditText.setText(holder.sFixCharge);

                if (holder.sSTypeOfProblem == "Fuel Problem") {
                    holder.layoutSubProblem.setVisibility(View.VISIBLE);
                    holder.ProblemSubTypeSpinner.setAdapter(arrayAdapter1);
                    holder.ProblemSubTypeSpinner.setSelection(0);
                    holder.count1 = holder.count1 + 1;

                } else if (holder.sSTypeOfProblem == "Tyre Problem") {
                    holder.layoutSubProblem.setVisibility(View.VISIBLE);
                    holder.ProblemSubTypeSpinner.setAdapter(arrayAdapter2);
                    holder.ProblemSubTypeSpinner.setSelection(0);
                    holder.count2 = holder.count2 + 1;

                } else {
                    holder.ProblemSubTypeSpinner.setAdapter(arrayAdapter1);
                    holder.ProblemSubTypeSpinner.setSelection(list3.indexOf("-"));
                    holder.count3 = holder.count3 + 1;

                }

            }
        });

        holder.ProblemSubTypeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                holder.ProblemSubTypeSpinner.setSelection(i);
                if (holder.count1 != 0) {
                    holder.sSProblemSubType = holder.arrayList_ProblemSubType1.get(i);
                } else if (holder.count2 != 0) {
                    holder.sSProblemSubType = holder.arrayList_ProblemSubType2.get(i);
                } else {
                    holder.sSProblemSubType = "";
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        holder.MobileNumber_EditText.setText(arrayList_forRecyclerView.get(position).getMobileNumber());
        holder.UpdateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                holder.sMobileNumber = holder.MobileNumber_EditText.getText().toString();
                holder.sFixCharge = holder.FixCharge_EditText.getText().toString();

//                if(holder.sSProblemSubType.equalsIgnoreCase("-")){
//                    holder.sSProblemSubType = "";
//                }

                if (holder.sSTypeOfProblem.equalsIgnoreCase("Select TypeOfProblem") ||
                        holder.sSTypeOfProblem.equalsIgnoreCase("") || holder.sSTypeOfProblem.isEmpty()) {
                    new CommonMethod(context, "Please Select Type Of Problem");
                }
//                else if(holder.sSProblemSubType.equalsIgnoreCase("Select ProblemSubType")){
//                    new CommonMethod(context, "Please Select Problem Sub Type");
//                }
                else if (holder.sMobileNumber.isEmpty() || holder.sMobileNumber.equalsIgnoreCase("")) {
                    holder.MobileNumber_EditText.setError("Mobile Number is Required");
                } else if (holder.sMobileNumber.length() > 10 && holder.sMobileNumber.length() < 10) {
                    holder.MobileNumber_EditText.setError("Mobile Number is not Valid");
                } else if (holder.sFixCharge.isEmpty() || holder.sFixCharge.equalsIgnoreCase("")) {
                    holder.FixCharge_EditText.setError("FixedCharge is Required");
                } else {

                    UpdateServicesData(holder.sServiceID, holder.sSTypeOfProblem, holder.sSProblemSubType, holder.sMobileNumber, holder.sFixCharge);

                    arrayList_forRecyclerView.get(position).setServiceID(holder.sServiceID);
                    arrayList_forRecyclerView.get(position).setTypeOfService(holder.sSTypeOfProblem);
                    arrayList_forRecyclerView.get(position).setProblemSubType(holder.sProblemSubType);
                    arrayList_forRecyclerView.get(position).setServiceFixedCharge(holder.sFixCharge);

                    holder.layoutText.setVisibility(View.VISIBLE);
                    holder.layoutEdit.setVisibility(View.GONE);

                    notifyDataSetChanged();

                }

            }
        });

        holder.DeleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DeleteServicesData(holder.sServiceID);
                arrayList_forRecyclerView.remove(sPosition);
                notifyDataSetChanged();

            }
        });

    }


    private void DeleteServicesData(String sServiceID) {
        sp.getString(SharedPreferencesData.UserID, "");
    }

    @Override
    public int getItemCount() {
        return arrayList_forRecyclerView.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder {

        CircleImageView ProfileImage;
        TextView Name, MobileNumber, ProblemType, ProblemSubType, FixCharge;
        Spinner TypeOFProblemSpinner, ProblemSubTypeSpinner;
        EditText MobileNumber_EditText, FixCharge_EditText;
        Button EditButton, UpdateButton, DeleteButton, BackButton;
        LinearLayout layoutText, layoutSubProblem;
        NestedScrollView layoutEdit;

        ArrayList<String> arrayList_TypeOfProblem, arrayList_ProblemSubType1, arrayList_ProblemSubType2;
        String sName, sMobileNumber, sProblemType, sProblemSubType, sFixCharge;

        String sSTypeOfProblem, sSProblemSubType;
        String sServiceID;

        int count1, count2, count3;

        public MyHolder(@NonNull View itemView) {
            super(itemView);


            sp = context.getSharedPreferences(SharedPreferencesData.PREF, Context.MODE_PRIVATE);

            layoutText = itemView.findViewById(R.id.custom_foreman_services_MainLinear);
            ProfileImage = itemView.findViewById(R.id.custom_foreman_services_foremanProfileImage);
            String encodedSaveImage = sp.getString(SharedPreferencesData.ProfileImage, "");
            byte[] decodedString = Base64.decode(encodedSaveImage, Base64.DEFAULT);
            Bitmap decodeBitmap = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
            if (decodeBitmap != null) {
                ProfileImage.setImageBitmap(decodeBitmap);
            }
            Name = itemView.findViewById(R.id.custom_foreman_services_FirstANDLastName);
            MobileNumber = itemView.findViewById(R.id.custom_foreman_services_MobileNumber);
            ProblemType = itemView.findViewById(R.id.custom_foreman_services_TypeOfProblem);
            ProblemSubType = itemView.findViewById(R.id.custom_foreman_services_problemSubType);
            FixCharge = itemView.findViewById(R.id.custom_foreman_services_FixedCharge);
            EditButton = itemView.findViewById(R.id.custom_foreman_services_EditButton);
            DeleteButton = itemView.findViewById(R.id.custom_foreman_services_DeleteButton);

            layoutEdit = itemView.findViewById(R.id.custom_foreman_services_editableLayout);
            TypeOFProblemSpinner = itemView.findViewById(R.id.custom_foreman_services_Spinner_TypeOfProblem);

            layoutSubProblem = itemView.findViewById(R.id.custom_foreman_services_ProblemSubType_Layout);

            ProblemSubTypeSpinner = itemView.findViewById(R.id.custom_foreman_services_Spinner_ProblemSubType);
            MobileNumber_EditText = itemView.findViewById(R.id.custom_foreman_services_MobileNumberEditText);
            FixCharge_EditText = itemView.findViewById(R.id.custom_foreman_services_FixedServiceChargeEditText);
            UpdateButton = itemView.findViewById(R.id.custom_foreman_services_UpdateButton);
            BackButton = itemView.findViewById(R.id.custom_foreman_services_backButton);

            layoutEdit.setVisibility(View.GONE);
            layoutText.setVisibility(View.VISIBLE);

        }
    }

    private void UpdateServicesData(String ServiceID, String sTypeOfProblem, String sProblemSubType, String sMobileNumber, String sFixedCharge) {


//                ServiceID,
//                sp.getString(SharedPreferencesData.UserID, ""),
//                sMobileNumber, sTypeOfProblem, sProblemSubType, sFixedCharge


    }



}
