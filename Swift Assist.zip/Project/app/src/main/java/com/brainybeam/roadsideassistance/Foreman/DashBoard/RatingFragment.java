package com.brainybeam.roadsideassistance.Foreman.DashBoard;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.Utils.ConnectionDetector;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;


public class RatingFragment extends Fragment {

    CardView cardView1, cardView2;

    int ratingAboveFour, ratingAboveFourBetweenTwo, ratingLessThenTwo;

    SharedPreferences sp;

    TextView rating4, rating2to4, rating2;

    public RatingFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_rating, container, false);


        sp = getActivity().getSharedPreferences(SharedPreferencesData.PREF, Context.MODE_PRIVATE);

        cardView2 = view.findViewById(R.id.frag_rating_CardView2);


        cardView2.setVisibility(View.VISIBLE);

        rating4 = view.findViewById(R.id.frag_rating_ratingFour_TextView);
        rating2to4 = view.findViewById(R.id.frag_rating_ratingBetween2to4_TextView);
        rating2 = view.findViewById(R.id.frag_rating_ratingLessThen2_TextView);

        ratingAboveFour = 0;
        ratingAboveFourBetweenTwo = 0;
        ratingLessThenTwo = 0;

        if (new ConnectionDetector(getActivity()).isConnectingToInternet()) {


            GetRatingData();

        } else {
            new ConnectionDetector(getActivity()).connectiondetect();
        }

        if (sp.getString(SharedPreferencesData.Foreman_Rating_ratingAboveFour, "").equalsIgnoreCase("") || sp.getString(SharedPreferencesData.Foreman_Rating_ratingAboveFour, "").isEmpty()) {
            rating4.setText("0+");
        } else {
            rating4.setText(sp.getString(SharedPreferencesData.Foreman_Rating_ratingAboveFour, "") + "+");
        }

        if (sp.getString(SharedPreferencesData.Foreman_Rating_ratingAboveFourBetweenTwo, "").equalsIgnoreCase("") || sp.getString(SharedPreferencesData.Foreman_Rating_ratingAboveFourBetweenTwo, "").isEmpty()) {
            rating2to4.setText("0+");
        } else {
            rating2to4.setText(sp.getString(SharedPreferencesData.Foreman_Rating_ratingAboveFourBetweenTwo, "") + "+");
        }

        if (sp.getString(SharedPreferencesData.Foreman_Rating_ratingLessThenTwo, "").equalsIgnoreCase("") || sp.getString(SharedPreferencesData.Foreman_Rating_ratingLessThenTwo, "").isEmpty()) {
            rating2.setText("0+");
        } else {
            rating2.setText(sp.getString(SharedPreferencesData.Foreman_Rating_ratingLessThenTwo, "") + "+");
        }

        return view;
    }

    private void GetRatingData() {

        sp.getString(SharedPreferencesData.User_ForemanID, "");

        sp.edit().putString(SharedPreferencesData.Foreman_Rating_ratingAboveFour, String.valueOf(ratingAboveFour)).commit();
        sp.edit().putString(SharedPreferencesData.Foreman_Rating_ratingAboveFourBetweenTwo, String.valueOf(ratingAboveFourBetweenTwo)).commit();
        sp.edit().putString(SharedPreferencesData.Foreman_Rating_ratingLessThenTwo, String.valueOf(ratingLessThenTwo)).commit();


    }
}