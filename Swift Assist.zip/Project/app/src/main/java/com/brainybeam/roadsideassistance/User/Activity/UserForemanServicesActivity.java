package com.brainybeam.roadsideassistance.User.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;

import com.brainybeam.roadsideassistance.GPS.GPSTracker;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.User.CustomArrayList.UserForemanServiceList;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConnectionDetector;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Objects;

public class UserForemanServicesActivity extends AppCompatActivity {

    RecyclerView servicesRecyclerview;
    ArrayList<UserForemanServiceList> arrayList;

    SharedPreferences sp;
    FirebaseAuth mAuth;
    FirebaseFirestore fStore;
    ProgressDialog pd;
    GPSTracker gpsTracker;
    double CurrentLatitude, CurrentLongitude;
    double DriverLatitude, DriverLongitude;

    String sUserAddress, sUserLatitude, sUserLongitude;

    private static final int REQUEST_LOCATION = 1;
    LocationManager locationManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_foreman_services);
        // getSupportActionBar().hide();
        Objects.requireNonNull(getSupportActionBar()).setTitle("Service Provider");
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#2196F3"));
        getSupportActionBar().setBackgroundDrawable(colorDrawable);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        sp = getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);
        mAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();

        servicesRecyclerview = findViewById(R.id.user_foremanServices_recyclerview);
        servicesRecyclerview.setLayoutManager(new LinearLayoutManager(UserForemanServicesActivity.this));
        servicesRecyclerview.setItemAnimator(new DefaultItemAnimator());

        gpsTracker = new GPSTracker(UserForemanServicesActivity.this);

        // Check if GPS enabled
        if (gpsTracker.canGetLocation()) {

            CurrentLatitude = gpsTracker.getLatitude();
            CurrentLongitude = gpsTracker.getLongitude();
            //getLocation();
        } else {
            // Can't get location.
            // GPS or network is not enabled.
            // Ask user to enable GPS/network in settings.
            gpsTracker.showSettingsAlert();
        }
        if (new ConnectionDetector(UserForemanServicesActivity.this).isConnectingToInternet()) {
            getServicesData();

        } else {
            new ConnectionDetector(UserForemanServicesActivity.this).connectiondetect();
        }

    }

    private void getLocation() {
        if (ActivityCompat.checkSelfPermission(
                UserForemanServicesActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                UserForemanServicesActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(UserForemanServicesActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);
        } else {
            Location locationGPS = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (locationGPS != null) {
                double lat = locationGPS.getLatitude();
                double longi = locationGPS.getLongitude();
                CurrentLatitude = lat;
                CurrentLongitude = longi;
            } else {
                new CommonMethod(UserForemanServicesActivity.this, "Not Found");
            }
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
        }

        return super.onOptionsItemSelected(item);
    }

    private void getServicesData() {

        String User_TypeOfProblem = sp.getString(SharedPreferencesData.User_TypeOfProblem, "");

        arrayList = new ArrayList<>();
        Task<QuerySnapshot> documentReference = fStore.collection("Services").whereEqualTo("typeOfProblem", User_TypeOfProblem).get();
        documentReference.addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                Log.d("Created", "Created Successfully");
                if (task.isSuccessful() && task.getResult() != null) {
                    for (DocumentSnapshot document : task.getResult()) {
                        UserForemanServiceList list = new UserForemanServiceList();

                        list.setServiceID(document.getString("serviceID"));
                        list.setForemanID(document.getString("foremanID"));
                        list.setProfileImage(document.getString("profileImage"));
                        list.setTypeOfProblem(document.getString("typeOfProblem"));
                        list.setProblemSubType(document.getString("problemSubType"));
                        list.setServiceFixedCharge(document.getString("serviceFixedCharge"));

                        list.setFirstName(document.getString("FirstName"));
                        list.setLastName(document.getString("LastName"));
                        list.setMobileNumber(document.getString("MobileNumber"));
                        String FullAddress = document.getString("ForemanAddress") + "," + document.getString("ForemanArea") + "," + document.getString("ForemanCity") + "," + document.getString("ForemanState");
                        list.setFullAddress(FullAddress);
                        list.setLatitude(document.getString("sForemanLatitude"));
                        list.setLongitude(document.getString("sForemanLongitude"));
                        list.setUserLocation(sUserAddress);

                        // TODO User Location
                        Location startPoint = new Location("locationA");
                        list.setUserLatitude(String.valueOf(CurrentLatitude));
                        list.setUserLongitude(String.valueOf(CurrentLongitude));
                        startPoint.setLatitude(CurrentLatitude);
                        startPoint.setLongitude(CurrentLongitude);

                        // TODO Foreman Location
                        Location endPoint = new Location("locationA");
                        endPoint.setLatitude(DriverLatitude);
                        endPoint.setLongitude(DriverLongitude);
                        DecimalFormat precision = new DecimalFormat("0.00");
                        double distance = Double.parseDouble(precision.format(startPoint.distanceTo(endPoint) / 1000));
                        list.setDistance(String.valueOf(distance));
                        arrayList.add(list);
                    }
                    UserForemanServiceAdapter adapter = new UserForemanServiceAdapter(UserForemanServicesActivity.this, arrayList);
                    servicesRecyclerview.setAdapter(adapter);
                    adapter.notifyDataSetChanged();
                }
            }
        });

    }


}