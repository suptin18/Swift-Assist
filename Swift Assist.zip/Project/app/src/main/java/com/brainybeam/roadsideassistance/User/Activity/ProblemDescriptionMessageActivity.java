package com.brainybeam.roadsideassistance.User.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConnectionDetector;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;

public class ProblemDescriptionMessageActivity extends AppCompatActivity {

    EditText MessageBox;
    Button SendButton, SkipButton;

    String sMessage;


    SharedPreferences sp;
    ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_problem_description_message);
        getSupportActionBar().setTitle("Describe your Problem");
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#2196F3"));
        getSupportActionBar().setBackgroundDrawable(colorDrawable);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        sp = getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);

        MessageBox = findViewById(R.id.problem_description_message_MessageBoxEditText);
        SendButton = findViewById(R.id.problem_description_message_SendButton);
        SkipButton = findViewById(R.id.problem_description_message_SkipButton);

        SendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                sMessage = MessageBox.getText().toString();
                if (sMessage.isEmpty() || sMessage.equalsIgnoreCase("")) {
                    MessageBox.setError("Please Click Valid Button");
                } else {

                    if (new ConnectionDetector(ProblemDescriptionMessageActivity.this).isConnectingToInternet()) {

                        sp.edit().putString(SharedPreferencesData.User_DescriptionMessage, sMessage).commit();
                        pd = new ProgressDialog(ProblemDescriptionMessageActivity.this);
                        pd.setMessage("Message Sending...");
                        pd.setCancelable(false);
                        pd.show();
                        StoreProblemDescriptionMessage();
                        new CommonMethod(ProblemDescriptionMessageActivity.this, UserVehicleSelectionActivity.class);

                    } else {
                        new ConnectionDetector(ProblemDescriptionMessageActivity.this).connectiondetect();
                    }
                }

            }
        });

        SkipButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (new ConnectionDetector(ProblemDescriptionMessageActivity.this).isConnectingToInternet()) {
                    new CommonMethod(ProblemDescriptionMessageActivity.this, UserVehicleSelectionActivity.class);
                } else {
                    new ConnectionDetector(ProblemDescriptionMessageActivity.this).connectiondetect();
                }
            }
        });
    }

    private void StoreProblemDescriptionMessage() {
//                sp.getString(SharedPreferencesData.User_ServiceID, ""),
//                sp.getString(SharedPreferencesData.User_ForemanID, ""),
//                sp.getString(SharedPreferencesData.UserID, ""),
//                sMessage
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

}