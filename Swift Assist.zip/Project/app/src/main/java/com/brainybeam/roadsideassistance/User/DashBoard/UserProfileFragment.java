package com.brainybeam.roadsideassistance.User.DashBoard;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.brainybeam.roadsideassistance.OTPVerification.OTPVerificationActivity;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

import de.hdodenhof.circleimageview.CircleImageView;


public class UserProfileFragment extends Fragment {

    LinearLayout layout1, layout2;
    CircleImageView ProfileImage1, ProfileImage2;
    TextView FirstName, LastName, Contact, Email, AccountStatus;
    EditText FirstName_EditText, LastName_EditText, Contact_EditText, Email_EditText, Password_EditText;
    Button EditTextButton, UpdateButton, DeactivateButton1, DeactivateButton2;

    String sFirstName, sLastName, sContact, sEmail, sPassword;
    SharedPreferences sp;
    Bundle bundle;

    Uri imageUri;
    StorageReference storageReference;
    FirebaseApp firebaseApp;
    private FirebaseAuth mAuth;
    FirebaseFirestore fStore;

    private final String EmailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

    String[] appPermission = {Manifest.permission.READ_EXTERNAL_STORAGE};
    private static final int PERMISSION_REQUEST_CODE = 1240;


    public UserProfileFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for getActivity() fragment
        View view = inflater.inflate(R.layout.fragment_user_profile, container, false);

        firebaseApp = FirebaseApp.initializeApp(requireActivity());
        mAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();


        sp = requireActivity().getSharedPreferences(SharedPreferencesData.PREF, Context.MODE_PRIVATE);

        layout1 = view.findViewById(R.id.frag_user_profile_layout1);
        layout2 = view.findViewById(R.id.frag_user_profile_layout2);
        ProfileImage1 = view.findViewById(R.id.frag_user_profile_userProfileImage);
        ProfileImage2 = view.findViewById(R.id.frag_user_profile_userProfileImage2);
        FirstName = view.findViewById(R.id.frag_user_profile_FirstName);
        LastName = view.findViewById(R.id.frag_user_profile_LastName);
        Contact = view.findViewById(R.id.frag_user_profile_MobileNumber);
        Email = view.findViewById(R.id.frag_user_profile_Email);
        AccountStatus = view.findViewById(R.id.frag_user_profile_AccountStatus);
        FirstName_EditText = view.findViewById(R.id.frag_user_profile_FirstNameEditText);
        LastName_EditText = view.findViewById(R.id.frag_user_profile_LastNameEditText);
        Contact_EditText = view.findViewById(R.id.frag_user_profile_MobileNumberEditText);
        Email_EditText = view.findViewById(R.id.frag_user_profile_EmailEditText);
        Password_EditText = view.findViewById(R.id.frag_user_profile_PasswordEditText);
        EditTextButton = view.findViewById(R.id.frag_user_profile_EditProfileButton);
        UpdateButton = view.findViewById(R.id.frag_user_profile_UpdateButton);
        DeactivateButton1 = view.findViewById(R.id.frag_user_profile_deactivateButton);
        DeactivateButton2 = view.findViewById(R.id.frag_user_profile_deactivateButton2);

        layout2.setVisibility(View.GONE);

        // TODO Get Profile Image
        GetImageSp();

        FirstName.setText(sp.getString(SharedPreferencesData.FirstName, ""));
        LastName.setText(sp.getString(SharedPreferencesData.LastName, ""));
        Contact.setText(sp.getString(SharedPreferencesData.MobileNumber, ""));
        Email.setText(sp.getString(SharedPreferencesData.Email, ""));
        AccountStatus.setText(sp.getString(SharedPreferencesData.Account_Status, ""));

        EditTextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                layout2.setVisibility(View.VISIBLE);
                layout1.setVisibility(View.GONE);
            }
        });

        UpdateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sFirstName = FirstName_EditText.getText().toString();
                sLastName = LastName_EditText.getText().toString();
                sContact = Contact_EditText.getText().toString();
                sEmail = Email_EditText.getText().toString();
                sPassword = Password_EditText.getText().toString();

                if (sFirstName.isEmpty()) {
                    FirstName_EditText.setError("FirstName is Required");
                } else if (sLastName.isEmpty()) {
                    LastName_EditText.setError("LastName is Required");
                } else if (sContact.length() != 10) {
                    Contact_EditText.setError("Mobile number is Required");
                } else if (sEmail.isEmpty()) {
                    Email_EditText.setError("Email is Required");
                } else if (!sEmail.matches(EmailPattern)) {
                    Email_EditText.setError("Valid Email is Required");
                } else if (sPassword.isEmpty()) {
                    Password_EditText.setError("Password is Required");
                } else if (sPassword.length() < 8) {
                    Password_EditText.setError("Password must be 8 char long");
                } else {
                    UpdateUserPassword();
                    UpdateUserProfileData();
                    UpdateUserProfileImageData();
                }

            }
        });


        ProfileImage2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (checkAndRequestPermission()) {
                    selectImageMethod(view);
                }
            }
        });

        DeactivateButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                DeactivateUserAccount();
            }
        });

        DeactivateButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                DeactivateUserAccount();
            }
        });
        return view;
    }

    // Todo Get Profile Image From Shared Preference
    private void GetImageSp() {
        String encodedSaveImage = sp.getString(SharedPreferencesData.ProfileImage, "");
        byte[] decodedString = Base64.decode(encodedSaveImage, Base64.DEFAULT);
        Bitmap decodeBitmap = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        if (decodeBitmap != null) {
            ProfileImage1.setImageBitmap(decodeBitmap);
            new CommonMethod(getActivity(), "Image Got from Sp");
        } else {
            getUserImage();
        }
    }

    // Todo Get Profile Image from Firebase
    private void getUserImage() {
        storageReference = FirebaseStorage.getInstance().getReference("images/userprofile/" + sp.getString(SharedPreferencesData.UserID, "") + ".jpg");
        try {
            File localfile = File.createTempFile("tempfile", ".jpg");
            storageReference.getFile(localfile).addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                    new CommonMethod(getActivity(), "Image Downloaded");
                    Bitmap bitmap1 = BitmapFactory.decodeFile(localfile.getAbsolutePath());
                    ProfileImage1.setImageBitmap(bitmap1);

                    SaveImageSp();// Save Image to Sp
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    new CommonMethod(getActivity(), "Image Not Downloaded");
                    ProfileImage1.setImageResource(R.drawable.ic_profile);//default image
                }

            });
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    // Todo Save Image to Shared Preference
    private void SaveImageSp() {
        BitmapDrawable bitmapDrawable = (BitmapDrawable) ProfileImage1.getDrawable();
        Bitmap bitmap = bitmapDrawable.getBitmap();

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream);
        byte[] byteArray = outputStream.toByteArray();
        String encodedImage = Base64.encodeToString(byteArray, Base64.DEFAULT);

        sp.edit().putString(SharedPreferencesData.ProfileImage, encodedImage).apply();

        new CommonMethod(getActivity(), "Image saved to shared preference");
    }

    // Todo Update Profile Image
    private void UpdateUserProfileImageData() {
        // Todo Delete Old Image
        storageReference = FirebaseStorage.getInstance().getReference("images/userprofile/" + sp.getString(SharedPreferencesData.UserID, "") + ".jpg");
        storageReference.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                new CommonMethod(getActivity(), "Image Deleted");
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                new CommonMethod(getActivity(), "Image Not Deleted");
            }
        });
        // Todo Upload New Image
        storageReference = FirebaseStorage.getInstance().getReference("images/userprofile/" + sp.getString(SharedPreferencesData.UserID, "") + ".jpg");
        storageReference.putFile(imageUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                new CommonMethod(getActivity(), "Image Uploaded");
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                new CommonMethod(getActivity(), "Image Not Uploaded");
            }
        });
    }

    // Todo Deactivate User Account
    private void DeactivateUserAccount() {

    }

    // Todo Update Password
    private void UpdateUserPassword() {
        Objects.requireNonNull(mAuth.getCurrentUser()).updatePassword(sPassword);
        new CommonMethod(getActivity(), "Password Updated");
    }

    // Todo Update User Profile
    private void UpdateUserProfileData() {
        sp.edit().putString(SharedPreferencesData.FirstName, sFirstName).apply();
        sp.edit().putString(SharedPreferencesData.LastName, sLastName).apply();
        sp.edit().putString(SharedPreferencesData.MobileNumber, sContact).apply();
        sp.edit().putString(SharedPreferencesData.Email, sEmail).apply();
        sp.edit().putString(SharedPreferencesData.Password, sPassword).apply();
        String userID = Objects.requireNonNull(mAuth.getCurrentUser()).getUid();
        DocumentReference documentReference = fStore.collection("Users").document(userID);
        new CommonMethod(getActivity(), "User ID" + userID);
        Map<String, Object> user = new HashMap<>();
        user.put("FirstName", sFirstName);
        user.put("LastName", sLastName);
        user.put("MobileNumber", sContact);
        user.put("Email", sEmail);
        user.put("Password", sPassword);
        Boolean value = true;
        user.put("Active_Status",  value);
        documentReference.update(user).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                new CommonMethod(getActivity(), "Information Updated");

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                new CommonMethod(getActivity(), "Information Not Updated");
            }
        });
    }


    private void otpSendToMobile(String sPhone) {

        PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

            @Override
            public void onVerificationCompleted(@NonNull PhoneAuthCredential credential) {

            }

            @Override
            public void onVerificationFailed(FirebaseException e) {
                new CommonMethod(getActivity(), e.getLocalizedMessage());
            }

            @Override
            public void onCodeSent(@NonNull String VerificationId,
                                   @NonNull PhoneAuthProvider.ForceResendingToken token) {

                new CommonMethod(getActivity(), "OTP is successFully Send");
                bundle.putString("PhoneNumber", sPhone.trim());
                bundle.putString("Mobile_VerificationID", VerificationId);
                Intent intent = new Intent(getActivity(), OTPVerificationActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        };

        PhoneAuthOptions options =
                PhoneAuthOptions.newBuilder(mAuth)
                        .setPhoneNumber("+880" + sPhone.trim())
                        .setTimeout(60L, TimeUnit.SECONDS)
                        .setActivity(requireActivity())
                        .setCallbacks(mCallbacks)
                        .build();
        PhoneAuthProvider.verifyPhoneNumber(options);

    }

    public void selectImageMethod(View view) {
        Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
        photoPickerIntent.setType("image/*");
        someActivityResultLauncher.launch(photoPickerIntent);
    }

    ActivityResultLauncher<Intent> someActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    // There are no request codes
                    // doSomeOperations();
                    Intent data = result.getData();
                    imageUri = Objects.requireNonNull(data).getData();
                    Log.d("RESPONSE_URI", String.valueOf(imageUri));
                    ProfileImage2.setImageURI(imageUri);
                }
            });


    public boolean checkAndRequestPermission() {
        List<String> listPermission = new ArrayList<>();
        for (String perm : appPermission) {
            if (ContextCompat.checkSelfPermission(requireActivity(), perm) != PackageManager.PERMISSION_GRANTED) {
                listPermission.add(perm);
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(requireActivity(), Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED) {

                listPermission.add(Manifest.permission.READ_MEDIA_IMAGES);
            }
        }
        if (listPermission.size() >= 2) {
            ActivityCompat.requestPermissions(requireActivity(), listPermission.toArray(new String[0]), PERMISSION_REQUEST_CODE);
            return false;
        }
        return true;
    }


}