package com.brainybeam.roadsideassistance.User.CustomArrayList;

public class UserVehicleList {

    String VehicleID;
    String UserID;
    String NumberPlate_number;
    String TypeOfVehicle;
    String VehicleModelName;
    String Vehicle_Colour;

    public String getVehicleID() {
        return VehicleID;
    }

    public void setVehicleID(String vehicleID) {
        VehicleID = vehicleID;
    }

    public String getUserID() {
        return UserID;
    }

    public void setUserID(String userID) {
        UserID = userID;
    }

    public String getNumberPlate_number() {
        return NumberPlate_number;
    }

    public void setNumberPlate_number(String numberPlate_number) {
        NumberPlate_number = numberPlate_number;
    }

    public String getTypeOfVehicle() {
        return TypeOfVehicle;
    }

    public void setTypeOfVehicle(String typeOfVehicle) {
        TypeOfVehicle = typeOfVehicle;
    }

    public String getVehicleModelName() {
        return VehicleModelName;
    }

    public void setVehicleModelName(String vehicleModelName) {
        VehicleModelName = vehicleModelName;
    }

    public String getVehicle_Colour() {
        return Vehicle_Colour;
    }

    public void setVehicle_Colour(String vehicle_Colour) {
        Vehicle_Colour = vehicle_Colour;
    }


}
