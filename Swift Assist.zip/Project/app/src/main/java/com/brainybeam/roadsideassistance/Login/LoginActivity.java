package com.brainybeam.roadsideassistance.Login;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;

import com.brainybeam.roadsideassistance.Admin.AdminCredential.AdminCredential;
import com.brainybeam.roadsideassistance.Admin.DashBoard.AdminDashboardActivity;
import com.brainybeam.roadsideassistance.Foreman.Activity.ForemanForgotPasswordActivity;
import com.brainybeam.roadsideassistance.Foreman.DashBoard.ForemanDashboardActivity;
import com.brainybeam.roadsideassistance.Foreman.Signup.ForemanSignupActivity;
import com.brainybeam.roadsideassistance.GPS.GPSTracker;
import com.brainybeam.roadsideassistance.Notification.PushNotification.Config;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.UpdateFCMIDData;
import com.brainybeam.roadsideassistance.User.Activity.UserForgotPasswordActivity;
import com.brainybeam.roadsideassistance.User.DashBoard.UserDashboardActivity;
import com.brainybeam.roadsideassistance.User.Signup.UserSignupActivity;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConnectionDetector;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.messaging.FirebaseMessaging;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    private EditText EmailORMobile, Password;
    private TextView ForgotPassword;
    SwitchCompat emailPhoneLoginSwitch;

    private ArrayList<String> AdminEmail;
    private ArrayList<String> AdminPassword;

    private final String EmailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

    String sEmailORMobile, sPassword, Mobile_VerificationID = null;

    SharedPreferences sp;
    GPSTracker gpsTracker;
    //ApiInterface apiInterface;
    FirebaseFirestore fStore;
    private FirebaseAuth mAuth;

    // TODO FCMID For Notification
    BroadcastReceiver broadcastReceiver;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        int or = getResources().getConfiguration().orientation;
        if (or == Configuration.ORIENTATION_LANDSCAPE) {
            Objects.requireNonNull(getSupportActionBar()).hide();
        }

        gpsTracker = new GPSTracker(LoginActivity.this);
        sp = getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);
        fStore = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();

        AdminEmail = new ArrayList<>();
        AdminPassword = new ArrayList<>();

        List<String> list1 = Arrays.asList(AdminCredential.AdminEmail);
        List<String> list2 = Arrays.asList(AdminCredential.AdminPassword);
        AdminEmail.addAll(list1);
        AdminPassword.addAll(list2);

        EmailORMobile = findViewById(R.id.login_EmailORMobile);
        EmailORMobile.setHint(R.string.email);//value


        Password = findViewById(R.id.login_Password);
        Password.setHint(R.string.password);//value
        ForgotPassword = findViewById(R.id.login_forgotPassword);
        Button login = findViewById(R.id.login_loginButton);
        Button getotp = findViewById(R.id.login_getotp);
        getotp.setVisibility(View.GONE);
        TextView signup = findViewById(R.id.login_signupButton);
        emailPhoneLoginSwitch = findViewById(R.id.EmailPhoneLoginSwitch);


        // Check if GPS enabled
        if (!gpsTracker.canGetLocation()) {
            gpsTracker.showSettingsAlert();
        }

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                sEmailORMobile = EmailORMobile.getText().toString();
                sPassword = Password.getText().toString();

                if (sEmailORMobile.isEmpty() || sEmailORMobile.equalsIgnoreCase(" ")) {
                    EmailORMobile.setError("Email OR Mobile Number is Required");
                } else if (!sEmailORMobile.matches(EmailPattern) && sEmailORMobile.length() < 10) {
                    EmailORMobile.setError("Valid Email OR Mobile Number is Required");
                } else if (sPassword.isEmpty() || sPassword.equalsIgnoreCase(" ")) {
                    Password.setError("Password is Required");
                } else if (AdminEmail.contains(sEmailORMobile) && AdminPassword.contains(sPassword)) {
                    AdminFCMIDStore();
                    sp.edit().putString(SharedPreferencesData.AdminLoginState, "AdminLogin").apply();
                    new CommonMethod(LoginActivity.this, AdminDashboardActivity.class);
                    finish();
                } else {

                    if (new ConnectionDetector(LoginActivity.this).isConnectingToInternet()) {
                        if (emailPhoneLoginSwitch.isChecked()) {
                            Email_loginMethod(sEmailORMobile, sPassword);
                        } else {
                            Mobile_loginMethod();
                        }

                    } else {
                        new ConnectionDetector(LoginActivity.this).connectiondetect();
                    }
                }

            }
        });


        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(LoginActivity.this);

                alertDialog.setPositiveButton("Signup As User", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        new CommonMethod(LoginActivity.this, UserSignupActivity.class);
                    }
                });
                alertDialog.setNeutralButton("Signup As Foreman", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        new CommonMethod(LoginActivity.this, ForemanSignupActivity.class);
                    }
                });
                alertDialog.show();

            }
        });


        emailPhoneLoginSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    EmailORMobile.setHint(R.string.email);
                    EmailORMobile.setInputType(InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
                    Password.setHint(R.string.password);
                    Password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    EmailORMobile.setText("");
                    Password.setText("");
                    ForgotPassword.setVisibility(View.VISIBLE);
                    getotp.setVisibility(View.GONE);
                } else {
                    EmailORMobile.setHint(R.string.phone_number);
                    EmailORMobile.setInputType(InputType.TYPE_CLASS_PHONE);
                    Password.setHint(R.string.otp);
                    Password.setInputType(InputType.TYPE_CLASS_PHONE);
                    EmailORMobile.setText("");
                    Password.setText("");
                    ForgotPassword.setVisibility(View.GONE);
                    getotp.setVisibility(View.VISIBLE);
                }
            }
        });

        getotp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String sPhone = EmailORMobile.getText().toString();
                otpSendToMobile(sPhone);
            }
        });

        ForgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder alertDialog = new AlertDialog.Builder(LoginActivity.this);

                alertDialog.setPositiveButton("User", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        new CommonMethod(LoginActivity.this, UserForgotPasswordActivity.class);
                    }
                });

                alertDialog.setNeutralButton("Foreman", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        new CommonMethod(LoginActivity.this, ForemanForgotPasswordActivity.class);
                    }
                });

                alertDialog.setCancelable(true);
                alertDialog.show();
            }
        });
    }


    private void AdminFCMIDStore() {

        getAdminToken();

    }

    private void otpSendToMobile(String sPhone) {

        PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

            @Override
            public void onVerificationCompleted(@NonNull PhoneAuthCredential credential) {

            }

            @Override
            public void onVerificationFailed(FirebaseException e) {

                new CommonMethod(LoginActivity.this, e.getLocalizedMessage());
            }

            @Override
            public void onCodeSent(@NonNull String VerificationId,
                                   @NonNull PhoneAuthProvider.ForceResendingToken token) {
                Mobile_VerificationID = VerificationId;

                new CommonMethod(LoginActivity.this, "OTP is successFully Send");

            }
        };

        PhoneAuthOptions options =
                PhoneAuthOptions.newBuilder(mAuth)
                        .setPhoneNumber("+880" + sPhone.trim())
                        .setTimeout(60L, TimeUnit.SECONDS)
                        .setActivity(this)
                        .setCallbacks(mCallbacks)
                        .build();
        PhoneAuthProvider.verifyPhoneNumber(options);

    }

    // TODO Login Method Start
    public void Mobile_loginMethod() {
        if (Mobile_VerificationID == null) {
            new CommonMethod(LoginActivity.this, "OTP is not Send");
            return;
        }
        String code = sPassword.trim();
        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(Mobile_VerificationID, code);
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            LoginMethod(Objects.requireNonNull(mAuth.getCurrentUser()).getUid());
                            new CommonMethod(LoginActivity.this, "Successful Login ");
                        } else {
                            new CommonMethod(LoginActivity.this, "Login Error");
                        }
                    }
                });

    }

    public void Email_loginMethod(String sEmailORMobile, String sPassword) {
        mAuth.signInWithEmailAndPassword(sEmailORMobile, sPassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    LoginMethod(Objects.requireNonNull(mAuth.getCurrentUser()).getUid());
                } else {
                    new CommonMethod(LoginActivity.this, "Login Error");
                }

            }
        });
    }

    public void LoginMethod(String userID) {
        sp.edit().putString(SharedPreferencesData.UserID, userID).apply();
        DocumentReference documentReference = fStore.collection("Users").document(userID);
        documentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                assert value != null;
                sp.edit().putString(SharedPreferencesData.UserType, value.getString("UserType")).apply();
                sp.edit().putString(SharedPreferencesData.FirstName, value.getString("FirstName")).apply();
                sp.edit().putString(SharedPreferencesData.LastName, value.getString("LastName")).apply();
                sp.edit().putString(SharedPreferencesData.MobileNumber, value.getString("MobileNumber")).apply();
                sp.edit().putString(SharedPreferencesData.Email, value.getString("Email")).apply();
                sp.edit().putString(SharedPreferencesData.Password, value.getString("Password")).apply();
                sp.edit().putString(SharedPreferencesData.Account_Status, value.getString("Account_Status")).apply();
                sp.edit().putBoolean(SharedPreferencesData.Active_Status, Boolean.TRUE.equals(value.getBoolean("Active_Status"))).apply();

                // TODO Notification FCMID
                broadcastReceiver = new BroadcastReceiver() {
                    @Override
                    public void onReceive(Context context, Intent intent) {
                        if (Objects.equals(intent.getAction(), Config.REGISTRATION_COMPLETE)) {
                            FirebaseMessaging.getInstance().subscribeToTopic(Config.TOPIC_GLOBAL);
                            getUserToken();
                        } else if (Objects.equals(intent.getAction(), Config.PUSH_NOTIFICATION)) {
                            String s = intent.getStringExtra("message");
                        } else {
                        }
                    }
                };

                if (Objects.requireNonNull(value.getString("UserType")).equalsIgnoreCase("User")) {
                    getUserToken();
                    new CommonMethod(LoginActivity.this, UserDashboardActivity.class);
                    finish();
                } else {
                    sp.edit().putString(SharedPreferencesData.ForemanAddress, value.getString("ForemanAddress")).apply();
                    sp.edit().putString(SharedPreferencesData.ForemanArea, value.getString("ForemanArea")).apply();
                    sp.edit().putString(SharedPreferencesData.ForemanCity, value.getString("ForemanCity")).apply();
                    sp.edit().putString(SharedPreferencesData.ForemanState, value.getString("ForemanState")).apply();
                    sp.edit().putBoolean(SharedPreferencesData.ForemanAccount_Status, Boolean.TRUE.equals(value.getBoolean("ForemanAccount_Status"))).apply();
                    sp.edit().putString(SharedPreferencesData.Foreman_ForemanLatitude,value.getString("sForemanLatitude")).apply();
                    sp.edit().putString(SharedPreferencesData.Foreman_ForemanLongitude,value.getString("sForemanLongitude")).apply();
                getForemanToken();
                    new CommonMethod(LoginActivity.this, ForemanDashboardActivity.class);
                    finish();
                }
            }
        });
        //        sp.edit().putString(SharedPreferencesData.ProfileImage, data.response.get(i).profileImage).commit();
    }
    // TODO Login Method End

    private void getAdminToken() {
        FirebaseMessaging.getInstance().getToken().addOnSuccessListener(new OnSuccessListener<String>() {
            @Override
            public void onSuccess(String stoken) {
                Log.d("RESPONSE_TOKEN", stoken);
                sp.edit().putString(SharedPreferencesData.UserFCMID, stoken).commit();

                if (new ConnectionDetector(LoginActivity.this).isConnectingToInternet()) {
                    if (sp.getString(SharedPreferencesData.UserType, "").isEmpty()) {
                        sp.edit().putString(SharedPreferencesData.Admin_FCMID, stoken).commit();
                    }
                } else {
                    new ConnectionDetector(LoginActivity.this).connectiondetect();
                }
            }
        });
    }

    private void getUserToken() {
        FirebaseMessaging.getInstance().getToken().addOnSuccessListener(new OnSuccessListener<String>() {
            @Override
            public void onSuccess(String stoken) {
                Log.d("RESPONSE_TOKEN", stoken);
                sp.edit().putString(SharedPreferencesData.UserFCMID, stoken).apply();

                if (new ConnectionDetector(LoginActivity.this).isConnectingToInternet()) {
                    if (sp.getString(SharedPreferencesData.UserType, "").isEmpty()) {
                        sp.edit().putString(SharedPreferencesData.Admin_FCMID, stoken).apply();
                    }
                } else {
                    new ConnectionDetector(LoginActivity.this).connectiondetect();
                }
            }
        });
    }


    private void getForemanToken() {
        FirebaseMessaging.getInstance().getToken().addOnSuccessListener(new OnSuccessListener<String>() {
            @Override
            public void onSuccess(String stoken) {
                Log.d("RESPONSE_TOKEN", stoken);
                sp.edit().putString(SharedPreferencesData.UserFCMID, stoken).apply();

                if (new ConnectionDetector(LoginActivity.this).isConnectingToInternet()) {
                    if (sp.getString(SharedPreferencesData.UserType, "").isEmpty()) {
                        sp.edit().putString(SharedPreferencesData.Admin_FCMID, stoken).apply();
                    }
                } else {
                    new ConnectionDetector(LoginActivity.this).connectiondetect();
                }
            }
        });
    }

}
