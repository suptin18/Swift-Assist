package com.brainybeam.roadsideassistance.Foreman.DashBoard;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.brainybeam.roadsideassistance.GPS.GPSTracker;
import com.brainybeam.roadsideassistance.OTPVerification.OTPVerificationActivity;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConstantData;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;


import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

import de.hdodenhof.circleimageview.CircleImageView;


public class ForemanProfileFragment extends Fragment {

    LinearLayout layout1, layout2;
    CircleImageView ProfileImage1, ProfileImage2;
    TextView FirstName, LastName, Contact, Email, Address, Area, City, State, AccountStatus;
    EditText FirstName_EditText, LastName_EditText, Contact_EditText, Email_EditText, Password_EditText, Address_EditText, Area_EditText, City_EditText;
    Spinner Spinner_State;
    Button EditTextButton, UpdateButton, DeactivateButton1, DeactivateButton2;

    ArrayList<String> arrayList;
    String sFirstName, sLastName, sContact, sEmail, sPassword, sAddress, sArea, sCity, sState;

    Uri imageUri;
    StorageReference storageReference;
    SharedPreferences sp;
    FirebaseFirestore fStore;

    Bundle bundle;

    FirebaseApp firebaseApp;
    private FirebaseAuth mAuth;
    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks;
    private String sPhone;

    private String EmailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";


    String[] appPermission = {Manifest.permission.READ_EXTERNAL_STORAGE};
    private static final int PERMISSION_REQUEST_CODE = 1240;
    private static final int PICK_IMAGE_REQUEST = 12;
    String sImagePath1 = "";
    String sImagePath2 = "";

    String getImageURL = "";
    double DriverLatitude, DriverLongitude;
    String sFullAddress, sForemanLatitude, sForemanLongitude;

    private static final int REQUEST_LOCATION = 1;
    LocationManager locationManager;

    GPSTracker gpsTracker;

    public ForemanProfileFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_foreman_profile, container, false);


        firebaseApp = FirebaseApp.initializeApp(requireActivity());
        mAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();

        sp = requireActivity().getSharedPreferences(SharedPreferencesData.PREF, Context.MODE_PRIVATE);

        layout1 = view.findViewById(R.id.frag_foreman_profile_layout1);
        layout2 = view.findViewById(R.id.frag_foreman_profile_layout2);
        ProfileImage1 = view.findViewById(R.id.frag_foreman_profile_foremanProfileImage);
        ProfileImage2 = view.findViewById(R.id.frag_foreman_profile_userProfileImage2);
        FirstName = view.findViewById(R.id.frag_foreman_profile_FirstName);
        LastName = view.findViewById(R.id.frag_foreman_profile_LastName);
        Contact = view.findViewById(R.id.frag_foreman_profile_MobileNumber);
        Email = view.findViewById(R.id.frag_foreman_profile_Email);
        Address = view.findViewById(R.id.frag_foreman_profile_Address);
        Area = view.findViewById(R.id.frag_foreman_profile_Area);
        City = view.findViewById(R.id.frag_foreman_profile_City);
        State = view.findViewById(R.id.frag_foreman_profile_State);
        AccountStatus = view.findViewById(R.id.frag_foreman_profile_AccountStatus);
        FirstName_EditText = view.findViewById(R.id.frag_foreman_profile_FirstNameEditText);
        LastName_EditText = view.findViewById(R.id.frag_foreman_profile_LastNameEditText);
        Contact_EditText = view.findViewById(R.id.frag_foreman_profile_MobileNumberEditText);
        Email_EditText = view.findViewById(R.id.frag_foreman_profile_EmailEditText);
        Password_EditText = view.findViewById(R.id.frag_foreman_profile_PasswordEditText);
        Address_EditText = view.findViewById(R.id.frag_foreman_profile_AddressEditText);
        Area_EditText = view.findViewById(R.id.frag_foreman_profile_AreaEditText);
        City_EditText = view.findViewById(R.id.frag_foreman_profile_CityEditText);
        Spinner_State = view.findViewById(R.id.frag_foreman_profile_SpinnerState);
        EditTextButton = view.findViewById(R.id.frag_foreman_profile_EditProfileButton);
        UpdateButton = view.findViewById(R.id.frag_foreman_profile_UpdateButton);
        DeactivateButton1 = view.findViewById(R.id.frag_foreman_profile_deactivateButton);
        DeactivateButton2 = view.findViewById(R.id.frag_foreman_profile_deactivateButton2);

        layout2.setVisibility(View.GONE);

        gpsTracker = new GPSTracker(getActivity());

        // Check if GPS enabled
        if (gpsTracker.canGetLocation()) {

//            CurrentLatitude = gpsTracker.getLatitude();
//            CurrentLongitude = gpsTracker.getLongitude();

            //getLocation();

        } else {
            // Can't get location.
            // GPS or network is not enabled.
            // Ask user to enable GPS/network in settings.
            gpsTracker.showSettingsAlert();
        }


        // TODO Get Profile Image
        GetImageSp();

        FirstName.setText(sp.getString(SharedPreferencesData.FirstName, ""));
        LastName.setText(sp.getString(SharedPreferencesData.LastName, ""));
        Contact.setText(sp.getString(SharedPreferencesData.MobileNumber, ""));
        Email.setText(sp.getString(SharedPreferencesData.Email, ""));
        Address.setText(sp.getString(SharedPreferencesData.ForemanAddress, ""));
        Area.setText(sp.getString(SharedPreferencesData.ForemanArea, ""));
        City.setText(sp.getString(SharedPreferencesData.ForemanCity, ""));
        State.setText(sp.getString(SharedPreferencesData.ForemanState, ""));
        AccountStatus.setText(sp.getString(SharedPreferencesData.Account_Status, ""));

        EditTextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                layout2.setVisibility(View.VISIBLE);
                layout1.setVisibility(View.GONE);
            }
        });

        sState = "";
        arrayList = new ArrayList<>();
        arrayList.add("Select State");
        String S_array[] = ConstantData.State;
        List<String> list;
        list = Arrays.asList(S_array);
        arrayList.addAll(list);

        Spinner_State.setSelection(arrayList.indexOf("Select State"));
        ArrayAdapter adapter = new ArrayAdapter(getActivity(), android.R.layout.simple_list_item_1, arrayList);
        adapter.setDropDownViewResource(android.R.layout.simple_list_item_activated_1);
        Spinner_State.setAdapter(adapter);

        Spinner_State.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                sState = arrayList.get(i);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        UpdateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sFirstName = FirstName_EditText.getText().toString();
                sLastName = LastName_EditText.getText().toString();
                sContact = Contact_EditText.getText().toString();
                sEmail = Email_EditText.getText().toString();
                sPassword = Password_EditText.getText().toString();
                sAddress = Address_EditText.getText().toString();
                sArea = Area_EditText.getText().toString();
                sCity = City_EditText.getText().toString();

                if (sFirstName.isEmpty()) {
                    FirstName_EditText.setError("FirstName is Required");
                } else if (sLastName.isEmpty()) {
                    LastName_EditText.setError("LastName is Required");
                } else if (sContact.isEmpty()) {
                    Contact_EditText.setError("Mobile number is Required");
                } else if (sContact.length() != 10) {
                    Contact_EditText.setError("Mobile number is Not valid");
                } else if (sEmail.isEmpty()) {
                    Email_EditText.setError("Email is Required");
                } else if (!sEmail.matches(EmailPattern)) {
                    Email_EditText.setError("Valid Email is Required");
                } else if (sPassword.isEmpty()) {
                    Password_EditText.setError("Password is Required");
                } else if (sPassword.length() < 8) {
                    Password_EditText.setError("Password must be 8 char long");
                } else if (sAddress.isEmpty()) {
                    Address_EditText.setError("Address is Required");
                } else if (sArea.isEmpty()) {
                    Area_EditText.setError("Area is Required");
                } else if (sCity.isEmpty()) {
                    City_EditText.setError("City is Required");
                } else if (sState.isEmpty()) {
                    new CommonMethod(getActivity(), "State is Required");
                } else if (sState.equalsIgnoreCase("Select State")) {
                    new CommonMethod(getActivity(), "Not Valid State");
                } else {
                    UpdateSPProfileLocationData();
                    UpdateUserProfileImageData();
                    sp.edit().putString(SharedPreferencesData.ProfileImage, sImagePath2).commit();
                    UpdateUserProfileData();
                    UpdateUserPassword();

                }

            }
        });



        ProfileImage2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (checkAndRequestPermission()) {
                    selectImageMethod(view);
                }
            }
        });

        DeactivateButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DeactivateUserAccount();
            }
        });

        DeactivateButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DeactivateUserAccount();
            }
        });


        return view;
    }

    private void UpdateSPProfileLocationData() {

        String FullAddress = sp.getString(SharedPreferencesData.ForemanAddress, "") + "," + sp.getString(SharedPreferencesData.ForemanArea, "") + "," + sp.getString(SharedPreferencesData.ForemanCity, "") + "," + sp.getString(SharedPreferencesData.ForemanState, "");
        Geocoder coder = new Geocoder(getActivity());
        List<Address> address;
        try {
            // May throw an IOException
            address = coder.getFromLocationName(FullAddress, 5);
            if (address == null) {
                DriverLatitude = 0.00;
                DriverLongitude = 0.00;
            }
            Address location = address.get(0);

            DriverLatitude = location.getLatitude();
            DriverLongitude = location.getLongitude();
            //p1 = new LatLng(location.getLatitude(), location.getLongitude() );

        } catch (IOException ex) {

            ex.printStackTrace();
        }


        sForemanLatitude = String.valueOf(DriverLatitude);
        sForemanLongitude = String.valueOf(DriverLongitude);


    }

    // Todo Get Profile Image From Shared Preference
    private void GetImageSp() {
        String encodedSaveImage = sp.getString(SharedPreferencesData.ProfileImage, "");
        byte[] decodedString = Base64.decode(encodedSaveImage, Base64.DEFAULT);
        Bitmap decodeBitmap = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        if (decodeBitmap != null) {
            ProfileImage1.setImageBitmap(decodeBitmap);
            new CommonMethod(getActivity(), "Image Got from Sp");
        } else {
            getUserImage();
        }
    }

    // Todo Get Profile Image from Firebase
    private void getUserImage() {
        storageReference = FirebaseStorage.getInstance().getReference("images/userprofile/" + sp.getString(SharedPreferencesData.UserID, "") + ".jpg");
        try {
            File localfile = File.createTempFile("tempfile", ".jpg");
            storageReference.getFile(localfile).addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                    new CommonMethod(getActivity(), "Image Downloaded");
                    Bitmap bitmap1 = BitmapFactory.decodeFile(localfile.getAbsolutePath());
                    ProfileImage1.setImageBitmap(bitmap1);

                    SaveImageSp();// Save Image to Sp
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    new CommonMethod(getActivity(), "Image Not Downloaded");
                    ProfileImage1.setImageResource(R.drawable.ic_profile);//default image
                }

            });
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    // Todo Save Image to Shared Preference
    private void SaveImageSp() {
        BitmapDrawable bitmapDrawable = (BitmapDrawable) ProfileImage1.getDrawable();
        Bitmap bitmap = bitmapDrawable.getBitmap();

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream);
        byte[] byteArray = outputStream.toByteArray();
        String encodedImage = Base64.encodeToString(byteArray, Base64.DEFAULT);

        sp.edit().putString(SharedPreferencesData.ProfileImage, encodedImage).apply();

        new CommonMethod(getActivity(), "Image saved to shared preference");
    }

    // Todo Update Profile Image
    private void UpdateUserProfileImageData() {
        // Todo Delete Old Image
        storageReference = FirebaseStorage.getInstance().getReference("images/userprofile/" + sp.getString(SharedPreferencesData.UserID, "") + ".jpg");
        storageReference.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                new CommonMethod(getActivity(), "Image Deleted");
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                new CommonMethod(getActivity(), "Image Not Deleted");
            }
        });
        // Todo Upload New Image
        storageReference = FirebaseStorage.getInstance().getReference("images/userprofile/" + sp.getString(SharedPreferencesData.UserID, "") + ".jpg");
        storageReference.putFile(imageUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                new CommonMethod(getActivity(), "Image Uploaded");
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                new CommonMethod(getActivity(), "Image Not Uploaded");
            }
        });
    }

    private void getLocation() {
        if (ActivityCompat.checkSelfPermission(
                getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);
        } else {
            Location locationGPS = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (locationGPS != null) {
                double lat = locationGPS.getLatitude();
                double longi = locationGPS.getLongitude();
                DriverLatitude = lat;
                DriverLongitude = longi;
            } else {
                new CommonMethod(getActivity(), "Not Found");
            }
        }
    }


    private void DeactivateUserAccount() {

    }

    private void UpdateUserProfileData() {
        sp.edit().putString(SharedPreferencesData.FirstName, sFirstName).commit();
        sp.edit().putString(SharedPreferencesData.LastName, sLastName).commit();
        sp.edit().putString(SharedPreferencesData.MobileNumber, sContact).commit();
        sp.edit().putString(SharedPreferencesData.Email, sEmail).commit();
        sp.edit().putString(SharedPreferencesData.Password, sPassword).commit();
        sp.edit().putString(SharedPreferencesData.ForemanAddress, sAddress).commit();
        sp.edit().putString(SharedPreferencesData.ForemanArea, sArea).commit();
        sp.edit().putString(SharedPreferencesData.ForemanCity, sCity).commit();
        sp.edit().putString(SharedPreferencesData.ForemanState, sState).commit();

        FirstName.setText(sp.getString(SharedPreferencesData.FirstName, ""));
        LastName.setText(sp.getString(SharedPreferencesData.LastName, ""));
        Contact.setText(sp.getString(SharedPreferencesData.MobileNumber, ""));
        Email.setText(sp.getString(SharedPreferencesData.Email, ""));
        Address.setText(sp.getString(SharedPreferencesData.ForemanAddress, ""));
        Area.setText(sp.getString(SharedPreferencesData.ForemanArea, ""));
        City.setText(sp.getString(SharedPreferencesData.ForemanCity, ""));
        State.setText(sp.getString(SharedPreferencesData.ForemanState, ""));
        AccountStatus.setText(sp.getString(SharedPreferencesData.Account_Status, ""));

        String userID = Objects.requireNonNull(mAuth.getCurrentUser()).getUid();
        DocumentReference documentReference = fStore.collection("Users").document(userID);
        new CommonMethod(getActivity(), "User ID" + userID);
        Map<String, Object> user = new HashMap<>();
        user.put("FirstName", sp.getString(SharedPreferencesData.FirstName, ""));
        user.put("LastName", sp.getString(SharedPreferencesData.LastName, ""));
        user.put("MobileNumber", sp.getString(SharedPreferencesData.MobileNumber, ""));
        user.put("Email", sp.getString(SharedPreferencesData.Email, ""));
        user.put("ForemanAddress", sp.getString(SharedPreferencesData.ForemanAddress, ""));
        user.put("ForemanArea", sp.getString(SharedPreferencesData.ForemanArea, ""));
        user.put("ForemanCity", sp.getString(SharedPreferencesData.ForemanCity, ""));
        user.put("ForemanState", sp.getString(SharedPreferencesData.ForemanState, ""));
        user.put("sForemanLatitude", sForemanLatitude);
        user.put("sForemanLongitude", sForemanLongitude);
        user.put("Account_Status", "Verified");
        documentReference.update(user).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                new CommonMethod(getActivity(), "Information Updated");

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                new CommonMethod(getActivity(), "Information Not Updated");
            }
        });

    }


    private void otpSendToMobile(String sPhone) {

        mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

            @Override
            public void onVerificationCompleted(PhoneAuthCredential credential) {

            }

            @Override
            public void onVerificationFailed(FirebaseException e) {

                new CommonMethod(getActivity(), e.getLocalizedMessage());
            }

            @Override
            public void onCodeSent(@NonNull String VerificationId,
                                   @NonNull PhoneAuthProvider.ForceResendingToken token) {


                new CommonMethod(getActivity(), "OTP is successFully Send");

                bundle.putString("PhoneNumber", sPhone.trim());
                bundle.putString("Mobile_VerificationID", VerificationId);
                Intent intent = new Intent(getActivity(), OTPVerificationActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        };

        PhoneAuthOptions options =
                PhoneAuthOptions.newBuilder(mAuth)
                        .setPhoneNumber("+880" + sPhone.trim())
                        .setTimeout(60L, TimeUnit.SECONDS)
                        .setActivity(getActivity())
                        .setCallbacks(mCallbacks)
                        .build();
        PhoneAuthProvider.verifyPhoneNumber(options);

    }

    // Todo Update Password
    private void UpdateUserPassword() {
        Objects.requireNonNull(mAuth.getCurrentUser()).updatePassword(sPassword);
        new CommonMethod(getActivity(), "Password Updated");
    }

    public void selectImageMethod(View view) {
        Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
        photoPickerIntent.setType("image/*");
        someActivityResultLauncher.launch(photoPickerIntent);
    }

    ActivityResultLauncher<Intent> someActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    // There are no request codes
                    // doSomeOperations();
                    Intent data = result.getData();
                    imageUri = Objects.requireNonNull(data).getData();
                    Log.d("RESPONSE_URI", String.valueOf(imageUri));
                    ProfileImage2.setImageURI(imageUri);
                }
            });


    public boolean checkAndRequestPermission() {
        List<String> listPermission = new ArrayList<>();
        for (String perm : appPermission) {
            if (ContextCompat.checkSelfPermission(requireActivity(), perm) != PackageManager.PERMISSION_GRANTED) {
                listPermission.add(perm);
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(requireActivity(), Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED) {

                listPermission.add(Manifest.permission.READ_MEDIA_IMAGES);
            }
        }
        if (listPermission.size() >= 2) {
            ActivityCompat.requestPermissions(requireActivity(), listPermission.toArray(new String[0]), PERMISSION_REQUEST_CODE);
            return false;
        }
        return true;
    }


}