package com.brainybeam.roadsideassistance.Admin.AdminCredential;

public class AdminCredential {

    public static final String AdminEmail[] = {

            "admin@gmail.com",
            "adminsupti@gmail.com"

    };

    public static final String AdminPassword[] = {
            "admin",
            "007007"
    };

}
