package com.brainybeam.roadsideassistance.User.DashBoard;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.User.Activity.AddVehicleActivity;
import com.brainybeam.roadsideassistance.User.CustomArrayList.UserVehicleList;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConnectionDetector;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Objects;


public class UserAddVehicleDetailFragment extends Fragment {


    RecyclerView recyclerView;
    FloatingActionButton floatingActionButton;

    public ArrayList<UserVehicleList> arrayList;
    SharedPreferences sp;
    FirebaseAuth mAuth;
    FirebaseFirestore fStore;

    public UserAddVehicleDetailFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_user_add_vehicle_detail, container, false);

        sp = requireActivity().getSharedPreferences(SharedPreferencesData.PREF, Context.MODE_PRIVATE);
        mAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();

        recyclerView = view.findViewById(R.id.frag_user_Addvehicle_recyclerview);
        floatingActionButton = view.findViewById(R.id.frag_user_Addvehicle_floatingAddButton);

        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CommonMethod(getActivity(), AddVehicleActivity.class);
            }
        });

        if (new ConnectionDetector(getActivity()).isConnectingToInternet()) {
            recyclerViewDataSetMethod();

        } else {
            new ConnectionDetector(getActivity()).connectiondetect();
        }

        return view;
    }

    private void recyclerViewDataSetMethod() {
        arrayList = new ArrayList<>();
        String userID = Objects.requireNonNull(mAuth.getCurrentUser()).getUid();
        Task<QuerySnapshot> documentReference = fStore.collection("Vehicles").whereEqualTo("userID", userID).get();
        documentReference.addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful() && task.getResult() != null) {
                    for (DocumentSnapshot document : task.getResult()) {
                        UserVehicleList list = new UserVehicleList();
                        list.setVehicleID(document.getString("vehicleID"));
                        list.setUserID(document.getString("userID"));
                        list.setNumberPlate_number(document.getString("numberPlateNumber"));
                        list.setTypeOfVehicle(document.getString("typeOfVehicle"));
                        list.setVehicleModelName(document.getString("vehicleModelName"));
                        list.setVehicle_Colour(document.getString("vehicleColour"));
                        arrayList.add(list);
                    }
                    UserVehicleDetailAdapter adapter = new UserVehicleDetailAdapter(getActivity(), arrayList);
                    recyclerView.setAdapter(adapter);
                    adapter.notifyDataSetChanged();
                }
            }
        });
    }
}