package com.brainybeam.roadsideassistance.RetrofitData;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class GetUserHistoryData {

    @SerializedName("Status")
    @Expose
    public Boolean status;
    @SerializedName("Message")
    @Expose
    public String message;
    @SerializedName("response")
    @Expose
    public List<GetUserHistoryResponse> response = null;


    public class GetUserHistoryResponse {


        @SerializedName("HistoryID")
        @Expose
        public String historyID;
        @SerializedName("ServiceID")
        @Expose
        public String serviceID;
        @SerializedName("ForemanID")
        @Expose
        public String foremanID;
        @SerializedName("UserID")
        @Expose
        public String userID;
        @SerializedName("VehicleID")
        @Expose
        public String vehicleID;
        @SerializedName("ProblemDescriptionMessage")
        @Expose
        public String problemDescriptionMessage;
        @SerializedName("PaymentID")
        @Expose
        public String paymentID;
        @SerializedName("SPReqMoney")
        @Expose
        public String sPReqMoney;
        @SerializedName("PaymentMode")
        @Expose
        public String paymentMode;
        @SerializedName("Payment")
        @Expose
        public String payment;
        @SerializedName("UserLocation")
        @Expose
        public String userLocation;
        @SerializedName("PaymentDate")
        @Expose
        public String paymentDate;
        @SerializedName("FirstName")
        @Expose
        public String firstName;
        @SerializedName("LastName")
        @Expose
        public String lastName;
        @SerializedName("ProfileImage")
        @Expose
        public String profileImage;
        @SerializedName("MobileNumber")
        @Expose
        public String mobileNumber;
        @SerializedName("Address")
        @Expose
        public String address;
        @SerializedName("TypeOfProblem")
        @Expose
        public String typeOfProblem;
        @SerializedName("ProblemSubType")
        @Expose
        public String problemSubType;
        @SerializedName("ServiceFixedCharge")
        @Expose
        public String serviceFixedCharge;
        @SerializedName("NumberPlate_number")
        @Expose
        public String numberPlateNumber;
        @SerializedName("TypeOfVehicle")
        @Expose
        public String typeOfVehicle;
        @SerializedName("VehicleModelName")
        @Expose
        public String vehicleModelName;
        @SerializedName("Vehicle_Colour")
        @Expose
        public String vehicleColour;

    }

}
