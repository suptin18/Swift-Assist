package com.brainybeam.roadsideassistance.Admin.DashBoard;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentManager;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.brainybeam.roadsideassistance.Foreman.DashBoard.ForemanDashboardActivity;
import com.brainybeam.roadsideassistance.Foreman.DashBoard.ForemanHomeFragment;
import com.brainybeam.roadsideassistance.Login.LoginActivity;
import com.brainybeam.roadsideassistance.Notification.ForemanNotificationActivity;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConnectionDetector;
import com.brainybeam.roadsideassistance.Utils.ConstantData;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;
import com.google.android.material.navigation.NavigationView;

public class AdminDashboardActivity extends AppCompatActivity {

    TextView Title_menu;
    ImageView menu_image, calling_image, Notification_image;

    // TODO Navigation
    LinearLayout nav_header_home_layout,  nav_header_NewForemanRequest_layout, nav_header_ActiveUsers_layout,
            nav_header_ActiveServiceProvider_layout, nav_header_Logout_layout;

    ImageView nav_header_home_image_logo,  nav_header_NewForemanRequest_image_logo, nav_header_ActiveUsers_image_logo,
            nav_header_ActiveServiceProvider_image_logo, nav_header_Logout_image_logo;

    TextView nav_header_home_TextButton,  nav_header_NewForemanRequest_TextButton, nav_header_ActiveUsers_TextButton,
            nav_header_ActiveServiceProvider_TextButton, nav_header_Logout_TextButton;

    SharedPreferences sp;

    ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);
//        getSupportActionBar().setTitle("Home");
//        ColorDrawable colorDrawable
//                = new ColorDrawable(Color.parseColor("#2196F3"));
//        getSupportActionBar().setBackgroundDrawable(colorDrawable);
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        sp = getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);



        pd = new ProgressDialog(AdminDashboardActivity.this);
        pd.setMessage("Network Connecting...");
        pd.setCancelable(false);
        pd.show();

        if(new ConnectionDetector(AdminDashboardActivity.this).isConnectingToInternet()){
            pd.dismiss();
        } else {

            if(!new ConnectionDetector(AdminDashboardActivity.this).isConnectingToInternet()){
                pd.setMessage("Please Check Your Network");
            }
            new ConnectionDetector(AdminDashboardActivity.this).connectiondetect();
            pd.dismiss();
        }


        // TODO Tab activity Start

        Title_menu = findViewById(R.id.admin_content_main_dashboard_title);
        Title_menu.setText("Home");

        final DrawerLayout drawer = (DrawerLayout) findViewById(R.id.admin_drawer_layout);
        menu_image = findViewById(R.id.admin_content_main_dashboard_menu_imageButton);
        menu_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                drawer.openDrawer(GravityCompat.START);

            }
        });

        calling_image = findViewById(R.id.admin_content_main_dashboard_call_imageButton);
        calling_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder builder = new AlertDialog.Builder(AdminDashboardActivity.this);
                builder.setTitle("Call Assistance Center?");
                builder.setPositiveButton("CALL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent = new Intent(Intent.ACTION_CALL);
                        intent.setData(Uri.parse("tel:"+ ConstantData.Call_Assistance_MobileNumber));
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                                // TODO: Consider calling
                                //    Activity#requestPermissions
                                // here to request the missing permissions, and then overriding
                                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                //                                          int[] grantResults)
                                // to handle the case where the user grants the permission. See the documentation
                                // for Activity#requestPermissions for more details.
                                return;
                            }
                        }
                        startActivity(intent);
                    }
                });

                builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                });
                builder.show();

            }
        });
        // TODO Tab activity finished

        Notification_image = findViewById(R.id.admin_content_main_dashboard_Notification_image);
        Notification_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CommonMethod(AdminDashboardActivity.this, AdminDashboardActivity.class);
            }
        });





        // TODO Default Fragment
        drawer.closeDrawer(GravityCompat.START);
        FragmentManager manager = getSupportFragmentManager();
        manager.beginTransaction()
                .replace(R.id.admin_content_main_dashboard_FragmentContainerView, new AdminHomeFragment(), null)
                .setReorderingAllowed(true)
                .addToBackStack("")
                .commit();



        // TODO ----------------------------------------------------------------
        // TODO                NavigationView Start
        // TODO ----------------------------------------------------------------

        NavigationView navigationView = (NavigationView) findViewById(R.id.admin_dashboard_nav_view);
        View header = navigationView.getHeaderView(0);


        nav_header_home_layout = header.findViewById(R.id.admin_nav_header_home_layout);
        nav_header_NewForemanRequest_layout = header.findViewById(R.id.admin_nav_header_NewForemanRequest_layout);
        nav_header_ActiveUsers_layout = header.findViewById(R.id.admin_nav_header_activeUsers_layout);
        nav_header_ActiveServiceProvider_layout = header.findViewById(R.id.admin_nav_header_activeServiceProvider_layout);
        nav_header_Logout_layout = header.findViewById(R.id.admin_nav_header_logout_layout);

        nav_header_home_image_logo = header.findViewById(R.id.admin_nav_header_home_imageview_logo);
        nav_header_NewForemanRequest_image_logo  = header.findViewById(R.id.admin_nav_header_NewForemanRequest_imageview_logo);
        nav_header_ActiveUsers_image_logo  = header.findViewById(R.id.admin_nav_header_activeUsers_imageview_logo);
        nav_header_ActiveServiceProvider_image_logo  = header.findViewById(R.id.admin_nav_header_activeServiceProvider_imageview_logo);
        nav_header_Logout_image_logo  = header.findViewById(R.id.admin_nav_header_logout_imageview_logo);

        nav_header_home_TextButton = header.findViewById(R.id.admin_nav_header_home_TextButton);
        nav_header_NewForemanRequest_TextButton = header.findViewById(R.id.admin_nav_header_NewForemanRequest_TextButton);
        nav_header_ActiveUsers_TextButton = header.findViewById(R.id.admin_nav_header_activeUsers_TextButton);
        nav_header_ActiveServiceProvider_TextButton = header.findViewById(R.id.admin_nav_header_activeServiceProvider_TextButton);
        nav_header_Logout_TextButton = header.findViewById(R.id.admin_nav_header_logout_TextButton);



        // TODO Admin Home Fragment
        nav_header_home_TextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Home");
                drawer.closeDrawer(GravityCompat.START);
                FragmentManager manager = getSupportFragmentManager();

                manager.beginTransaction()
                        .replace(R.id.admin_content_main_dashboard_FragmentContainerView, new AdminHomeFragment(), null)
                        .setReorderingAllowed(true)
                        .addToBackStack("")
                        .commit();
            }
        });

        nav_header_home_image_logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Home");
                drawer.closeDrawer(GravityCompat.START);
                FragmentManager manager = getSupportFragmentManager();

                manager.beginTransaction()
                        .replace(R.id.admin_content_main_dashboard_FragmentContainerView, new AdminHomeFragment(), null)
                        .setReorderingAllowed(true)
                        .addToBackStack("")
                        .commit();
            }
        });

        nav_header_home_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Home");
                drawer.closeDrawer(GravityCompat.START);
                FragmentManager manager = getSupportFragmentManager();

                manager.beginTransaction()
                        .replace(R.id.admin_content_main_dashboard_FragmentContainerView, new AdminHomeFragment(), null)
                        .setReorderingAllowed(true)
                        .addToBackStack("")
                        .commit();
            }
        });

        // TODO Admin New Foreman Request Fragment
        nav_header_NewForemanRequest_TextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("New Foreman Request");
                drawer.closeDrawer(GravityCompat.START);
                FragmentManager manager = getSupportFragmentManager();

                manager.beginTransaction()
                        .replace(R.id.admin_content_main_dashboard_FragmentContainerView, new AdminNewForemanRequestFragment(), null)
                        .setReorderingAllowed(true)
                        .addToBackStack("")
                        .commit();
            }
        });

        nav_header_NewForemanRequest_image_logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("New Foreman Request");
                drawer.closeDrawer(GravityCompat.START);
                FragmentManager manager = getSupportFragmentManager();

                manager.beginTransaction()
                        .replace(R.id.admin_content_main_dashboard_FragmentContainerView, new AdminNewForemanRequestFragment(), null)
                        .setReorderingAllowed(true)
                        .addToBackStack("")
                        .commit();
            }
        });

        nav_header_NewForemanRequest_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("New Foreman Request");
                drawer.closeDrawer(GravityCompat.START);
                FragmentManager manager = getSupportFragmentManager();

                manager.beginTransaction()
                        .replace(R.id.admin_content_main_dashboard_FragmentContainerView, new AdminNewForemanRequestFragment(), null)
                        .setReorderingAllowed(true)
                        .addToBackStack("")
                        .commit();
            }
        });


        // TODO Admin Active Users Fragment
        nav_header_ActiveUsers_TextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Active Users");
                drawer.closeDrawer(GravityCompat.START);
                FragmentManager manager = getSupportFragmentManager();

                manager.beginTransaction()
                        .replace(R.id.admin_content_main_dashboard_FragmentContainerView, new AdminActiveUsersFragment(), null)
                        .setReorderingAllowed(true)
                        .addToBackStack("")
                        .commit();
            }
        });

        nav_header_ActiveUsers_image_logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Active Users");
                drawer.closeDrawer(GravityCompat.START);
                FragmentManager manager = getSupportFragmentManager();

                manager.beginTransaction()
                        .replace(R.id.admin_content_main_dashboard_FragmentContainerView, new AdminActiveUsersFragment(), null)
                        .setReorderingAllowed(true)
                        .addToBackStack("")
                        .commit();
            }
        });

        nav_header_ActiveUsers_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Active Users");
                drawer.closeDrawer(GravityCompat.START);
                FragmentManager manager = getSupportFragmentManager();

                manager.beginTransaction()
                        .replace(R.id.admin_content_main_dashboard_FragmentContainerView, new AdminActiveUsersFragment(), null)
                        .setReorderingAllowed(true)
                        .addToBackStack("")
                        .commit();
            }
        });

        // TODO Admin Active Service Providers Fragment
        nav_header_ActiveServiceProvider_TextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Active Service Providers");
                drawer.closeDrawer(GravityCompat.START);
                FragmentManager manager = getSupportFragmentManager();

                manager.beginTransaction()
                        .replace(R.id.admin_content_main_dashboard_FragmentContainerView, new AdminActiveServiceProviderFragment(), null)
                        .setReorderingAllowed(true)
                        .addToBackStack("")
                        .commit();
            }
        });

        nav_header_ActiveServiceProvider_image_logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Active Service Providers");
                drawer.closeDrawer(GravityCompat.START);
                FragmentManager manager = getSupportFragmentManager();

                manager.beginTransaction()
                        .replace(R.id.admin_content_main_dashboard_FragmentContainerView, new AdminActiveServiceProviderFragment(), null)
                        .setReorderingAllowed(true)
                        .addToBackStack("")
                        .commit();
            }
        });

        nav_header_ActiveServiceProvider_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Active Service Providers");
                drawer.closeDrawer(GravityCompat.START);
                FragmentManager manager = getSupportFragmentManager();

                manager.beginTransaction()
                        .replace(R.id.admin_content_main_dashboard_FragmentContainerView, new AdminActiveServiceProviderFragment(), null)
                        .setReorderingAllowed(true)
                        .addToBackStack("")
                        .commit();
            }
        });

        // TODO Admin Logout Fragment
        nav_header_Logout_TextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Logout");
                sp.edit().clear().commit();
                startActivity(new Intent(AdminDashboardActivity.this, LoginActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
            }
        });

        nav_header_Logout_image_logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Logout");
                sp.edit().clear().commit();
                startActivity(new Intent(AdminDashboardActivity.this, LoginActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
            }
        });

        nav_header_Logout_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Logout");
                sp.edit().clear().commit();
                startActivity(new Intent(AdminDashboardActivity.this, LoginActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
            }
        });

    }



    @Override
    public void onBackPressed() {
//        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.foreman_drawer_layout);
//        if (drawer.isDrawerOpen(GravityCompat.START)) {
//            drawer.closeDrawer(GravityCompat.START);
//        } else {
//            //super.onBackPressed();
        super.onBackPressed();
        AlertDialog.Builder builder = new AlertDialog.Builder(AdminDashboardActivity.this);
            builder.setTitle(getResources().getString(R.string.app_name));
            builder.setMessage("Are You Sure Want To Exit!");
            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    finishAffinity();
                }
            });
            builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            });
            builder.show();
       // }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_notification, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
        }
        if(id == R.id.notification_menu){
            new CommonMethod(AdminDashboardActivity.this, AdminDashboardActivity.class);
        }
        return super.onOptionsItemSelected(item);
    }


}