package com.brainybeam.roadsideassistance.Foreman.DashBoard;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.brainybeam.roadsideassistance.Foreman.CustomArrayList.ForemanUserSelectedServicesList;
import com.brainybeam.roadsideassistance.GPS.GPSTracker;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.GetForemanUserSelectedServicesData;
import com.brainybeam.roadsideassistance.User.Activity.UserForemanServicesActivity;
import com.brainybeam.roadsideassistance.User.Activity.UserVehicleSelectionActivity;
import com.brainybeam.roadsideassistance.User.Activity.UserVehicleSelectionAdapter;
import com.brainybeam.roadsideassistance.User.CustomArrayList.UserForemanServiceList;
import com.brainybeam.roadsideassistance.User.CustomArrayList.UserVehicleList;
import com.brainybeam.roadsideassistance.User.DashBoard.UserVehicleDetailAdapter;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConnectionDetector;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class NewUserRequestReceiveFragment extends Fragment {

    RecyclerView recyclerView;

    ArrayList<ForemanUserSelectedServicesList> arrayList;

    SharedPreferences sp;
    FirebaseAuth mAuth;
    FirebaseFirestore fStore;

    GPSTracker gpsTracker;
    double CurrentLatitude, CurrentLongitude;

    String sForemanAddress, sForemanLatitude, sForemanLongitude;

    private static final int REQUEST_LOCATION = 1;
    LocationManager locationManager;

    public NewUserRequestReceiveFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_new_user_request_receive, container, false);

        sp = getActivity().getSharedPreferences(SharedPreferencesData.PREF, Context.MODE_PRIVATE);
        mAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();

        recyclerView = view.findViewById(R.id.frag_foreman_newUser_requestReceive_recyclerview);

        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        locationManager = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);
        if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            OnGPS();
        } else {
            getLocation();
        }
//        GPSTracker gpsTracker = new GPSTracker(getActivity());
//
        Geocoder geocoder = new Geocoder(getActivity(), Locale.getDefault());
        List<Address> addresses = null;
        try {
            addresses = geocoder.getFromLocation(CurrentLatitude, CurrentLongitude, 1);
            String add = addresses.toString();
//            String city = addresses.get(0).getLocality();
//            String state = addresses.get(0).getAdminArea();
//            String zip = addresses.get(0).getPostalCode();
//            String country = addresses.get(0).getCountryName();

//            CurrentLatitude = gpsTracker.getLatitude();
//            CurrentLongitude = gpsTracker.getLongitude();
            sForemanAddress = add;
        } catch (IOException e) {
            e.printStackTrace();
        }

        sp.edit().putString(SharedPreferencesData.Foreman_ForemanCurrLocation, sForemanAddress).commit();

        if (new ConnectionDetector(getActivity()).isConnectingToInternet()) {

            recyclerViewDataSetMethod();

        } else {
            new ConnectionDetector(getActivity()).connectiondetect();
        }

        return view;
    }

    private void OnGPS() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setMessage("Enable GPS").setCancelable(false).setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
            }
        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        final AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private void getLocation() {
        if (ActivityCompat.checkSelfPermission(
                getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);
        } else {
            Location locationGPS = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (locationGPS != null) {
                double lat = locationGPS.getLatitude();
                double longi = locationGPS.getLongitude();
                CurrentLatitude = lat;
                CurrentLongitude = longi;
            } else {
                new CommonMethod(getActivity(), "Not Found");
            }
        }
    }

    private void recyclerViewDataSetMethod() {

        arrayList = new ArrayList<>();
        String userID = Objects.requireNonNull(mAuth.getCurrentUser()).getUid();
        Task<QuerySnapshot> documentReference = fStore.collection("Cart").whereEqualTo("foremanID", userID).get();
        documentReference.addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful() && task.getResult() != null) {
                    for (DocumentSnapshot document : task.getResult()) {
                        ForemanUserSelectedServicesList list = new ForemanUserSelectedServicesList();

                        list.setCartID(document.getString("cartID"));
                        list.setServiceID(document.getString("serviceID"));
                        list.setForemanID(document.getString("foremanID"));
                        list.setUserID(document.getString("userID"));
                        list.setVehicleID(document.getString("vehicleID"));
                        list.setProblemDescriptionMessage(document.getString("problemDescriptionMessage"));
                        list.setSPReqMoney(document.getString("sPReqMoney"));
                        list.setUserLocation(document.getString("userLocation"));
                        list.setPaymentStatus(document.getString("paymentStatus"));
                        list.setTypeOfProblem(document.getString("typeOfProblem"));
                        list.setProblemSubType(document.getString("problemSubType"));
                        list.setServiceFixedCharge(document.getString("serviceFixedCharge"));
                        list.setUserFirstName(document.getString("firstName"));
                        list.setUserLastName(document.getString("lastName"));
                        list.setUserProfileImage(document.getString("profileImage"));
                        list.setUserMobileNumber(document.getString("mobileNumber"));
                        list.setNumberPlate_number(document.getString("numberPlateNumber"));
                        list.setTypeOfVehicle(document.getString("typeOfVehicle"));
                        list.setVehicleModelName(document.getString("vehicleModelName"));
                        list.setVehicle_Colour(document.getString("vehicleColour"));

                        arrayList.add(list);
                    }
                    ForemanUserSelectedServicesAdapter adapter = new ForemanUserSelectedServicesAdapter(getActivity(), arrayList);
                    recyclerView.setAdapter(adapter);
                    adapter.notifyDataSetChanged();
                }
            }
        });


    }
}