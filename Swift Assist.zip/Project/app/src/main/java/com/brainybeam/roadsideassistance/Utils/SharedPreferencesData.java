package com.brainybeam.roadsideassistance.Utils;

public class SharedPreferencesData {

    public static final String PREF = "pref";

    // TODO User, Foreman
    public static final String UserType = "UserType";

    // TODO User, Foreman
    public static final String UserID = "UserID";
    public static final String FirstName = "FirstName";
    public static final String LastName = "LastName";
    public static final String ProfileImage = "ProfileImage";
    public static final String MobileNumber = "MobileNumber";
    public static final String Email = "Email";
    public static final String Password = "Password";
    public static final String Account_Status = "Status";

    public static final String ForemanAddress = "ForemanAddress";
    public static final String ForemanArea = "ForemanArea";
    public static final String ForemanCity = "ForemanCity";
    public static final String ForemanState = "ForemanState";

    // TODO Accepted OR Canceled Foreman Account by Admin After
    public static final String ForemanAccount_Status = "ForemanStatus";

    public static final String FCMID = "FCMID";
    public static final String UserFCMID = "UserFCMID";
    public static final String ForemanFCMID = "ForemanFCMID";
    public static final String AdminFCMID = "AdminFCMID";




    // TODO ----------------------------------
    // TODO ===>>      User
    // TODO ----------------------------------

    // Number Plate Number/Registration Number of Vehicle:
    public static final String VehicleID = "VehicleID";
    public static final String NumberPlate_number = "Registration Number of Vehicle";
    // 2-Wheeler, 4-Wheeler, Heavy Motor Vehicles
    public static final String TypeOfVehicle = "TypeOfVehicle";
    public static final String VehicleModelName = "VehicleModelName";
    public static final String Vehicle_Colour = "VehicleColour";


    public static final String UserSelectionCount = "UserSelectionCount";
    public static final String UserTypeOfProblem = "TypeOfProblem";
    public static final String UserTypeOfSubProblem = "TypeOfSubProblem";

    // TODO ----------------------------------
    // TODO ===>>      Service Provider
    // TODO ----------------------------------

    public static final String ServiceProviderID = "ServiceProviderID";
    public static final String ServiceProviderMobileNumber = "ServiceProviderMobileNumber";
    public static final String TypeOfProblemService = "TypeOfProblemServices";
    public static final String TypeOfSubProblemServices = "TypeOfSubProblemServices";
    public static final String ServiceFixCharge = "ServiceFixCharge";
    public static final String ForemanRating = "ForemanRating";

    public static final String User_OrderID = "User_OrderID";
    public static final String Foreman_OrderID = "Foreman_OrderID";
    public static final String User_ID = "User_ID";
    public static final String User_MobileNUmber = "User_MobileNUmber";
    public static final String Foreman_ID = "Foreman_ID";
    public static final String Foreman_MobileNUmber = "Foreman_MobileNUmber";
    public static final String User_LATITUDE = "User_Latitude";
    public static final String User_LONGITUDE = "User_Longitude";
    public static final String Foreman_LATITUDE = "Foreman_Latitude";
    public static final String Foreman_LONGITUDE = "Foreman_Longitude";


    // TODO ----------------------------------
    // TODO ===>>      User
    // TODO ----------------------------------

    public static final String User_ForemanID = "User_ForemanID";

    public static final String User_ForemanFirstName = "User_ForemanFirstName";
    public static final String User_ForemanLastName = "User_ForemanLastName";

    public static final String User_VehicleID = "User_VehicleID";
    public static final String User_NumberPlate_number = "User_NumberPlate_number";
    public static final String User_TypeOfVehicle = "User_TypeOfVehicle";
    public static final String User_VehicleModelName = "User_VehicleModelName";
    public static final String User_Vehicle_Colour = "User_Vehicle_Colour";

    public static final String User_ServiceID = "User_ServiceID";

    public static final String User_TypeOfProblem = "User_TypeOfProblem";
    public static final String User_ProblemSubType = "User_ProblemSubType";
    public static final String User_FixCharge = "User_FixCharge";
    public static final String User_DistanceWithForeman = "User_DistanceWithForeman";

    public static final String User_CartID = "User_CartID";

    public static final String User_ForemanProfileImage = "User_ForemanProfileImage";

    public static final String User_UserMobileNumber = "User_UserMobileNumber";
    public static final String User_ForemanMobileNumber = "User_ForemanMobileNumber";
    public static final String User_SPReqMoney = "User_SPReqMoney";
    public static final String User_PaymentID = "User_PaymentID";
    public static final String User_Payment = "User_Payment";
    public static final String User_PaymentMode = "User_PaymentMode";
    public static final String User_PaymentStatus = "User_PaymentStatus";
    public static final String User_UserLocation = "User_UserLocation";
    public static final String User_UserLatitude = "User_UserLatitude";
    public static final String User_UserLongitude = "User_UserLongitude";
    public static final String User_ForemanLatitude = "User_ForemanLatitude";
    public static final String User_ForemanLongitude = "User_ForemanLongitude";

    public static final String User_DescriptionMessage = "User_DescriptionMessage";

    public static final String User_ForemanCurrLatitude = "User_ForemanCurrLatitude";
    public static final String User_ForemanCurrLongitude = "User_ForemanCurrLongitude";
    public static final String User_ForemanLocationID = "User_ForemanLocationID";
    public static final String User_UserCurrLatitude = "User_UserCurrLatitude";
    public static final String User_UserCurrLongitude = "User_UserCurrLongitude";
    public static final String User_UserLocationID = "User_UserLocationID";
    // public static final String User_ = "User_";

    // TODO ----------------------------------
    // TODO ===>>      Service Provider
    // TODO ----------------------------------

    public static final String Foreman_UserID = "Foreman_UserID";

    public static final String Foreman_UserFirstName = "Foreman_UserFirstName";
    public static final String Foreman_UserLastName = "Foreman_UserLastName";
    public static final String Foreman_UserProfileImage = "Foreman_UserProfileImage";

    public static final String Foreman_ServiceID = "Foreman_ServiceID";
    public static final String Foreman_UserTypeOfProblem = "Foreman_UserTypeOfProblem";
    public static final String Foreman_UserProblemSubType = "Foreman_UserProblemSubType";
    public static final String Foreman_UserServiceFixCharge = "Foreman_UserServiceCharge";

    public static final String Foreman_UserVehicleID = "Foreman_UserVehicleID";
    public static final String Foreman_UserVehicleNumber = "Foreman_UserVehicleNumber";
    public static final String Foreman_UserTypeOfVehicle = "Foreman_UserTypeOfVehicle";
    public static final String Foreman_UserVehicleModelName = "Foreman_UserVehicleModelName";
    public static final String Foreman_UserVehicleColor = "Foreman_UserVehicleColor";


    public static final String Foreman_CartID = "Foreman_CartID";
    public static final String Foreman_UserDescriptionMessage = "Foreman_UserDescriptionMessage";

    public static final String Foreman_UserMobileNumber = "Foreman_UserMobileNumber";
    public static final String Foreman_ForemanMobileNumber = "Foreman_ForemanMobileNumber";
    public static final String Foreman_SPReqMoney = "Foreman_SPReqMoney";
    public static final String Foreman_UserPayment = "Foreman_UserPayment";
    public static final String Foreman_UserPaymentMode = "Foreman_UserPaymentMode";
    public static final String Foreman_UserPaymentStatus = "Foreman_UserPaymentStatus";
    public static final String Foreman_UserLocation = "Foreman_UserLocation";
    public static final String Foreman_UserLatitude = "Foreman_UserLatitude";
    public static final String Foreman_UserLongitude = "Foreman_UserLongitude";
    public static final String Foreman_ForemanLatitude = "Foreman_ForemanLatitude";
    public static final String Foreman_ForemanLongitude = "Foreman_ForemanLongitude";
    public static final String Foreman_ForemanLocation = "Foreman_ForemanLocation";
    public static final String Foreman_ForemanCurrLocation = "Foreman_ForemanCurrLocation";

    public static final String Foreman_UserCurrLatitude = "Foreman_UserCurrLatitude";
    public static final String Foreman_UserCurrLongitude = "Foreman_UserCurrLongitude";
    public static final String Foreman_UserLocationID = "Foreman_UserLocationID";
    public static final String Foreman_ForemanCurrLatitude = "Foreman_ForemanCurrLatitude";
    public static final String Foreman_ForemanCurrLongitude = "Foreman_ForemanCurrLongitude";
    public static final String Foreman_ForemanLocationID = "Foreman_ForemanLocationID";


    // TODO ------------------------------------------
    // TODO ------------------------------------------
    // TODO ------------------------------------------
    public static final String Admin_FCMID = "Admin_FCMID";
    public static final String Admin_NumberOfUsers = "Admin_NumberOfUsers";
    public static final String Admin_NumberOfForeman = "Admin_NumberOfForeman";
    public static final String Admin_NumberOfTotleUsers = "Admin_NumberOfTotleUsers";

    public static final String Foreman_Rating_ratingAboveFour = "Foreman_Rating_ratingAboveFour";
    public static final String Foreman_Rating_ratingAboveFourBetweenTwo = "Foreman_Rating_ratingAboveFourBetweenTwo";
    public static final String Foreman_Rating_ratingLessThenTwo = "Foreman_Rating_ratingLessThenTwo";


    public static final String AdminLoginState = "AdminLoginState";
    public static final String UserEnable = "UserEnable";
    public static final String ForemanEnable = "ForemanEnable";

    public static String Active_Status = "Active_Status";
}
