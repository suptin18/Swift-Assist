package com.brainybeam.roadsideassistance.Foreman.CustomArrayList;

public class PendingPaymentList {

    String CartID, ServiceID, ForemanID, UserID, VehicleID;
    String ProblemDescriptionMessage, SPReqMoney, PaymentMode, Payment, PaymentStatus;
    String TypeOfProblem, ProblemSubType, ServiceFixedCharge, UserFirstName, UserLastName, UserProfileImage, UserMobileNumber;
    String NumberPlate_number, TypeOfVehicle, VehicleModelName, Vehicle_Colour;
    String ForemanLocationID, ForemanLatitude, ForemanLongitude;
    String UserLocationID, UserLatitude, UserLongitude;

    public String getCartID() {
        return CartID;
    }

    public void setCartID(String cartID) {
        CartID = cartID;
    }

    public String getServiceID() {
        return ServiceID;
    }

    public void setServiceID(String serviceID) {
        ServiceID = serviceID;
    }

    public String getForemanID() {
        return ForemanID;
    }

    public void setForemanID(String foremanID) {
        ForemanID = foremanID;
    }

    public String getUserID() {
        return UserID;
    }

    public void setUserID(String userID) {
        UserID = userID;
    }

    public String getVehicleID() {
        return VehicleID;
    }

    public void setVehicleID(String vehicleID) {
        VehicleID = vehicleID;
    }

    public String getProblemDescriptionMessage() {
        return ProblemDescriptionMessage;
    }

    public void setProblemDescriptionMessage(String problemDescriptionMessage) {
        ProblemDescriptionMessage = problemDescriptionMessage;
    }

    public String getSPReqMoney() {
        return SPReqMoney;
    }

    public void setSPReqMoney(String SPReqMoney) {
        this.SPReqMoney = SPReqMoney;
    }

    public String getPaymentMode() {
        return PaymentMode;
    }

    public void setPaymentMode(String paymentMode) {
        PaymentMode = paymentMode;
    }

    public String getPayment() {
        return Payment;
    }

    public void setPayment(String payment) {
        Payment = payment;
    }

    public String getPaymentStatus() {
        return PaymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        PaymentStatus = paymentStatus;
    }

    public String getTypeOfProblem() {
        return TypeOfProblem;
    }

    public void setTypeOfProblem(String typeOfProblem) {
        TypeOfProblem = typeOfProblem;
    }

    public String getProblemSubType() {
        return ProblemSubType;
    }

    public void setProblemSubType(String problemSubType) {
        ProblemSubType = problemSubType;
    }

    public String getServiceFixedCharge() {
        return ServiceFixedCharge;
    }

    public void setServiceFixedCharge(String serviceFixedCharge) {
        ServiceFixedCharge = serviceFixedCharge;
    }

    public String getUserFirstName() {
        return UserFirstName;
    }

    public void setUserFirstName(String userFirstName) {
        UserFirstName = userFirstName;
    }

    public String getUserLastName() {
        return UserLastName;
    }

    public void setUserLastName(String userLastName) {
        UserLastName = userLastName;
    }

    public String getUserProfileImage() {
        return UserProfileImage;
    }

    public void setUserProfileImage(String userProfileImage) {
        UserProfileImage = userProfileImage;
    }

    public String getUserMobileNumber() {
        return UserMobileNumber;
    }

    public void setUserMobileNumber(String userMobileNumber) {
        UserMobileNumber = userMobileNumber;
    }

    public String getNumberPlate_number() {
        return NumberPlate_number;
    }

    public void setNumberPlate_number(String numberPlate_number) {
        NumberPlate_number = numberPlate_number;
    }

    public String getTypeOfVehicle() {
        return TypeOfVehicle;
    }

    public void setTypeOfVehicle(String typeOfVehicle) {
        TypeOfVehicle = typeOfVehicle;
    }

    public String getVehicleModelName() {
        return VehicleModelName;
    }

    public void setVehicleModelName(String vehicleModelName) {
        VehicleModelName = vehicleModelName;
    }

    public String getVehicle_Colour() {
        return Vehicle_Colour;
    }

    public void setVehicle_Colour(String vehicle_Colour) {
        Vehicle_Colour = vehicle_Colour;
    }

    public String getForemanLocationID() {
        return ForemanLocationID;
    }

    public void setForemanLocationID(String foremanLocationID) {
        ForemanLocationID = foremanLocationID;
    }

    public String getForemanLatitude() {
        return ForemanLatitude;
    }

    public void setForemanLatitude(String foremanLatitude) {
        ForemanLatitude = foremanLatitude;
    }

    public String getForemanLongitude() {
        return ForemanLongitude;
    }

    public void setForemanLongitude(String foremanLongitude) {
        ForemanLongitude = foremanLongitude;
    }

    public String getUserLocationID() {
        return UserLocationID;
    }

    public void setUserLocationID(String userLocationID) {
        UserLocationID = userLocationID;
    }

    public String getUserLatitude() {
        return UserLatitude;
    }

    public void setUserLatitude(String userLatitude) {
        UserLatitude = userLatitude;
    }

    public String getUserLongitude() {
        return UserLongitude;
    }

    public void setUserLongitude(String userLongitude) {
        UserLongitude = userLongitude;
    }
}
