package com.brainybeam.roadsideassistance.Foreman.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.brainybeam.roadsideassistance.Login.LoginActivity;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.DeleteUserORForemanData;
import com.brainybeam.roadsideassistance.User.Activity.UserForgotPasswordActivity;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ForemanForgotPasswordActivity extends AppCompatActivity {

    EditText Password, ReEnterPassword;
    Button login;

    String sPassword, sPassword2;

    ApiInterface apiInterface;
    SharedPreferences sp;
    ProgressDialog pd;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_foreman_forgot_password);

        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        sp = getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);

        Password = findViewById(R.id.foreman_forgot_password_PasswordEditText);
        ReEnterPassword = findViewById(R.id.foreman_forgot_password_ReEnterPasswordEditText);
        login = findViewById(R.id.foreman_forgot_password_LoginButton);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sPassword = Password.getText().toString();
                sPassword2 = ReEnterPassword.getText().toString();

                if(sPassword.isEmpty() || sPassword.equalsIgnoreCase("")){
                    Password.setError("Password is Required");
                } else if(sPassword2.isEmpty() || sPassword2.equalsIgnoreCase("")){
                    ReEnterPassword.setError("Password is Required");
                } else if(sPassword.length()<8){
                    Password.setError("Password Must be 8 char long");
                } else if(!sPassword.equals(sPassword2)){
                    ReEnterPassword.setError("Password is Not Match");
                } else {

                    pd = new ProgressDialog(ForemanForgotPasswordActivity.this);
                    pd.setTitle("Password Resetting...");
                    pd.setCancelable(false);
                    pd.show();
                    PasswordUpdateData();

                }
            }
        });
    }

    private void PasswordUpdateData() {

        Call<DeleteUserORForemanData> call = apiInterface.ForemanForgotPassword(
                sp.getString(SharedPreferencesData.UserID, ""),
                sPassword
        );

        call.enqueue(new Callback<DeleteUserORForemanData>() {
            @Override
            public void onResponse(Call<DeleteUserORForemanData> call, Response<DeleteUserORForemanData> response) {

                pd.dismiss();
                if(response.code()==200){

                    if(response.body().status==true){
                        sp.edit().putString(SharedPreferencesData.Password, sPassword).commit();
                        new CommonMethod(ForemanForgotPasswordActivity.this, LoginActivity.class);
                        finish();
                    } else {
                        new CommonMethod(ForemanForgotPasswordActivity.this, response.body().message);
                    }

                } else {
                    new CommonMethod(ForemanForgotPasswordActivity.this, "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<DeleteUserORForemanData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(ForemanForgotPasswordActivity.this, t.getMessage());
            }
        });

    }
    
}