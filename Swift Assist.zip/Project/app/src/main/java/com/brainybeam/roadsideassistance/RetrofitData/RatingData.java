package com.brainybeam.roadsideassistance.RetrofitData;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class RatingData {

    @SerializedName("Status")
    @Expose
    public Boolean status;
    @SerializedName("Message")
    @Expose
    public String message;
    @SerializedName("response")
    @Expose
    public List<RatingResponse> response = null;

    public class RatingResponse {

        @SerializedName("RatingID")
        @Expose
        public String ratingID;
        @SerializedName("ForemanID")
        @Expose
        public String foremanID;
        @SerializedName("Rating")
        @Expose
        public String rating;

    }

}
