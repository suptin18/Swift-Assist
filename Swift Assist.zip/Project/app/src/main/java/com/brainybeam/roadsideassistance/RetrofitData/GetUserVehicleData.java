package com.brainybeam.roadsideassistance.RetrofitData;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class GetUserVehicleData {

    @SerializedName("Status")
    @Expose
    public Boolean status;
    @SerializedName("Message")
    @Expose
    public String message;
    @SerializedName("response")
    @Expose
    public List<GetUserVehicleResponse> response = null;


    public class GetUserVehicleResponse {

        @SerializedName("VehicleID")
        @Expose
        public String vehicleID;
        @SerializedName("UserID")
        @Expose
        public String userID;
        @SerializedName("NumberPlate_number")
        @Expose
        public String numberPlateNumber;
        @SerializedName("TypeOfVehicle")
        @Expose
        public String typeOfVehicle;
        @SerializedName("VehicleModelName")
        @Expose
        public String vehicleModelName;
        @SerializedName("Vehicle_Colour")
        @Expose
        public String vehicleColour;
        @SerializedName("Created_time")
        @Expose
        public String createdTime;

    }
}
