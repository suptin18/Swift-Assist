package com.brainybeam.roadsideassistance.User.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.User.DashBoard.UserAddVehicleDetailFragment;
import com.brainybeam.roadsideassistance.User.DashBoard.UserDashboardActivity;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConnectionDetector;
import com.brainybeam.roadsideassistance.Utils.ConstantData;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class AddVehicleActivity extends AppCompatActivity {

    EditText NumberPlateNumber, ModelName, VehicleColor;
    Spinner Spinner_TypeOfVehicle;

    ArrayList<String> arrayList_typeofVehicle;
    Button AddButton, BackButton;

    String sNumberPlateNumber, sTypeOfVehicle, sModelName, sVehicleColor;

    FirebaseAuth mAuth;
    FirebaseApp firebaseApp;
    FirebaseFirestore fStore;

    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_vehicle);

        Objects.requireNonNull(getSupportActionBar()).setTitle("Add Vehicle");
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#2196F3"));
        getSupportActionBar().setBackgroundDrawable(colorDrawable);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        sp = AddVehicleActivity.this.getSharedPreferences(SharedPreferencesData.PREF, Context.MODE_PRIVATE);
        firebaseApp = FirebaseApp.initializeApp(getApplicationContext());
        mAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();


        NumberPlateNumber = findViewById(R.id.user_Addvehicle_NumberPlateEditText);
        Spinner_TypeOfVehicle = findViewById(R.id.user_Addvehicle_Spinner_TypeOfVehicle);
        ModelName = findViewById(R.id.user_Addvehicle_ModelNameEditText);
        VehicleColor = findViewById(R.id.user_Addvehicle_VehicleColorEditText);
        AddButton = findViewById(R.id.user_Addvehicle_AddButton);
        BackButton = findViewById(R.id.user_Addvehicle_backButton);

        sTypeOfVehicle = "";
        arrayList_typeofVehicle = new ArrayList<>();
        arrayList_typeofVehicle.add("Select Type Of Vehicle");
        String[] S_array = ConstantData.TypeOfVehicle;
        List<String> list;
        list = Arrays.asList(S_array);
        arrayList_typeofVehicle.addAll(list);

        Spinner_TypeOfVehicle.setSelection(arrayList_typeofVehicle.indexOf("Select Type Of Vehicle"));
        ArrayAdapter adapter = new ArrayAdapter(AddVehicleActivity.this, android.R.layout.simple_list_item_1, arrayList_typeofVehicle);
        adapter.setDropDownViewResource(android.R.layout.simple_list_item_activated_1);
        Spinner_TypeOfVehicle.setAdapter(adapter);

        Spinner_TypeOfVehicle.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                sTypeOfVehicle = arrayList_typeofVehicle.get(i);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        AddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sNumberPlateNumber = NumberPlateNumber.getText().toString();
                sModelName = ModelName.getText().toString();
                sVehicleColor = VehicleColor.getText().toString();

                if (sNumberPlateNumber.isEmpty()) {
                    NumberPlateNumber.setError("Vehicle Number is Necessary");
                } else if (sTypeOfVehicle.isEmpty() || sTypeOfVehicle.equalsIgnoreCase("Select Type Of Vehicle")) {
                    new CommonMethod(AddVehicleActivity.this, "Please Select Valid Type Of Vehicle");
                } else if (sModelName.isEmpty()) {
                    ModelName.setError("Model Name is Required");
                } else if (sVehicleColor.isEmpty()) {
                    VehicleColor.setError("Vehicle Color is Required");
                } else {

                    if (new ConnectionDetector(AddVehicleActivity.this).isConnectingToInternet()) {

                        StoreVehicleData();

                    } else {
                        new ConnectionDetector(AddVehicleActivity.this).connectiondetect();
                    }
                }
            }
        });

        BackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

    }

    private void StoreVehicleData() {
        String userID = Objects.requireNonNull(mAuth.getCurrentUser()).getUid();
        String vehicleID = userID + sNumberPlateNumber;
        DocumentReference documentReference = fStore.collection("Vehicles").document(vehicleID);
        Map<String, Object> vehicle = new HashMap<>();
        vehicle.put("vehicleID", vehicleID);
        vehicle.put("userID", userID);
        vehicle.put("numberPlateNumber", sNumberPlateNumber);
        vehicle.put("typeOfVehicle", sTypeOfVehicle);
        vehicle.put("vehicleModelName", sModelName);
        vehicle.put("vehicleColour", sVehicleColor);
        documentReference.set(vehicle).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                Toast.makeText(AddVehicleActivity.this, "Vehicle Add Successfully", Toast.LENGTH_SHORT).show();
                Log.d("TAG", "Vehicle Add Successfully for " + userID);
            }

        });
        //onBackPressed();
        new CommonMethod(AddVehicleActivity.this, UserDashboardActivity.class);

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

}