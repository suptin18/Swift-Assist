package com.brainybeam.roadsideassistance.Admin.DashBoard;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.brainybeam.roadsideassistance.Admin.CustomArrayList.NewForemanRequestList;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.AdminGetNewForemanRequestData;
import com.brainybeam.roadsideassistance.User.CustomArrayList.UserVehicleList;
import com.brainybeam.roadsideassistance.User.DashBoard.UserVehicleDetailAdapter;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConnectionDetector;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class AdminNewForemanRequestFragment extends Fragment {

    RecyclerView recyclerView;

    ArrayList<NewForemanRequestList> arrayList;


    SharedPreferences sp;

    FirebaseAuth mAuth;
    FirebaseApp firebaseApp;
    FirebaseFirestore fStore;

    public AdminNewForemanRequestFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_admin_new_foreman_request, container, false);


        sp = getActivity().getSharedPreferences(SharedPreferencesData.PREF, Context.MODE_PRIVATE);
        mAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();

        recyclerView = view.findViewById(R.id.frag_admin_new_foreman_request_recyclerView);

        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        if(new ConnectionDetector(getActivity()).isConnectingToInternet()){

            recyclerViewDataSetMethod();

        } else {
            new ConnectionDetector(getActivity()).connectiondetect();
        }

        return view;
    }

    private void recyclerViewDataSetMethod() {

        arrayList = new ArrayList<>();
        String userID = Objects.requireNonNull(mAuth.getCurrentUser()).getUid();
        Task<QuerySnapshot> documentReference = fStore.collection("Users").whereEqualTo("ForemanAccount_Status", false).get();
        documentReference.addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful() && task.getResult() != null) {
                    for (DocumentSnapshot document : task.getResult()) {
                        NewForemanRequestList list = new NewForemanRequestList();

                        list.setForemanID(document.getString("ForemanID"));
                        list.setUserType(document.getString("UserType"));
                        list.setFirstName(document.getString("FirstName"));
                        list.setLastName(document.getString("LastName"));
                        list.setProfileImage(document.getString("Image"));
                        list.setMobileNumber(document.getString("MobileNumber"));
                        list.setEmail(document.getString("Email"));
                        list.setAddress(document.getString("ForemanAddress"));
                        list.setArea(document.getString("ForemanArea"));
                        list.setCity(document.getString("ForemanCity"));
                        list.setState(document.getString("ForemanState"));
                        list.setAccount_Status(document.getString("Account_Status"));
                        list.setCreated_time(document.getString("CreatedTime"));

                        arrayList.add(list);
                    }
                    AdminNewForemanRequestAdapter adapter = new AdminNewForemanRequestAdapter(getActivity(), arrayList);
                    recyclerView.setAdapter(adapter);
                    adapter.notifyDataSetChanged();
                }
            }
        });
    }

}