package com.brainybeam.roadsideassistance.Foreman.Activity;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.brainybeam.roadsideassistance.GPS.GPSTracker;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.GetForemanLocationData;
import com.brainybeam.roadsideassistance.RetrofitData.GetUserLocationData;
import com.brainybeam.roadsideassistance.RetrofitData.LocationData;
import com.brainybeam.roadsideassistance.User.Activity.UserForemanServicesActivity;
import com.brainybeam.roadsideassistance.User.Activity.UserTrackingActivity;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ForemanTrackingActivity extends AppCompatActivity implements OnMapReadyCallback,
        LocationListener, GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener, SensorEventListener {

    ImageView BackTabLogo, CallingTabLogo;
    Button nextButton, LocationUpdateButton;
    TextView UserAddressView;

    private GoogleMap mMap;
    private static final int MY_PERMISSIONS_REQUEST_FINE_LOCATION = 111;
    private LocationListener locationListener;
    private LocationManager locationManager;
    // record the compass picture angle turned
    private float currentDegree = 0f;

    // device sensor manager
    private SensorManager mSensorManager;

    Location mLastLocation;
    Marker mCurrLocationMarker;
    GoogleApiClient mGoogleApiClient;
    LocationRequest mLocationRequest;

    private final long MIN_TIME = 1000; // 1 second
    private final long MIN_DIST = 5; // 5 Meters
    private LatLng latLng;


    GPSTracker gpsTracker;
    double latitude, longitude;


    SharedPreferences sp;
    ProgressDialog pd;

    String sForemanAddress, sForemanLatitude, sForemanLongitude;
    String sUserAddress, sUserLatitude, sUserLongitude;

    double userLatitude, userLongitude;

    double CurrentLatitude, CurrentLongitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_foreman_tracking);

        sp = getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);

        nextButton = findViewById(R.id.foreman_tracking_NextButton);
        BackTabLogo = findViewById(R.id.foreman_tracking_back_image_Logo);
        CallingTabLogo = findViewById(R.id.foreman_tracking_call_image_Logo);
        LocationUpdateButton = findViewById(R.id.foreman_tracking_updateLocationButton);
        UserAddressView = findViewById(R.id.foreman_tracking_UserAddress);

        //  nextButton.setVisibility(View.GONE);
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CommonMethod(ForemanTrackingActivity.this, ForemanUserPaymentActivity.class);
            }
        });


        BackTabLogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        CallingTabLogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder builder = new AlertDialog.Builder(ForemanTrackingActivity.this);
                builder.setTitle("Call to User?" + " " + sp.getString(SharedPreferencesData.Foreman_UserFirstName, ""));
                builder.setPositiveButton("CALL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent = new Intent(Intent.ACTION_CALL);
                        intent.setData(Uri.parse("tel:+880" + sp.getString(SharedPreferencesData.Foreman_UserMobileNumber, "")));
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                                // TODO: Consider calling
                                //    Activity#requestPermissions
                                // here to request the missing permissions, and then overriding
                                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                //                                          int[] grantResults)
                                // to handle the case where the user grants the permission. See the documentation
                                // for Activity#requestPermissions for more details.
                                return;
                            }
                        }
                        startActivity(intent);
                    }
                });
                builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                });
                builder.show();

            }
        });


        if (ContextCompat.checkSelfPermission(ForemanTrackingActivity.this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this, // Activity
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    MY_PERMISSIONS_REQUEST_FINE_LOCATION);
        }

        gpsTracker = new GPSTracker(ForemanTrackingActivity.this);


        // TODO Get User Location Data
        GetUserLocationData();
        GetForemanLocationData();

        gpsTracker = new GPSTracker(ForemanTrackingActivity.this);

        SupportMapFragment mapFragment;

        if (gpsTracker.canGetLocation()) {
            mapFragment = (SupportMapFragment) getSupportFragmentManager()
                    .findFragmentById(R.id.foreman_tracking_mapFragment);
            mapFragment.getMapAsync(this);
            // mMap.setTrafficEnabled(true);
        } else {
            gpsTracker.showSettingsAlert();
        }

        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, PackageManager.PERMISSION_GRANTED);
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, PackageManager.PERMISSION_GRANTED);

        //fetch_GPS();
        mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);


        // Check if GPS enabled
        if (gpsTracker.canGetLocation()) {

            CurrentLatitude = gpsTracker.getLatitude();
            CurrentLongitude = gpsTracker.getLongitude();

            //   getLocation();

        } else {
            // Can't get location.
            // GPS or network is not enabled.
            // Ask user to enable GPS/network in settings.
            gpsTracker.showSettingsAlert();
        }


        // TODO Distance

        // TODO User Location
        Location startPoint = new Location("locationA");
        startPoint.setLatitude(CurrentLatitude);
        startPoint.setLongitude(CurrentLongitude);

        // TODO Foreman Location
        Location endPoint = new Location("locationA");
        endPoint.setLatitude(userLatitude);
        endPoint.setLongitude(userLongitude);
        DecimalFormat precision = new DecimalFormat("0.00");
        double distance = Double.parseDouble(precision.format(startPoint.distanceTo(endPoint) / 1000));


        if (distance < 500) {
            nextButton.setVisibility(View.VISIBLE);
            LocationUpdateButton.setVisibility(View.GONE);
        }

        LocationUpdateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GetUserLocationData();
                StoreUpdatedForemanLocationData();
                new CommonMethod(ForemanTrackingActivity.this, ForemanTrackingActivity.class);
                finish();
            }
        });


    }

    private void GetForemanLocationData() {

//        sp.getString(SharedPreferencesData.UserID, ""),
//                sp.getString(SharedPreferencesData.Foreman_UserID, "")
//
//        sp.edit().putString(SharedPreferencesData.Foreman_ForemanLocationID, data.response.get(i).foremanLocationID).commit();
//        sp.edit().putString(SharedPreferencesData.Foreman_ForemanCurrLatitude, data.response.get(i).foremanLatitude).commit();
//        sp.edit().putString(SharedPreferencesData.Foreman_ForemanCurrLongitude, data.response.get(i).foremanLongitude).commit();
//

    }

    private void GetUserLocationData() {

//
//        sp.getString(SharedPreferencesData.Foreman_UserID, ""),
//                sp.getString(SharedPreferencesData.UserID, "")
//
//        userLatitude = Double.valueOf(data.response.get(i).userLatitude);
//        userLongitude = Double.valueOf(data.response.get(i).userLongitude);
//
//        Geocoder geocoder = new Geocoder(ForemanTrackingActivity.this, Locale.getDefault());
//        List<Address> addresses = null;
//        try {
//            addresses = geocoder.getFromLocation(Double.valueOf(data.response.get(i).userLatitude), Double.valueOf(data.response.get(i).userLongitude), 1);
//            String addF = addresses.get(0).getAddressLine(0);
//            String city = addresses.get(0).getLocality();
//            String state = addresses.get(0).getAdminArea();
//            String zip = addresses.get(0).getPostalCode();
//            String country = addresses.get(0).getCountryName();
//
//            //  UserAddressView.setText(add);
//
//            UserAddressView.setText(addF);
//            // StoreUpdatedForemanLocationData();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//
//        sp.edit().putString(SharedPreferencesData.Foreman_UserLocationID, data.response.get(i).userLocationID).commit();
//        sp.edit().putString(SharedPreferencesData.Foreman_UserCurrLatitude, data.response.get(i).userLatitude).commit();
//        sp.edit().putString(SharedPreferencesData.Foreman_UserCurrLongitude, data.response.get(i).userLongitude).commit();
//

    }

    @Override
    protected void onResume() {
        super.onResume();

        // for the system's orientation sensor registered listeners
        mSensorManager.registerListener(ForemanTrackingActivity.this, mSensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION),
                SensorManager.SENSOR_DELAY_GAME);
    }

    @Override
    protected void onPause() {
        super.onPause();

        // to stop the listener and save battery
        mSensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {

        // get the angle around the z-axis rotated
        float degree = Math.round(event.values[0]);


        // create a rotation animation (reverse turn degree degrees)
        RotateAnimation ra = new RotateAnimation(
                currentDegree,
                -degree,
                Animation.RELATIVE_TO_SELF, 0.5f,
                Animation.RELATIVE_TO_SELF,
                0.5f);

        // how long the animation will take place
        ra.setDuration(210);

        // set the animation after the end of the reservation status
        ra.setFillAfter(true);

        // Start the animation
        currentDegree = -degree;

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // not in use
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED) {
                buildGoogleApiClient();
                mMap.setMyLocationEnabled(true);
            }
        } else {
            buildGoogleApiClient();
            //mMap.setMyLocationEnabled(true);
        }

//        // Add a marker in Sydney and move the camera
//
//        gpsTracker = new GPSTracker(ForemanTrackingActivity.this);
//
//        latitude = gpsTracker.getLatitude();
//        longitude = gpsTracker.getLongitude();
//
//        LatLng sydney = new LatLng(latitude, longitude);
//        mMap.addMarker(new MarkerOptions().position(sydney).title("Sydney"));
//        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
//        locationListener = new LocationListener() {
//            @Override
//            public void onLocationChanged(Location location) {
//
//                try {
//                    latLng = new LatLng(23.0225, 72.5714);
//                    mMap.addMarker(new MarkerOptions().position(latLng).title("My Position"));
//
//                    mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
//                }
//                catch (SecurityException e){
//                    e.printStackTrace();
//                }
//
//            }
//
//        };
//
//        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
//
//        try {
//            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, MIN_TIME, MIN_DIST, locationListener);
//        }
//        catch (SecurityException e){
//            e.printStackTrace();
//        }
    }

    protected synchronized void buildGoogleApiClient() {
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API).build();
        mGoogleApiClient.connect();
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
        super.onPointerCaptureChanged(hasCapture);
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {

        mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(1000);
        mLocationRequest.setFastestInterval(1000);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY);
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, ForemanTrackingActivity.this);
        }


    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    public void onLocationChanged(@NonNull Location location) {

        mLastLocation = location;
        if (mCurrLocationMarker != null) {
            mCurrLocationMarker.remove();
        }

        //Place current location marker
        final LatLng[] latLng = {new LatLng(location.getLatitude(), location.getLongitude())};
        final MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.position(latLng[0]);
        markerOptions.title("Your Current Position");
        markerOptions.draggable(true);

        markerOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.icforeman));

        mCurrLocationMarker = mMap.addMarker(markerOptions);
        mMap.setMapType(mMap.MAP_TYPE_SATELLITE);

        Geocoder geocoder = new Geocoder(ForemanTrackingActivity.this, Locale.getDefault());
        List<Address> addresses = null;
        try {
            addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
            String add = addresses.get(0).getAddressLine(0);
            String city = addresses.get(0).getLocality();
            String state = addresses.get(0).getAdminArea();
            String zip = addresses.get(0).getPostalCode();
            String country = addresses.get(0).getCountryName();

            //  UserAddressView.setText(add);

            sForemanLatitude = String.valueOf(location.getLatitude());
            sForemanLongitude = String.valueOf(location.getLongitude());
            sForemanAddress = add;
            // StoreUpdatedForemanLocationData();
        } catch (IOException e) {
            e.printStackTrace();
        }

        //move map camera
        mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng[0]));
        mMap.animateCamera(CameraUpdateFactory.zoomTo(15));
        //mMap.setTrafficEnabled(true);

        //stop location updates
        if (mGoogleApiClient != null) {
            LocationServices.FusedLocationApi.removeLocationUpdates(mGoogleApiClient, this);
        }

        mMap.setOnMyLocationChangeListener(new GoogleMap.OnMyLocationChangeListener() {
            @Override
            public void onMyLocationChange(Location location) {
                if (location == null)
                    return;

                mCurrLocationMarker = mMap.addMarker(new MarkerOptions()
                        .flat(true)
                        .title("Incident Location")
                        .icon(BitmapDescriptorFactory
                                .fromResource(R.drawable.iccar))
                        .anchor(0.5f, 1f)
                        .position(new LatLng(userLatitude, userLongitude)));

            }
        });

    }

    private void StoreUpdatedForemanLocationData() {

//
//                sp.getString(SharedPreferencesData.Foreman_ForemanLocationID, ""),
//                sForemanLatitude,
//                sForemanLongitude
//
//
//        new CommonMethod(ForemanTrackingActivity.this, "Update Foreman");

    }


}