package com.brainybeam.roadsideassistance.RetrofitData;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ForemanLoginData {

    @SerializedName("Status")
    @Expose
    public String status;
    @SerializedName("Message")
    @Expose
    public String message;
    @SerializedName("response")
    @Expose
    public List<ForemanLoginResponse> response = null;

    public class ForemanLoginResponse {

        @SerializedName("ForemanID")
        @Expose
        public String foremanID;
        @SerializedName("UserType")
        @Expose
        public String userType;
        @SerializedName("FirstName")
        @Expose
        public String firstName;
        @SerializedName("LastName")
        @Expose
        public String lastName;
        @SerializedName("ProfileImage")
        @Expose
        public String profileImage;
        @SerializedName("MobileNumber")
        @Expose
        public String mobileNumber;
        @SerializedName("Email")
        @Expose
        public String email;
        @SerializedName("Password")
        @Expose
        public String password;
        @SerializedName("Address")
        @Expose
        public String address;
        @SerializedName("Area")
        @Expose
        public String area;
        @SerializedName("City")
        @Expose
        public String city;
        @SerializedName("State")
        @Expose
        public String state;
        @SerializedName("Account_Status")
        @Expose
        public String accountStatus;
        @SerializedName("FCMID")
        @Expose
        public String fcmid;
        @SerializedName("Created_time")
        @Expose
        public String createdTime;

    }


}
