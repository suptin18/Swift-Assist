package com.brainybeam.roadsideassistance.Foreman.DashBoard;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.brainybeam.roadsideassistance.Foreman.Activity.ForemanHomePendingPaymentActivity;
import com.brainybeam.roadsideassistance.Foreman.Activity.ForemanHomePendingPaymentAdapter;
import com.brainybeam.roadsideassistance.Foreman.CustomArrayList.PendingPaymentList;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.CartPendingPaymentData;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConnectionDetector;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class ForemanUsersLocationTrackingFragment extends Fragment {

    RecyclerView recyclerView;

    CardView cardView;

    ArrayList<PendingPaymentList> arrayList;

    ApiInterface apiInterface;
    SharedPreferences sp;
    ProgressDialog pd;

    public ForemanUsersLocationTrackingFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_foreman_users_location_tracking, container, false);

        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        sp = getActivity().getSharedPreferences(SharedPreferencesData.PREF, Context.MODE_PRIVATE);

        recyclerView = view.findViewById(R.id.frag_foreman_user_location_tracking_RecyclerView);
        cardView = view.findViewById(R.id.frag_foreman_user_location_tracking_CardViewNotHaveAnyPendingActivity);

        cardView.setVisibility(View.GONE);

        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        if(new ConnectionDetector(getActivity()).isConnectingToInternet()){

            pd = new ProgressDialog(getActivity());
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();

            recyclerViewDataSetMethod();

        } else {
            new ConnectionDetector(getActivity()).connectiondetect();
        }

        return view;
    }

    private void recyclerViewDataSetMethod() {

        Call<CartPendingPaymentData> call = apiInterface.GetCartPendingPaymentData(
                sp.getString(SharedPreferencesData.UserID, "")
        );

        call.enqueue(new Callback<CartPendingPaymentData>() {
            @Override
            public void onResponse(Call<CartPendingPaymentData> call, Response<CartPendingPaymentData> response) {

                pd.dismiss();
                if(response.code()==200){

                    if(response.body().status==true){

                        arrayList = new ArrayList<>();
                        CartPendingPaymentData data = response.body();
                        for(int i=0; i<data.response.size(); i++){

                            PendingPaymentList list = new PendingPaymentList();

                            list.setCartID(data.response.get(i).cartID);
                            list.setServiceID(data.response.get(i).serviceID);
                            list.setForemanID(data.response.get(i).foremanID);
                            list.setUserID(data.response.get(i).userID);
                            list.setVehicleID(data.response.get(i).vehicleID);
                            list.setProblemDescriptionMessage(data.response.get(i).problemDescriptionMessage);
                            list.setSPReqMoney(data.response.get(i).sPReqMoney);
                            list.setPaymentMode(data.response.get(i).paymentMode);
                            list.setPayment(data.response.get(i).payment);
                            list.setPaymentStatus(data.response.get(i).paymentStatus);
                            list.setTypeOfProblem(data.response.get(i).typeOfProblem);
                            list.setProblemSubType(data.response.get(i).problemSubType);
                            list.setServiceFixedCharge(data.response.get(i).serviceFixedCharge);
                            list.setUserFirstName(data.response.get(i).firstName);
                            list.setUserLastName(data.response.get(i).lastName);
                            list.setUserProfileImage(data.response.get(i).profileImage);
                            list.setUserMobileNumber(data.response.get(i).mobileNumber);
                            list.setNumberPlate_number(data.response.get(i).numberPlateNumber);
                            list.setTypeOfVehicle(data.response.get(i).typeOfVehicle);
                            list.setVehicleModelName(data.response.get(i).vehicleModelName);
                            list.setVehicle_Colour(data.response.get(i).vehicleColour);
                            list.setForemanLocationID(data.response.get(i).foremanLocationID);
                            list.setForemanLatitude(data.response.get(i).foremanLatitude);
                            list.setForemanLongitude(data.response.get(i).foremanLongitude);
                            list.setUserLocationID(data.response.get(i).userLocationID);
                            list.setUserLatitude(data.response.get(i).userLatitude);
                            list.setUserLongitude(data.response.get(i).userLongitude);

                            arrayList.add(list);
                        }

                        ForemanLocationTrackingAdapter adapter = new ForemanLocationTrackingAdapter(getActivity(), arrayList);
                        recyclerView.setAdapter(adapter);
                        adapter.notifyDataSetChanged();

                    } else {
                        new CommonMethod(getActivity(), response.body().message);
                        recyclerView.setVisibility(View.GONE);
                        cardView.setVisibility(View.VISIBLE);
                    }

                } else {
                    new CommonMethod(getActivity(), "Server Error Code "+response.code());
                }

            }

            @Override
            public void onFailure(Call<CartPendingPaymentData> call, Throwable t) {
                new CommonMethod(getActivity(), t.getMessage());
            }
        });

    }
    
}