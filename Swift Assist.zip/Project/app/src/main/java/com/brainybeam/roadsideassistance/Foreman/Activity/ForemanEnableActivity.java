package com.brainybeam.roadsideassistance.Foreman.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.brainybeam.roadsideassistance.Login.LoginActivity;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.DeleteUserORForemanData;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ForemanEnableActivity extends AppCompatActivity {
    
    Button ActivateButton, LogoutButton;

    ApiInterface apiInterface;
    SharedPreferences sp;
    ProgressDialog pd;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_foreman_enable);

        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        sp = getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);

        ActivateButton = findViewById(R.id.foreman_enable_activateButton);
        LogoutButton = findViewById(R.id.foreman_enable_LogoutButton);

        ActivateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pd = new ProgressDialog(ForemanEnableActivity.this);
                pd.setTitle("Processing...");
                pd.setCancelable(false);
                pd.show();
                Activate();
            }
        });

        LogoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sp.edit().clear().commit();
                startActivity(new Intent(ForemanEnableActivity.this, LoginActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
            }
        });
        
    }

    private void Activate() {

        Call<DeleteUserORForemanData> call = apiInterface.ActiveForemanAccountData(
                sp.getString(SharedPreferencesData.UserID, "")
        );
        
        call.enqueue(new Callback<DeleteUserORForemanData>() {
            @Override
            public void onResponse(Call<DeleteUserORForemanData> call, Response<DeleteUserORForemanData> response) {

                pd.dismiss();
                if(response.code()==200){

                    if(response.body().status==true){
                        new CommonMethod(ForemanEnableActivity.this, "Your Account Request has been to Admin");
                        new CommonMethod(ForemanEnableActivity.this, "Please Wait Some time..");
                        new CommonMethod(ForemanEnableActivity.this, LoginActivity.class);
                        finish();
                    } else {
                        new CommonMethod(ForemanEnableActivity.this, "UnSuccessFull");
                        new CommonMethod(ForemanEnableActivity.this, "Please Try Again");
                    }

                } else {
                    new CommonMethod(ForemanEnableActivity.this, "Server Error Code : "+response.code());
                }
                
            }

            @Override
            public void onFailure(Call<DeleteUserORForemanData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(ForemanEnableActivity.this, t.getMessage());
            }
        });
        
    }
    
}