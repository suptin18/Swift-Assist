package com.brainybeam.roadsideassistance.User.DashBoard;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.RecyclerView;

import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.User.CustomArrayList.UserVehicleList;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConnectionDetector;
import com.brainybeam.roadsideassistance.Utils.ConstantData;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserVehicleDetailAdapter extends RecyclerView.Adapter<UserVehicleDetailAdapter.MyHolder> {

    Context context;
    ArrayList<UserVehicleList> arrayList;

    String sVehicleID, sNumberPlateNumber, sTypeOfVehicle, sModelName, sVehicleColor;

    SharedPreferences sp;
    FirebaseAuth mAuth;
    FirebaseFirestore fStore;

    int iPosition;

    public UserVehicleDetailAdapter(Context context, ArrayList<UserVehicleList> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_user_vehicle, parent, false);

        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, @SuppressLint("RecyclerView") int position) {

        sVehicleID = arrayList.get(position).getVehicleID();
        holder.UserID.setText(arrayList.get(position).getUserID());
        holder.NumberPlateNumber.setText(arrayList.get(position).getNumberPlate_number());
        holder.TypeofVehicle.setText(arrayList.get(position).getTypeOfVehicle());
        holder.ModelName.setText(arrayList.get(position).getVehicleModelName());
        holder.VehicleColor.setText(arrayList.get(position).getVehicle_Colour());

        holder.NumberPlateNumber_EditText.setText(arrayList.get(position).getNumberPlate_number());
        holder.Spinner_TypeOfVehicle.setSelection(position);
        holder.ModelName_EditText.setText(arrayList.get(position).getVehicleModelName());
        holder.VehicleColor_EditText.setText(arrayList.get(position).getVehicle_Colour());

        ArrayAdapter adapter = new ArrayAdapter(context, android.R.layout.simple_list_item_1, holder.arrayList_typeofVehicle);
        adapter.setDropDownViewResource(android.R.layout.simple_list_item_activated_1);
        holder.Spinner_TypeOfVehicle.setAdapter(adapter);

        holder.Spinner_TypeOfVehicle.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                sTypeOfVehicle = holder.arrayList_typeofVehicle.get(i);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        holder.EditButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                holder.nestedScrollView.setVisibility(View.VISIBLE);
                holder.layout.setVisibility(View.GONE);
            }
        });

        holder.BackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                holder.layout.setVisibility(View.VISIBLE);
                holder.nestedScrollView.setVisibility(View.GONE);
            }
        });

        holder.UpdateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                sNumberPlateNumber = holder.NumberPlateNumber_EditText.getText().toString();
                sModelName = holder.ModelName_EditText.getText().toString();
                sVehicleColor = holder.VehicleColor_EditText.getText().toString();

                if (sNumberPlateNumber.isEmpty()) {
                    holder.NumberPlateNumber_EditText.setError("Vehicle Number is Required");
                } else if (sModelName.isEmpty()) {
                    holder.ModelName_EditText.setError("Model Name is Required");
                } else if (sVehicleColor.isEmpty()) {
                    holder.VehicleColor_EditText.setError("Vehicle Color is Required");
                } else if (sTypeOfVehicle.isEmpty()) {
                    new CommonMethod(context, "Please Select Type Of Vehicle");
                } else {

                    if (new ConnectionDetector(context).isConnectingToInternet()) {

                        iPosition = position;

                        UpdateVehicleData();

                        holder.nestedScrollView.setVisibility(View.GONE);
                        holder.layout.setVisibility(View.VISIBLE);

                        notifyDataSetChanged();

                    } else {
                        new ConnectionDetector(context).connectiondetect();
                    }

                }

            }
        });

        holder.DeleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (new ConnectionDetector(context).isConnectingToInternet()) {

                    iPosition = position;
                    DeleteVehicleData();
                    notifyDataSetChanged();
                } else {
                    new ConnectionDetector(context).connectiondetect();
                }
            }
        });

    }

    private void DeleteVehicleData() {
        // sVehicleID
        fStore.collection("Vehicles").document(sVehicleID).delete();
        arrayList.remove(iPosition);
        notifyDataSetChanged();
    }

    private void UpdateVehicleData() {
        //sVehicleID, sNumberPlateNumber, sTypeOfVehicle, sModelName, sVehicleColor
        Map<String, Object> vehicle = new HashMap<>();
        vehicle.put("numberPlateNumber", sNumberPlateNumber);
        vehicle.put("typeOfVehicle", sTypeOfVehicle);
        vehicle.put("vehicleModelName", sModelName);
        vehicle.put("vehicleColour", sVehicleColor);
        fStore.collection("Vehicles").document(sVehicleID).update(vehicle);
        arrayList.get(iPosition).setNumberPlate_number(sNumberPlateNumber);
        arrayList.get(iPosition).setTypeOfVehicle(sTypeOfVehicle);
        arrayList.get(iPosition).setVehicleModelName(sModelName);
        arrayList.get(iPosition).setVehicle_Colour(sVehicleColor);
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder {

        TextView UserID, NumberPlateNumber, TypeofVehicle, ModelName, VehicleColor;

        LinearLayout layout;
        NestedScrollView nestedScrollView;

        EditText NumberPlateNumber_EditText, ModelName_EditText, VehicleColor_EditText;
        Spinner Spinner_TypeOfVehicle;

        ArrayList<String> arrayList_typeofVehicle;
        Button EditButton, DeleteButton, UpdateButton, BackButton;


        public MyHolder(@NonNull View itemView) {
            super(itemView);

            sp = context.getSharedPreferences(SharedPreferencesData.PREF, Context.MODE_PRIVATE);
            mAuth = FirebaseAuth.getInstance();
            fStore = FirebaseFirestore.getInstance();

            layout = itemView.findViewById(R.id.custom_user_vehicle_MainLinear);
            UserID = itemView.findViewById(R.id.custom_user_vehicle_UserID);
            NumberPlateNumber = itemView.findViewById(R.id.custom_user_vehicle_NumberPlate);
            TypeofVehicle = itemView.findViewById(R.id.custom_user_vehicle_TypeOfVehicle);
            ModelName = itemView.findViewById(R.id.custom_user_vehicle_ModelName);
            VehicleColor = itemView.findViewById(R.id.custom_user_vehicle_VehicleColor);

            nestedScrollView = itemView.findViewById(R.id.custom_user_vehicle_editableLayout);
            NumberPlateNumber_EditText = itemView.findViewById(R.id.custom_user_vehicle_NumberPlateEditText);
            Spinner_TypeOfVehicle = itemView.findViewById(R.id.custom_user_vehicle_Spinner_TypeOfVehicle);
            ModelName_EditText = itemView.findViewById(R.id.custom_user_vehicle_ModelNameEditText);
            VehicleColor_EditText = itemView.findViewById(R.id.custom_user_vehicle_VehicleColorEditText);
            EditButton = itemView.findViewById(R.id.custom_user_vehicle_EditButton);
            UpdateButton = itemView.findViewById(R.id.custom_user_vehicle_UpdateButton);
            DeleteButton = itemView.findViewById(R.id.custom_user_vehicle_DeleteButton);
            BackButton = itemView.findViewById(R.id.custom_user_vehicle_backButton);


            layout.setVisibility(View.VISIBLE);
            nestedScrollView.setVisibility(View.GONE);

            sTypeOfVehicle = "";
            arrayList_typeofVehicle = new ArrayList<>();
            arrayList_typeofVehicle.add("Select Type Of Vehicle");
            String[] S_array = ConstantData.TypeOfVehicle;
            List<String> list;
            list = Arrays.asList(S_array);
            arrayList_typeofVehicle.addAll(list);

        }
    }
}
