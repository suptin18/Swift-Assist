package com.brainybeam.roadsideassistance.User.DashBoard;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.brainybeam.roadsideassistance.Login.LoginActivity;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.User.CustomArrayList.UserVehicleList;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;


public class UserSettingsFragment extends Fragment {


    LinearLayout ProfileDelete_layout, ProfileDeActivate_layout;

    ImageView ProfileDelete_imageview_logo, ProfileDeActivate_imageview_logo;

    TextView ProfileDelete_TextButton, ProfileDeActivate_TextButton;

    SharedPreferences sp;
    FirebaseAuth mAuth;
    FirebaseFirestore fStore;
    StorageReference storageReference;

    public UserSettingsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_user_settings, container, false);

        getActivity();
        sp = requireActivity().getSharedPreferences(SharedPreferencesData.PREF, Context.MODE_PRIVATE);
        mAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();

        ProfileDelete_layout = view.findViewById(R.id.frag_user_setting_profileDelete_layout);
        ProfileDeActivate_layout = view.findViewById(R.id.frag_user_setting_profileDeactivate_layout);

        ProfileDelete_imageview_logo = view.findViewById(R.id.frag_user_setting_profileDelete_imageview_logo);
        ProfileDeActivate_imageview_logo = view.findViewById(R.id.frag_user_setting_profileDeactivate_imageview_logo);

        ProfileDelete_TextButton = view.findViewById(R.id.frag_user_setting_profileDelete_TextButton);
        ProfileDeActivate_TextButton = view.findViewById(R.id.frag_user_setting_profileDeactivate_TextButton);


        // TODO User Profile Delete
        ProfileDelete_TextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DeleteUserProfile();
            }
        });

        ProfileDelete_imageview_logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DeleteUserProfile();
            }
        });

        ProfileDelete_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DeleteUserProfile();
            }
        });


        // TODO User Profile Deactivate
        ProfileDeActivate_TextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DeactivateUserAccount();
            }
        });

        ProfileDeActivate_imageview_logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DeactivateUserAccount();
            }
        });

        ProfileDeActivate_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DeactivateUserAccount();
            }
        });

        return view;
    }

    private void DeactivateUserAccount() {
        Map<String, Object> user = new HashMap<>();
        Boolean value = false;
        user.put("Active_Status", value);
        String userID = Objects.requireNonNull(mAuth.getCurrentUser()).getUid();
        fStore.collection("Users").document(userID).update(user);

        new CommonMethod(getActivity(), "Your Account SuccessFully Deactivate");
        new CommonMethod(getActivity(), LoginActivity.class);

    }

    //  TODO Delete Vehicle
//    private void DeleteVehicle() {
//        String userID = Objects.requireNonNull(mAuth.getCurrentUser()).getUid();
//        Task<QuerySnapshot> documentReference = fStore.collection("Vehicles").whereEqualTo("userID", userID).get();
//        documentReference.addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
//            @Override
//            public void onComplete(@NonNull Task<QuerySnapshot> task) {
//                if (task.isSuccessful() && task.getResult() != null) {
//                    for (DocumentSnapshot document : task.getResult()) {
//                        fStore.collection("Vehicles").document(Objects.requireNonNull(document.getString("vehicleID"))).delete();
//                    }
//                }
//            }
//        });
//        String userID = Objects.requireNonNull(mAuth.getCurrentUser()).getUid();
//        fStore.collection("Users").document(userID).delete();
//        storageReference = FirebaseStorage.getInstance().getReference("images/userprofile/" + userID + ".jpg");
//        storageReference.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
//            @Override
//            public void onSuccess(Void unused) {
//                new CommonMethod(getActivity(), "Image Deleted");
//            }
//        }).addOnFailureListener(new OnFailureListener() {
//            @Override
//            public void onFailure(@NonNull Exception e) {
//                new CommonMethod(getActivity(), "Image Not Deleted");
//            }
//        });
//    }

    private void DeleteUserProfile() {

        final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        String email = sp.getString(SharedPreferencesData.Email, "");
        String password = sp.getString(SharedPreferencesData.Password, "");
        AuthCredential credential = EmailAuthProvider.getCredential(email, password);

        // Prompt the user to re-provide their sign-in credentials
        if (user != null) {
            user.reauthenticate(credential)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            user.delete()
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()) {
                                                new CommonMethod(getActivity(), "Delete SuccessFully");
                                                sp.edit().clear();
                                                new CommonMethod(getActivity(), LoginActivity.class);
                                            }
                                        }
                                    });
                        }
                    });
        }


    }

}