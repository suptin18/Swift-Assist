package com.brainybeam.roadsideassistance.Admin.DashBoard;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.brainybeam.roadsideassistance.Foreman.DashBoard.ForemanDashboardActivity;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.ConnectionDetector;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;


public class AdminHomeFragment extends Fragment {

    TextView AppUser, NumberOfUser, NumberOfForeman;


    SharedPreferences sp;

    int sum;

    public AdminHomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_admin_home, container, false);


        sp = getActivity().getSharedPreferences(SharedPreferencesData.PREF, Context.MODE_PRIVATE);

        AppUser = view.findViewById(R.id.frag_admin_home_activeAppUsers_TextView);
        NumberOfUser = view.findViewById(R.id.frag_admin_home_activeUsers_TextView);
        NumberOfForeman = view.findViewById(R.id.frag_admin_home_activeForeman_TextView);
        sp.edit().putString(SharedPreferencesData.Admin_NumberOfUsers, "1").commit();

        if(sp.getString(SharedPreferencesData.Admin_NumberOfUsers, "").equalsIgnoreCase("") ||
        sp.getString(SharedPreferencesData.Admin_NumberOfForeman, "").equalsIgnoreCase("")){
            sum = 0;
        } else{

            sum = Integer.valueOf(sp.getString(SharedPreferencesData.Admin_NumberOfUsers, "")) +
                    Integer.valueOf(sp.getString(SharedPreferencesData.Admin_NumberOfForeman, ""));
        }



        if(new ConnectionDetector(getActivity()).isConnectingToInternet()){

        } else {

            if(!new ConnectionDetector(getActivity()).isConnectingToInternet()){

            }
            new ConnectionDetector(getActivity()).connectiondetect();

        }
        
        sp.edit().putString(SharedPreferencesData.Admin_NumberOfTotleUsers, String.valueOf(sum)).commit();


        AppUser.setText(sp.getString(SharedPreferencesData.Admin_NumberOfTotleUsers, "")+"+");
        NumberOfUser.setText(sp.getString(SharedPreferencesData.Admin_NumberOfUsers, "")+"+");
        NumberOfForeman.setText(sp.getString(SharedPreferencesData.Admin_NumberOfForeman, "")+"+");

        return view;
    }
}