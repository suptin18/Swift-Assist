package com.brainybeam.roadsideassistance.Utils;

public class ConstantData {

    public static final String ProjectName = "Swift Assist";
    public static final String Call_Assistance_MobileNumber = "+88001796558902";

    public static final String[] State = {
            // Name of the 64 Districts
//            "Bagerhat", "Bandarban", "Barguna", "Barishal", "Bhola",
//            "Bogura", "Brahmanbaria", "Chandpur", "Chapainawabganj",
//            "Chattogram", "Chuadanga", "Cox's Bazar", "Cumilla", "Dinajpur",
//            "Faridpur", "Feni", "Gaibandha", "Gazipur", "Gopalganj",
//            "Habiganj", "Jamalpur", "Jashore", "Jhalokati", "Jhenaidah",
//            "Joypurhat", "Khagrachari", "Khulna", "Kishoreganj", "Kurigram",
//            "Kushtia", "Lakshmipur", "Lalmonirhat", "Madaripur", "Magura",
//            "Manikganj", "Meherpur", "Moulvibazar", "Munshiganj", "Mymensingh",
//            "Naogaon", "Narail", "Narayanganj", "Narsingdi", "Natore",
//            "Netrokona", "Nilphamari", "Noakhali", "Pabna", "Panchagarh",
//            "Patuakhali", "Pirojpur", "Rajbari", "Rajshahi", "Rangamati",
//            "Rangpur", "Satkhira", "Shariatpur", "Sherpur", "Sirajganj",
//            "Sunamganj", "Sylhet", "Tangail", "Thakurgaon"
            // Name of the cities in Dhaka
            "Ramna",
            "Motijheel",
            "Dhanmondi",
            "Mohammadpur",
            "Kotwali",
            "Tejgaon",
            "Sutrapur",
            "Gulshan",
            "Lalbag",
            "Mirpur",
            "Pallabi",
            "Cantonment",
            "Demra",
            "Hazaribag",
            "Badda",
            "Kafrul",
            "Khilgaon",
            "Uttara",
            "Airport",
            "Paltan",
            "Adabar",
            "Kadamtoli",
            "Gendaria",
            "Rampura",
            "Banani",
            "Bangshal",
            "Bhatara",
            "Jatrabari",
            "Chawkbazar",
            "Rupnagar",
            "Turag",
            "Savar",
            "Shyamoli",
            "Agargaon",
            "Palashi",
            "Azimpur"
    };




    public static final String[] TypeOfProblem = {
            "Accident Situation",
            "Battery Discharged/Not Working",
            "Clutch/Break Problem",
            "Fuel Problem",
            "Lost/Lock Key",
            "Towing",
            "Tyre Problem",
            "Other issue"
    };


    public static final String[] ProblemSubTypeFuel = {
            "Out Of Diesel",
            "Out Of Petrol",
            "Wrong Fuel"
    };

    public static final String[] ProblemSubTypeTyre = {
            "Need Repair",
            "Spare Wheel"
    };

    public static final String[] ProblemSubType = {
            "-",
            "Out Of Diesel",
            "Out Of Petrol",
            "Wrong Fuel",
            "Need Repair",
            "Spare Wheel"
    };

    public static final String[] TypeOfVehicle = {
            "2-Wheeler",
            "4-Wheeler",
            "Heavy Motor Vehicles"
    };

    public static final String[] PaymentMode = {
            "Cash",
            "EPayment"
    };

}
